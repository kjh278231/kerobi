NAME neos859080_pre
ROWS
 N  OBJ
 L  c1      
 L  c42     
 L  c43     
 L  c44     
 L  c45     
 L  c46     
 L  c47     
 L  c48     
 L  c49     
 L  c50     
 L  c51     
 L  c52     
 L  c53     
 L  c54     
 L  c55     
 L  c56     
 L  c57     
 L  c58     
 L  c59     
 L  c60     
 L  c61     
 L  c62     
 L  c63     
 L  c64     
 L  c65     
 L  c66     
 L  c67     
 L  c68     
 L  c69     
 L  c70     
 L  c71     
 L  c72     
 L  c73     
 L  c74     
 L  c75     
 L  c76     
 L  c77     
 L  c78     
 L  c79     
 L  c80     
 L  c81     
 L  c82     
 L  c83     
 L  c84     
 L  c85     
 L  c86     
 L  c87     
 L  c88     
 L  c89     
 L  c90     
 L  c91     
 L  c92     
 L  c93     
 L  c94     
 L  c95     
 L  c96     
 L  c97     
 L  c98     
 L  c99     
 L  c100    
 L  c101    
 L  c102    
 L  c103    
 L  c104    
 L  c105    
 L  c106    
 L  c107    
 L  c108    
 L  c109    
 L  c110    
 L  c111    
 L  c112    
 L  c113    
 L  c114    
 L  c115    
 L  c116    
 L  c117    
 L  c118    
 L  c119    
 L  c120    
 L  c121    
 E  c122    
 E  c127    
 E  c128    
 E  c129    
 E  c130    
 E  c131    
 E  c132    
 E  c133    
 E  c134    
 E  c135    
 E  c136    
 E  c137    
 E  c138    
 E  c139    
 E  c140    
 E  c141    
 E  c142    
 E  c143    
 E  c144    
 E  c145    
 E  c146    
 E  c147    
 E  c148    
 E  c149    
 E  c150    
 E  c151    
 E  c152    
 E  c153    
 E  c154    
 E  c155    
 E  c156    
 E  c157    
 E  c158    
 E  c159    
 E  c160    
 E  c161    
 E  c162    
 E  c163    
 E  c164    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x1        OBJ       1
    x1        c42       1
    x1        c122      1
    x2        OBJ       1
    x2        c1        -1
    x2        c43       1
    x2        c130      1
    x3        OBJ       1
    x3        c44       1
    x3        c127      1
    x3        c129      1
    x3        c130      1
    x3        c133      1
    x3        c134      1
    x4        OBJ       1
    x4        c1        -1
    x4        c45       1
    x4        c138      1
    x5        OBJ       1
    x5        c46       1
    x5        c127      1
    x5        c128      1
    x5        c129      1
    x5        c130      1
    x5        c132      1
    x5        c134      1
    x5        c135      1
    x5        c136      1
    x5        c137      1
    x5        c138      1
    x5        c140      1
    x6        OBJ       1
    x6        c1        -1
    x6        c47       1
    x6        c130      1
    x6        c135      1
    x6        c137      1
    x6        c138      1
    x6        c141      1
    x6        c142      1
    x7        OBJ       1
    x7        c48       1
    x7        c122      1
    x7        c128      1
    x7        c129      1
    x7        c131      1
    x7        c132      1
    x7        c134      1
    x7        c135      1
    x7        c136      1
    x7        c137      1
    x7        c138      1
    x7        c139      1
    x7        c140      1
    x7        c142      1
    x7        c144      1
    x8        OBJ       1
    x8        c1        -1
    x8        c49       1
    x8        c146      1
    x9        OBJ       1
    x9        c50       1
    x9        c122      1
    x9        c128      1
    x9        c130      1
    x9        c131      1
    x9        c132      1
    x9        c134      1
    x9        c136      1
    x9        c137      1
    x9        c142      1
    x9        c145      1
    x9        c147      1
    x10       OBJ       1
    x10       c1        -1
    x10       c51       1
    x10       c130      1
    x10       c135      1
    x10       c136      1
    x10       c137      1
    x10       c138      1
    x10       c140      1
    x10       c142      1
    x10       c143      1
    x10       c144      1
    x10       c145      1
    x10       c146      1
    x10       c148      1
    x11       OBJ       1
    x11       c52       1
    x11       c127      1
    x11       c128      1
    x11       c130      1
    x11       c131      1
    x11       c133      1
    x11       c134      1
    x11       c136      1
    x11       c137      1
    x11       c139      1
    x11       c140      1
    x11       c144      1
    x11       c145      1
    x11       c148      1
    x11       c149      1
    x12       OBJ       1
    x12       c1        -1
    x12       c53       1
    x12       c138      1
    x12       c143      1
    x12       c145      1
    x12       c146      1
    x12       c149      1
    x12       c150      1
    x13       OBJ       1
    x13       c54       1
    x13       c127      1
    x13       c134      1
    x13       c138      1
    x13       c139      1
    x13       c140      1
    x13       c141      1
    x13       c142      1
    x13       c145      1
    x13       c150      1
    x13       c151      1
    x14       OBJ       1
    x14       c1        -1
    x14       c55       1
    x14       c130      1
    x14       c136      1
    x14       c137      1
    x14       c139      1
    x14       c140      1
    x14       c142      1
    x14       c143      1
    x14       c144      1
    x14       c145      1
    x14       c146      1
    x14       c147      1
    x14       c148      1
    x14       c150      1
    x14       c152      1
    x15       OBJ       1
    x15       c56       1
    x15       c122      1
    x15       c129      1
    x15       c130      1
    x15       c131      1
    x15       c133      1
    x15       c134      1
    x15       c137      1
    x15       c139      1
    x15       c144      1
    x15       c145      1
    x15       c149      1
    x15       c150      1
    x15       c153      1
    x16       OBJ       1
    x16       c1        -1
    x16       c57       1
    x16       c154      1
    x17       OBJ       1
    x17       c58       1
    x17       c122      1
    x17       c129      1
    x17       c132      1
    x17       c133      1
    x17       c134      1
    x17       c137      1
    x17       c138      1
    x17       c141      1
    x17       c144      1
    x17       c145      1
    x17       c146      1
    x17       c147      1
    x17       c148      1
    x17       c149      1
    x17       c150      1
    x17       c153      1
    x17       c154      1
    x18       OBJ       1
    x18       c1        -1
    x18       c59       1
    x18       c130      1
    x18       c136      1
    x18       c138      1
    x18       c139      1
    x18       c140      1
    x18       c142      1
    x18       c144      1
    x18       c145      1
    x18       c150      1
    x18       c153      1
    x18       c155      1
    x19       OBJ       1
    x19       c60       1
    x19       c127      1
    x19       c130      1
    x19       c131      1
    x19       c133      1
    x19       c134      1
    x19       c137      1
    x19       c140      1
    x19       c141      1
    x19       c144      1
    x19       c148      1
    x19       c150      1
    x19       c151      1
    x19       c152      1
    x19       c153      1
    x19       c154      1
    x19       c155      1
    x20       OBJ       1
    x20       c1        -1
    x20       c61       1
    x20       c138      1
    x20       c143      1
    x20       c144      1
    x20       c145      1
    x20       c146      1
    x20       c148      1
    x20       c150      1
    x20       c151      1
    x20       c152      1
    x20       c153      1
    x20       c154      1
    x20       c156      1
    x21       OBJ       1
    x21       c62       1
    x21       c127      1
    x21       c128      1
    x21       c133      1
    x21       c138      1
    x21       c139      1
    x21       c141      1
    x21       c143      1
    x21       c144      1
    x21       c147      1
    x21       c148      1
    x21       c149      1
    x21       c152      1
    x21       c153      1
    x21       c157      1
    x22       OBJ       1
    x22       c1        -1
    x22       c63       1
    x22       c130      1
    x22       c135      1
    x22       c136      1
    x22       c138      1
    x22       c139      1
    x22       c141      1
    x22       c142      1
    x22       c144      1
    x22       c145      1
    x22       c147      1
    x22       c148      1
    x22       c152      1
    x22       c153      1
    x22       c156      1
    x22       c157      1
    x23       OBJ       1
    x23       c64       1
    x23       c122      1
    x23       c128      1
    x23       c131      1
    x23       c132      1
    x23       c133      1
    x23       c136      1
    x23       c137      1
    x23       c139      1
    x23       c142      1
    x23       c143      1
    x23       c145      1
    x23       c146      1
    x23       c147      1
    x23       c149      1
    x23       c150      1
    x23       c151      1
    x23       c155      1
    x23       c158      1
    x24       OBJ       1
    x24       c1        -1
    x24       c65       1
    x24       c146      1
    x24       c151      1
    x24       c153      1
    x24       c154      1
    x24       c157      1
    x24       c158      1
    x25       OBJ       1
    x25       c66       1
    x25       c122      1
    x25       c128      1
    x25       c129      1
    x25       c130      1
    x25       c131      1
    x25       c132      1
    x25       c133      1
    x25       c135      1
    x25       c136      1
    x25       c139      1
    x25       c142      1
    x25       c143      1
    x25       c144      1
    x25       c145      1
    x25       c147      1
    x25       c148      1
    x25       c153      1
    x25       c154      1
    x25       c155      1
    x25       c159      1
    x26       OBJ       1
    x26       c1        -1
    x26       c67       1
    x26       c130      1
    x26       c135      1
    x26       c142      1
    x26       c146      1
    x26       c147      1
    x26       c148      1
    x26       c149      1
    x26       c150      1
    x26       c153      1
    x26       c158      1
    x26       c159      1
    x27       OBJ       1
    x27       c68       1
    x27       c127      1
    x27       c128      1
    x27       c129      1
    x27       c133      1
    x27       c134      1
    x27       c135      1
    x27       c137      1
    x27       c140      1
    x27       c141      1
    x27       c142      1
    x27       c147      1
    x27       c152      1
    x27       c153      1
    x27       c154      1
    x27       c160      1
    x28       OBJ       1
    x28       c1        -1
    x28       c69       1
    x28       c138      1
    x28       c144      1
    x28       c145      1
    x28       c147      1
    x28       c148      1
    x28       c150      1
    x28       c151      1
    x28       c152      1
    x28       c153      1
    x28       c154      1
    x28       c155      1
    x28       c156      1
    x28       c158      1
    x28       c160      1
    x29       OBJ       1
    x29       c70       1
    x29       c127      1
    x29       c129      1
    x29       c131      1
    x29       c132      1
    x29       c133      1
    x29       c134      1
    x29       c135      1
    x29       c136      1
    x29       c139      1
    x29       c146      1
    x29       c149      1
    x29       c150      1
    x29       c151      1
    x29       c152      1
    x29       c156      1
    x29       c158      1
    x29       c159      1
    x29       c160      1
    x30       OBJ       1
    x30       c1        -1
    x30       c71       1
    x30       c130      1
    x30       c137      1
    x30       c138      1
    x30       c139      1
    x30       c141      1
    x30       c142      1
    x30       c145      1
    x30       c147      1
    x30       c152      1
    x30       c153      1
    x30       c157      1
    x30       c158      1
    x30       c161      1
    x31       OBJ       1
    x31       c72       1
    x31       c122      1
    x31       c130      1
    x31       c131      1
    x31       c132      1
    x31       c133      1
    x31       c135      1
    x31       c136      1
    x31       c140      1
    x31       c144      1
    x31       c148      1
    x31       c150      1
    x31       c153      1
    x31       c155      1
    x31       c156      1
    x31       c160      1
    x31       c161      1
    x32       OBJ       1
    x32       c1        -1
    x32       c73       1
    x32       c162      1
    x33       OBJ       1
    x33       c74       1
    x33       c122      1
    x33       c130      1
    x33       c134      1
    x33       c135      1
    x33       c136      1
    x33       c140      1
    x33       c141      1
    x33       c142      1
    x33       c143      1
    x33       c144      1
    x33       c148      1
    x33       c150      1
    x33       c151      1
    x33       c152      1
    x33       c154      1
    x33       c155      1
    x33       c156      1
    x33       c160      1
    x33       c162      1
    x34       OBJ       1
    x34       c1        -1
    x34       c75       1
    x34       c130      1
    x34       c137      1
    x34       c140      1
    x34       c141      1
    x34       c142      1
    x34       c145      1
    x34       c146      1
    x34       c149      1
    x34       c152      1
    x34       c153      1
    x34       c154      1
    x34       c155      1
    x34       c156      1
    x34       c157      1
    x34       c158      1
    x34       c161      1
    x34       c162      1
    x35       OBJ       1
    x35       c76       1
    x35       c127      1
    x35       c129      1
    x35       c132      1
    x35       c134      1
    x35       c137      1
    x35       c139      1
    x35       c141      1
    x35       c142      1
    x35       c143      1
    x35       c147      1
    x35       c148      1
    x35       c149      1
    x35       c156      1
    x35       c157      1
    x35       c163      1
    x36       OBJ       1
    x36       c1        -1
    x36       c77       1
    x36       c144      1
    x36       c146      1
    x36       c147      1
    x36       c148      1
    x36       c150      1
    x36       c153      1
    x36       c158      1
    x36       c161      1
    x36       c163      1
    x37       OBJ       1
    x37       c78       1
    x37       c127      1
    x37       c128      1
    x37       c129      1
    x37       c131      1
    x37       c134      1
    x37       c139      1
    x37       c140      1
    x37       c142      1
    x37       c150      1
    x37       c153      1
    x37       c154      1
    x37       c158      1
    x37       c159      1
    x37       c162      1
    x37       c163      1
    x38       OBJ       1
    x38       c1        -1
    x38       c79       1
    x38       c130      1
    x38       c135      1
    x38       c139      1
    x38       c141      1
    x38       c142      1
    x38       c145      1
    x38       c148      1
    x38       c149      1
    x38       c156      1
    x38       c158      1
    x38       c159      1
    x38       c160      1
    x38       c161      1
    x38       c162      1
    x38       c163      1
    x39       OBJ       1
    x39       c80       1
    x39       c122      1
    x39       c128      1
    x39       c129      1
    x39       c130      1
    x39       c132      1
    x39       c133      1
    x39       c134      1
    x39       c136      1
    x39       c140      1
    x39       c141      1
    x39       c142      1
    x39       c145      1
    x39       c148      1
    x39       c149      1
    x39       c150      1
    x39       c155      1
    x39       c157      1
    x39       c164      1
    x40       OBJ       1
    x40       c1        -1
    x40       c81       1
    x40       c146      1
    x40       c151      1
    x40       c152      1
    x40       c153      1
    x40       c154      1
    x40       c159      1
    x40       c162      1
    x40       c164      1
    x41       OBJ       1
    x41       c1        -1
    x41       c82       1
    x41       c122      -1
    x42       OBJ       1
    x42       c1        -1
    x42       c83       1
    x42       c130      -1
    x43       OBJ       1
    x43       c1        -1
    x43       c84       1
    x43       c127      -1
    x43       c129      -1
    x43       c130      -1
    x43       c133      -1
    x43       c134      -1
    x44       OBJ       1
    x44       c1        -1
    x44       c85       1
    x44       c138      -1
    x45       OBJ       1
    x45       c1        -1
    x45       c86       1
    x45       c127      -1
    x45       c128      -1
    x45       c129      -1
    x45       c130      -1
    x45       c132      -1
    x45       c134      -1
    x45       c135      -1
    x45       c136      -1
    x45       c137      -1
    x45       c138      -1
    x45       c140      -1
    x46       OBJ       1
    x46       c1        -1
    x46       c87       1
    x46       c130      -1
    x46       c135      -1
    x46       c137      -1
    x46       c138      -1
    x46       c141      -1
    x46       c142      -1
    x47       OBJ       1
    x47       c1        -1
    x47       c88       1
    x47       c122      -1
    x47       c128      -1
    x47       c129      -1
    x47       c131      -1
    x47       c132      -1
    x47       c134      -1
    x47       c135      -1
    x47       c136      -1
    x47       c137      -1
    x47       c138      -1
    x47       c139      -1
    x47       c140      -1
    x47       c142      -1
    x47       c144      -1
    x48       OBJ       1
    x48       c1        -1
    x48       c89       1
    x48       c146      -1
    x49       OBJ       1
    x49       c1        -1
    x49       c90       1
    x49       c122      -1
    x49       c128      -1
    x49       c130      -1
    x49       c131      -1
    x49       c132      -1
    x49       c134      -1
    x49       c136      -1
    x49       c137      -1
    x49       c142      -1
    x49       c145      -1
    x49       c147      -1
    x50       OBJ       1
    x50       c1        -1
    x50       c91       1
    x50       c130      -1
    x50       c135      -1
    x50       c136      -1
    x50       c137      -1
    x50       c138      -1
    x50       c140      -1
    x50       c142      -1
    x50       c143      -1
    x50       c144      -1
    x50       c145      -1
    x50       c146      -1
    x50       c148      -1
    x51       OBJ       1
    x51       c1        -1
    x51       c92       1
    x51       c127      -1
    x51       c128      -1
    x51       c130      -1
    x51       c131      -1
    x51       c133      -1
    x51       c134      -1
    x51       c136      -1
    x51       c137      -1
    x51       c139      -1
    x51       c140      -1
    x51       c144      -1
    x51       c145      -1
    x51       c148      -1
    x51       c149      -1
    x52       OBJ       1
    x52       c1        -1
    x52       c93       1
    x52       c138      -1
    x52       c143      -1
    x52       c145      -1
    x52       c146      -1
    x52       c149      -1
    x52       c150      -1
    x53       OBJ       1
    x53       c1        -1
    x53       c94       1
    x53       c127      -1
    x53       c134      -1
    x53       c138      -1
    x53       c139      -1
    x53       c140      -1
    x53       c141      -1
    x53       c142      -1
    x53       c145      -1
    x53       c150      -1
    x53       c151      -1
    x54       OBJ       1
    x54       c1        -1
    x54       c95       1
    x54       c130      -1
    x54       c136      -1
    x54       c137      -1
    x54       c139      -1
    x54       c140      -1
    x54       c142      -1
    x54       c143      -1
    x54       c144      -1
    x54       c145      -1
    x54       c146      -1
    x54       c147      -1
    x54       c148      -1
    x54       c150      -1
    x54       c152      -1
    x55       OBJ       1
    x55       c1        -1
    x55       c96       1
    x55       c122      -1
    x55       c129      -1
    x55       c130      -1
    x55       c131      -1
    x55       c133      -1
    x55       c134      -1
    x55       c137      -1
    x55       c139      -1
    x55       c144      -1
    x55       c145      -1
    x55       c149      -1
    x55       c150      -1
    x55       c153      -1
    x56       OBJ       1
    x56       c1        -1
    x56       c97       1
    x56       c154      -1
    x57       OBJ       1
    x57       c1        -1
    x57       c98       1
    x57       c122      -1
    x57       c129      -1
    x57       c132      -1
    x57       c133      -1
    x57       c134      -1
    x57       c137      -1
    x57       c138      -1
    x57       c141      -1
    x57       c144      -1
    x57       c145      -1
    x57       c146      -1
    x57       c147      -1
    x57       c148      -1
    x57       c149      -1
    x57       c150      -1
    x57       c153      -1
    x57       c154      -1
    x58       OBJ       1
    x58       c1        -1
    x58       c99       1
    x58       c130      -1
    x58       c136      -1
    x58       c138      -1
    x58       c139      -1
    x58       c140      -1
    x58       c142      -1
    x58       c144      -1
    x58       c145      -1
    x58       c150      -1
    x58       c153      -1
    x58       c155      -1
    x59       OBJ       1
    x59       c1        -1
    x59       c100      1
    x59       c127      -1
    x59       c130      -1
    x59       c131      -1
    x59       c133      -1
    x59       c134      -1
    x59       c137      -1
    x59       c140      -1
    x59       c141      -1
    x59       c144      -1
    x59       c148      -1
    x59       c150      -1
    x59       c151      -1
    x59       c152      -1
    x59       c153      -1
    x59       c154      -1
    x59       c155      -1
    x60       OBJ       1
    x60       c1        -1
    x60       c101      1
    x60       c138      -1
    x60       c143      -1
    x60       c144      -1
    x60       c145      -1
    x60       c146      -1
    x60       c148      -1
    x60       c150      -1
    x60       c151      -1
    x60       c152      -1
    x60       c153      -1
    x60       c154      -1
    x60       c156      -1
    x61       OBJ       1
    x61       c1        -1
    x61       c102      1
    x61       c127      -1
    x61       c128      -1
    x61       c133      -1
    x61       c138      -1
    x61       c139      -1
    x61       c141      -1
    x61       c143      -1
    x61       c144      -1
    x61       c147      -1
    x61       c148      -1
    x61       c149      -1
    x61       c152      -1
    x61       c153      -1
    x61       c157      -1
    x62       OBJ       1
    x62       c1        -1
    x62       c103      1
    x62       c130      -1
    x62       c135      -1
    x62       c136      -1
    x62       c138      -1
    x62       c139      -1
    x62       c141      -1
    x62       c142      -1
    x62       c144      -1
    x62       c145      -1
    x62       c147      -1
    x62       c148      -1
    x62       c152      -1
    x62       c153      -1
    x62       c156      -1
    x62       c157      -1
    x63       OBJ       1
    x63       c1        -1
    x63       c104      1
    x63       c122      -1
    x63       c128      -1
    x63       c131      -1
    x63       c132      -1
    x63       c133      -1
    x63       c136      -1
    x63       c137      -1
    x63       c139      -1
    x63       c142      -1
    x63       c143      -1
    x63       c145      -1
    x63       c146      -1
    x63       c147      -1
    x63       c149      -1
    x63       c150      -1
    x63       c151      -1
    x63       c155      -1
    x63       c158      -1
    x64       OBJ       1
    x64       c1        -1
    x64       c105      1
    x64       c146      -1
    x64       c151      -1
    x64       c153      -1
    x64       c154      -1
    x64       c157      -1
    x64       c158      -1
    x65       OBJ       1
    x65       c1        -1
    x65       c106      1
    x65       c122      -1
    x65       c128      -1
    x65       c129      -1
    x65       c130      -1
    x65       c131      -1
    x65       c132      -1
    x65       c133      -1
    x65       c135      -1
    x65       c136      -1
    x65       c139      -1
    x65       c142      -1
    x65       c143      -1
    x65       c144      -1
    x65       c145      -1
    x65       c147      -1
    x65       c148      -1
    x65       c153      -1
    x65       c154      -1
    x65       c155      -1
    x65       c159      -1
    x66       OBJ       1
    x66       c1        -1
    x66       c107      1
    x66       c130      -1
    x66       c135      -1
    x66       c142      -1
    x66       c146      -1
    x66       c147      -1
    x66       c148      -1
    x66       c149      -1
    x66       c150      -1
    x66       c153      -1
    x66       c158      -1
    x66       c159      -1
    x67       OBJ       1
    x67       c1        -1
    x67       c108      1
    x67       c127      -1
    x67       c128      -1
    x67       c129      -1
    x67       c133      -1
    x67       c134      -1
    x67       c135      -1
    x67       c137      -1
    x67       c140      -1
    x67       c141      -1
    x67       c142      -1
    x67       c147      -1
    x67       c152      -1
    x67       c153      -1
    x67       c154      -1
    x67       c160      -1
    x68       OBJ       1
    x68       c1        -1
    x68       c109      1
    x68       c138      -1
    x68       c144      -1
    x68       c145      -1
    x68       c147      -1
    x68       c148      -1
    x68       c150      -1
    x68       c151      -1
    x68       c152      -1
    x68       c153      -1
    x68       c154      -1
    x68       c155      -1
    x68       c156      -1
    x68       c158      -1
    x68       c160      -1
    x69       OBJ       1
    x69       c1        -1
    x69       c110      1
    x69       c127      -1
    x69       c129      -1
    x69       c131      -1
    x69       c132      -1
    x69       c133      -1
    x69       c134      -1
    x69       c135      -1
    x69       c136      -1
    x69       c139      -1
    x69       c146      -1
    x69       c149      -1
    x69       c150      -1
    x69       c151      -1
    x69       c152      -1
    x69       c156      -1
    x69       c158      -1
    x69       c159      -1
    x69       c160      -1
    x70       OBJ       1
    x70       c1        -1
    x70       c111      1
    x70       c130      -1
    x70       c137      -1
    x70       c138      -1
    x70       c139      -1
    x70       c141      -1
    x70       c142      -1
    x70       c145      -1
    x70       c147      -1
    x70       c152      -1
    x70       c153      -1
    x70       c157      -1
    x70       c158      -1
    x70       c161      -1
    x71       OBJ       1
    x71       c1        -1
    x71       c112      1
    x71       c122      -1
    x71       c130      -1
    x71       c131      -1
    x71       c132      -1
    x71       c133      -1
    x71       c135      -1
    x71       c136      -1
    x71       c140      -1
    x71       c144      -1
    x71       c148      -1
    x71       c150      -1
    x71       c153      -1
    x71       c155      -1
    x71       c156      -1
    x71       c160      -1
    x71       c161      -1
    x72       OBJ       1
    x72       c1        -1
    x72       c113      1
    x72       c162      -1
    x73       OBJ       1
    x73       c1        -1
    x73       c114      1
    x73       c122      -1
    x73       c130      -1
    x73       c134      -1
    x73       c135      -1
    x73       c136      -1
    x73       c140      -1
    x73       c141      -1
    x73       c142      -1
    x73       c143      -1
    x73       c144      -1
    x73       c148      -1
    x73       c150      -1
    x73       c151      -1
    x73       c152      -1
    x73       c154      -1
    x73       c155      -1
    x73       c156      -1
    x73       c160      -1
    x73       c162      -1
    x74       OBJ       1
    x74       c1        -1
    x74       c115      1
    x74       c130      -1
    x74       c137      -1
    x74       c140      -1
    x74       c141      -1
    x74       c142      -1
    x74       c145      -1
    x74       c146      -1
    x74       c149      -1
    x74       c152      -1
    x74       c153      -1
    x74       c154      -1
    x74       c155      -1
    x74       c156      -1
    x74       c157      -1
    x74       c158      -1
    x74       c161      -1
    x74       c162      -1
    x75       OBJ       1
    x75       c1        -1
    x75       c116      1
    x75       c127      -1
    x75       c129      -1
    x75       c132      -1
    x75       c134      -1
    x75       c137      -1
    x75       c139      -1
    x75       c141      -1
    x75       c142      -1
    x75       c143      -1
    x75       c147      -1
    x75       c148      -1
    x75       c149      -1
    x75       c156      -1
    x75       c157      -1
    x75       c163      -1
    x76       OBJ       1
    x76       c1        -1
    x76       c117      1
    x76       c144      -1
    x76       c146      -1
    x76       c147      -1
    x76       c148      -1
    x76       c150      -1
    x76       c153      -1
    x76       c158      -1
    x76       c161      -1
    x76       c163      -1
    x77       OBJ       1
    x77       c1        -1
    x77       c118      1
    x77       c127      -1
    x77       c128      -1
    x77       c129      -1
    x77       c131      -1
    x77       c134      -1
    x77       c139      -1
    x77       c140      -1
    x77       c142      -1
    x77       c150      -1
    x77       c153      -1
    x77       c154      -1
    x77       c158      -1
    x77       c159      -1
    x77       c162      -1
    x77       c163      -1
    x78       OBJ       1
    x78       c1        -1
    x78       c119      1
    x78       c130      -1
    x78       c135      -1
    x78       c139      -1
    x78       c141      -1
    x78       c142      -1
    x78       c145      -1
    x78       c148      -1
    x78       c149      -1
    x78       c156      -1
    x78       c158      -1
    x78       c159      -1
    x78       c160      -1
    x78       c161      -1
    x78       c162      -1
    x78       c163      -1
    x79       OBJ       1
    x79       c1        -1
    x79       c120      1
    x79       c122      -1
    x79       c128      -1
    x79       c129      -1
    x79       c130      -1
    x79       c132      -1
    x79       c133      -1
    x79       c134      -1
    x79       c136      -1
    x79       c140      -1
    x79       c141      -1
    x79       c142      -1
    x79       c145      -1
    x79       c148      -1
    x79       c149      -1
    x79       c150      -1
    x79       c155      -1
    x79       c157      -1
    x79       c164      -1
    x80       OBJ       1
    x80       c1        -1
    x80       c121      1
    x80       c146      -1
    x80       c151      -1
    x80       c152      -1
    x80       c153      -1
    x80       c154      -1
    x80       c159      -1
    x80       c162      -1
    x80       c164      -1
    x121      c42       10
    x121      c82       -10
    x122      c43       10
    x122      c83       -10
    x123      c44       10
    x123      c84       -10
    x124      c45       10
    x124      c85       -10
    x125      c46       10
    x125      c86       -10
    x126      c47       10
    x126      c87       -10
    x127      c48       10
    x127      c88       -10
    x128      c49       10
    x128      c89       -10
    x129      c50       10
    x129      c90       -10
    x130      c51       10
    x130      c91       -10
    x131      c52       10
    x131      c92       -10
    x132      c53       10
    x132      c93       -10
    x133      c54       10
    x133      c94       -10
    x134      c55       10
    x134      c95       -10
    x135      c56       10
    x135      c96       -10
    x136      c57       10
    x136      c97       -10
    x137      c58       10
    x137      c98       -10
    x138      c59       10
    x138      c99       -10
    x139      c60       10
    x139      c100      -10
    x140      c61       10
    x140      c101      -10
    x141      c62       10
    x141      c102      -10
    x142      c63       10
    x142      c103      -10
    x143      c64       10
    x143      c104      -10
    x144      c65       10
    x144      c105      -10
    x145      c66       10
    x145      c106      -10
    x146      c67       10
    x146      c107      -10
    x147      c68       10
    x147      c108      -10
    x148      c69       10
    x148      c109      -10
    x149      c70       10
    x149      c110      -10
    x150      c71       10
    x150      c111      -10
    x151      c72       10
    x151      c112      -10
    x152      c73       10
    x152      c113      -10
    x153      c74       10
    x153      c114      -10
    x154      c75       10
    x154      c115      -10
    x155      c76       10
    x155      c116      -10
    x156      c77       10
    x156      c117      -10
    x157      c78       10
    x157      c118      -10
    x158      c79       10
    x158      c119      -10
    x159      c80       10
    x159      c120      -10
    x160      c81       10
    x160      c121      -10
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      c1        -1
    RHS1      c42       10
    RHS1      c43       10
    RHS1      c44       10
    RHS1      c45       10
    RHS1      c46       10
    RHS1      c47       10
    RHS1      c48       10
    RHS1      c49       10
    RHS1      c50       10
    RHS1      c51       10
    RHS1      c52       10
    RHS1      c53       10
    RHS1      c54       10
    RHS1      c55       10
    RHS1      c56       10
    RHS1      c57       10
    RHS1      c58       10
    RHS1      c59       10
    RHS1      c60       10
    RHS1      c61       10
    RHS1      c62       10
    RHS1      c63       10
    RHS1      c64       10
    RHS1      c65       10
    RHS1      c66       10
    RHS1      c67       10
    RHS1      c68       10
    RHS1      c69       10
    RHS1      c70       10
    RHS1      c71       10
    RHS1      c72       10
    RHS1      c73       10
    RHS1      c74       10
    RHS1      c75       10
    RHS1      c76       10
    RHS1      c77       10
    RHS1      c78       10
    RHS1      c79       10
    RHS1      c80       10
    RHS1      c81       10
BOUNDS
 UP BND1      x1        10
 UP BND1      x2        10
 UP BND1      x3        10
 UP BND1      x4        10
 UP BND1      x5        10
 UP BND1      x6        10
 UP BND1      x7        10
 UP BND1      x8        10
 UP BND1      x9        10
 UP BND1      x10       10
 UP BND1      x11       10
 UP BND1      x12       10
 UP BND1      x13       10
 UP BND1      x14       10
 UP BND1      x15       10
 UP BND1      x16       10
 UP BND1      x17       10
 UP BND1      x18       10
 UP BND1      x19       10
 UP BND1      x20       10
 UP BND1      x21       10
 UP BND1      x22       10
 UP BND1      x23       10
 UP BND1      x24       10
 UP BND1      x25       10
 UP BND1      x26       10
 UP BND1      x27       10
 UP BND1      x28       10
 UP BND1      x29       10
 UP BND1      x30       10
 UP BND1      x31       10
 UP BND1      x32       10
 UP BND1      x33       10
 UP BND1      x34       10
 UP BND1      x35       10
 UP BND1      x36       10
 UP BND1      x37       10
 UP BND1      x38       10
 UP BND1      x39       10
 UP BND1      x40       10
 UP BND1      x41       10
 UP BND1      x42       10
 UP BND1      x43       10
 UP BND1      x44       10
 UP BND1      x45       10
 UP BND1      x46       10
 UP BND1      x47       10
 UP BND1      x48       10
 UP BND1      x49       10
 UP BND1      x50       10
 UP BND1      x51       10
 UP BND1      x52       10
 UP BND1      x53       10
 UP BND1      x54       10
 UP BND1      x55       10
 UP BND1      x56       10
 UP BND1      x57       10
 UP BND1      x58       10
 UP BND1      x59       10
 UP BND1      x60       10
 UP BND1      x61       10
 UP BND1      x62       10
 UP BND1      x63       10
 UP BND1      x64       10
 UP BND1      x65       10
 UP BND1      x66       10
 UP BND1      x67       10
 UP BND1      x68       10
 UP BND1      x69       10
 UP BND1      x70       10
 UP BND1      x71       10
 UP BND1      x72       10
 UP BND1      x73       10
 UP BND1      x74       10
 UP BND1      x75       10
 UP BND1      x76       10
 UP BND1      x77       10
 UP BND1      x78       10
 UP BND1      x79       10
 UP BND1      x80       10
 BV BND1      x121    
 BV BND1      x122    
 BV BND1      x123    
 BV BND1      x124    
 BV BND1      x125    
 BV BND1      x126    
 BV BND1      x127    
 BV BND1      x128    
 BV BND1      x129    
 BV BND1      x130    
 BV BND1      x131    
 BV BND1      x132    
 BV BND1      x133    
 BV BND1      x134    
 BV BND1      x135    
 BV BND1      x136    
 BV BND1      x137    
 BV BND1      x138    
 BV BND1      x139    
 BV BND1      x140    
 BV BND1      x141    
 BV BND1      x142    
 BV BND1      x143    
 BV BND1      x144    
 BV BND1      x145    
 BV BND1      x146    
 BV BND1      x147    
 BV BND1      x148    
 BV BND1      x149    
 BV BND1      x150    
 BV BND1      x151    
 BV BND1      x152    
 BV BND1      x153    
 BV BND1      x154    
 BV BND1      x155    
 BV BND1      x156    
 BV BND1      x157    
 BV BND1      x158    
 BV BND1      x159    
 BV BND1      x160    
ENDATA
