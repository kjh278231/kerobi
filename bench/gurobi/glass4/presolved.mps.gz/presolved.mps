NAME glass4_pre
ROWS
 N  OBJ
 L  id21    
 L  id22    
 L  id23    
 L  id24    
 L  id25    
 L  id26    
 L  id27    
 L  id28    
 L  id29    
 L  id31    
 L  id32    
 L  id34    
 L  id36    
 L  id38    
 L  id40    
 L  id41    
 L  id43    
 L  id45    
 L  id46    
 L  id48    
 E  id49    
 L  id51    
 L  id53    
 L  id55    
 L  id57    
 L  id58    
 L  id60    
 L  id62    
 L  id63    
 L  id67    
 L  id68    
 L  id70    
 L  id72    
 E  id73    
 L  id75    
 L  id77    
 L  id79    
 L  id81    
 L  id83    
 L  id84    
 L  id86    
 L  id88    
 L  id89    
 L  id91    
 L  id93    
 E  id94    
 L  id96    
 L  id98    
 L  id100   
 L  id102   
 L  id104   
 L  id105   
 L  id107   
 L  id108   
 L  id110   
 L  id112   
 L  id114   
 E  id115   
 L  id117   
 L  id119   
 L  id121   
 L  id123   
 L  id124   
 L  id126   
 L  id127   
 L  id129   
 L  id131   
 L  id132   
 L  id134   
 E  id135   
 L  id137   
 L  id139   
 L  id141   
 L  id143   
 L  id145   
 L  id146   
 L  id148   
 L  id150   
 L  id151   
 L  id153   
 L  id155   
 E  id156   
 L  id158   
 L  id160   
 L  id162   
 L  id164   
 L  id166   
 L  id168   
 L  id170   
 L  id171   
 L  id173   
 L  id175   
 L  id176   
 L  id178   
 L  id180   
 L  id181   
 L  id182   
 L  id184   
 L  id186   
 E  id187   
 L  id189   
 L  id191   
 L  id193   
 L  id195   
 L  id196   
 L  id198   
 L  id199   
 L  id201   
 L  id203   
 E  id204   
 L  id206   
 L  id208   
 L  id210   
 L  id212   
 L  id213   
 L  id215   
 L  id216   
 L  id220   
 L  id222   
 E  id223   
 L  id225   
 L  id227   
 L  id229   
 L  id231   
 L  id232   
 L  id234   
 L  id236   
 L  id238   
 L  id240   
 E  id241   
 L  id243   
 L  id245   
 L  id247   
 L  id249   
 L  id251   
 L  id252   
 L  id254   
 L  id256   
 L  id258   
 L  id260   
 L  id262   
 E  id263   
 L  id265   
 L  id267   
 L  id269   
 L  id270   
 L  id272   
 L  id274   
 L  id276   
 L  id278   
 L  id279   
 L  id281   
 E  id282   
 L  id284   
 L  id286   
 L  id288   
 L  id290   
 L  id291   
 L  id293   
 L  id295   
 L  id297   
 L  id299   
 E  id300   
 L  id302   
 L  id304   
 L  id306   
 L  id308   
 L  id310   
 L  id312   
 L  id313   
 L  id315   
 L  id317   
 L  id319   
 L  id321   
 L  id322   
 L  id324   
 E  id325   
 L  id327   
 L  id329   
 L  id331   
 L  id333   
 L  id334   
 L  id336   
 L  id338   
 E  id339   
 L  id341   
 L  id342   
 L  id344   
 L  id346   
 L  id348   
 L  id350   
 L  id352   
 L  id354   
 E  id355   
 L  id357   
 L  id358   
 L  id360   
 L  id362   
 L  id364   
 L  id366   
 L  id368   
 L  id370   
 E  id371   
 L  id373   
 L  id374   
 L  id378   
 L  id380   
 L  id382   
 L  id384   
 L  id386   
 L  id387   
 E  id388   
 L  id390   
 L  id391   
 L  id393   
 L  id395   
 L  id397   
 L  id399   
 L  id401   
 L  id403   
 E  id404   
 L  id406   
 L  id407   
 L  id409   
 L  id413   
 L  id415   
 L  id417   
 L  id419   
 L  id421   
 L  id423   
 L  id424   
 E  id425   
 L  id427   
 L  id428   
 L  id430   
 L  id434   
 L  id436   
 L  id438   
 E  id439   
 L  id441   
 L  id443   
 L  id445   
 L  id447   
 L  id449   
 L  id451   
 L  id453   
 L  id455   
 L  id457   
 E  id458   
 L  id460   
 L  id462   
 L  id464   
 L  id466   
 L  id468   
 L  id470   
 L  id472   
 L  id474   
 L  id476   
 L  id477   
 L  id479   
 E  id480   
 L  id482   
 L  id484   
 L  id486   
 L  id488   
 L  id490   
 L  id492   
 E  id493   
 L  id495   
 L  id497   
 L  id499   
 L  id501   
 L  id503   
 L  id505   
 L  id507   
 L  id509   
 L  id511   
 L  id512   
 L  id514   
 E  id515   
 L  id517   
 L  id519   
 L  id521   
 L  id523   
 L  id525   
 L  id527   
 E  id528   
 L  id530   
 L  id532   
 L  id534   
 L  id536   
 L  id538   
 L  id540   
 L  id542   
 L  id544   
 L  id546   
 L  id547   
 E  id548   
 L  id550   
 L  id552   
 L  id554   
 L  id556   
 L  id558   
 L  id560   
 L  id562   
 L  id564   
 L  id566   
 E  id567   
 L  id569   
 L  id571   
 L  id573   
 L  id575   
 L  id577   
 L  id579   
 L  id581   
 L  id583   
 L  id585   
 L  id587   
 L  id588   
 L  id590   
 E  id591   
 L  id593   
 L  id595   
 L  id597   
 L  id599   
 L  id601   
 L  id603   
 L  id605   
 E  id606   
 L  id608   
 L  id610   
 L  id612   
 L  id613   
 L  id615   
 L  id617   
 L  id619   
 L  id621   
 L  id623   
 E  id624   
 L  id626   
 L  id628   
 L  id630   
 L  id632   
 L  id633   
 L  id635   
 L  id639   
 L  id641   
 L  id642   
 L  id644   
 L  id646   
 E  id647   
 L  id649   
 L  id651   
 L  id653   
 L  id654   
 L  id656   
 L  id658   
 L  id660   
 L  id662   
 E  id663   
 L  id665   
 L  id667   
 L  id669   
 L  id671   
 L  id673   
 L  id675   
 L  id677   
 L  id679   
 L  id680   
 L  id682   
 L  id684   
 E  id685   
 L  id687   
 L  id689   
 L  id691   
 L  id693   
 L  id695   
 L  id697   
 L  id699   
 E  id700   
 L  id702   
 L  id704   
 L  id706   
 L  id707   
 L  id709   
 L  id711   
 L  id713   
 L  id715   
 L  id717   
 E  id718   
COLUMNS
    x1        OBJ       2
    x1        id21      1
    x1        id32      -300
    x1        id36      300
    x1        id38      600
    x1        id41      100
    x1        id45      -100
    x1        id48      -600
    x1        id53      200
    x1        id55      400
    x1        id57      200
    x1        id58      300
    x1        id62      -33.3340148925781
    x1        id63      133.334014892578
    x1        id67      -120
    x1        id68      20
    x1        id72      -1100
    x1        id77      200
    x1        id79      400
    x1        id81      200
    x1        id83      -100
    x1        id84      200
    x1        id86      -100
    x1        id88      -40
    x1        id89      40
    x1        id91      -100
    x1        id93      -700
    x1        id98      200
    x1        id100     400
    x1        id102     200
    x1        id104     -100
    x1        id105     200
    x1        id107     -125
    x1        id108     25
    x1        id110     -200
    x1        id112     -200
    x1        id114     -400
    x1        id119     800
    x1        id121     200
    x1        id123     -100
    x1        id124     200
    x1        id126     -166.665985107422
    x1        id127     66.6659851074219
    x1        id129     -200
    x1        id131     -300
    x1        id132     -100
    x1        id134     -400
    x1        id137     -300
    x1        id141     800
    x1        id143     100
    x1        id145     -66.6659851074219
    x1        id146     66.6659851074219
    x1        id148     100
    x1        id150     -200
    x1        id151     100
    x1        id153     -200
    x1        id155     -400
    x1        id158     -200
    x1        id162     200
    x1        id164     200
    x1        id166     400
    x1        id168     300
    x1        id170     -100
    x1        id171     200
    x1        id173     -100
    x1        id175     -40
    x1        id176     40
    x1        id178     -100
    x1        id180     -300
    x1        id181     -40
    x1        id182     40
    x1        id184     -100
    x1        id186     -400
    x1        id189     -300
    x1        id193     1000
    x1        id195     -100
    x1        id196     200
    x1        id198     -166.665985107422
    x1        id199     66.6659851074219
    x1        id201     -300
    x1        id203     -400
    x2        OBJ       2
    x2        id22      1
    x2        id32      300
    x2        id36      -300
    x2        id38      -600
    x2        id41      -100
    x2        id45      100
    x2        id48      600
    x2        id208     200
    x2        id210     200
    x2        id212     200
    x2        id213     300
    x2        id216     300
    x2        id220     -300
    x2        id222     -900
    x2        id227     200
    x2        id229     200
    x2        id231     200
    x2        id232     100
    x2        id234     200
    x2        id236     -100
    x2        id238     -300
    x2        id240     -500
    x2        id245     200
    x2        id247     200
    x2        id249     200
    x2        id252     100
    x2        id254     200
    x2        id256     -200
    x2        id258     -300
    x2        id260     -200
    x2        id262     -200
    x2        id267     600
    x2        id269     200
    x2        id270     100
    x2        id272     200
    x2        id274     -500
    x2        id276     -200
    x2        id278     -66.6659851074219
    x2        id279     -133.334014892578
    x2        id281     -200
    x2        id284     -300
    x2        id288     600
    x2        id290     100
    x2        id291     200
    x2        id293     100
    x2        id295     -300
    x2        id297     -200
    x2        id299     -200
    x2        id302     -200
    x2        id306     200
    x2        id308     200
    x2        id310     200
    x2        id312     200
    x2        id313     100
    x2        id315     300
    x2        id317     -100
    x2        id319     -300
    x2        id321     -100
    x2        id322     -300
    x2        id324     -200
    x2        id327     -300
    x2        id331     800
    x2        id334     300
    x2        id336     -600
    x2        id338     -200
    x3        OBJ       2
    x3        id23      1
    x3        id53      -200
    x3        id55      -400
    x3        id57      -200
    x3        id58      -300
    x3        id62      33.3340148925781
    x3        id63      -133.334014892578
    x3        id67      120
    x3        id68      -20
    x3        id72      1100
    x3        id208     -200
    x3        id210     -200
    x3        id212     -200
    x3        id213     -300
    x3        id216     -300
    x3        id220     300
    x3        id222     900
    x3        id341     -200
    x3        id342     -300
    x3        id346     200
    x3        id348     700
    x3        id350     200
    x3        id352     -300
    x3        id354     -300
    x3        id357     -200
    x3        id358     -300
    x3        id362     200
    x3        id364     700
    x3        id366     200
    x3        id368     -400
    x3        id370     -200
    x3        id373     -200
    x3        id374     -300
    x3        id378     1100
    x3        id380     200
    x3        id382     -200
    x3        id384     -200
    x3        id386     -200
    x3        id387     -200
    x3        id390     -200
    x3        id391     -300
    x3        id393     -300
    x3        id397     1100
    x3        id399     100
    x3        id401     -200
    x3        id403     -200
    x3        id406     -200
    x3        id407     -300
    x3        id409     -200
    x3        id413     200
    x3        id415     200
    x3        id417     700
    x3        id419     300
    x3        id421     -300
    x3        id423     -250
    x3        id424     -150
    x3        id427     -200
    x3        id428     -300
    x3        id430     -300
    x3        id434     1300
    x3        id436     -200
    x3        id438     -300
    x4        OBJ       2
    x4        id24      1
    x4        id77      -200
    x4        id79      -400
    x4        id81      -200
    x4        id83      100
    x4        id84      -200
    x4        id86      100
    x4        id88      40
    x4        id89      -40
    x4        id91      100
    x4        id93      700
    x4        id227     -200
    x4        id229     -200
    x4        id231     -200
    x4        id232     -100
    x4        id234     -200
    x4        id236     100
    x4        id238     300
    x4        id240     500
    x4        id341     200
    x4        id342     300
    x4        id346     -200
    x4        id348     -700
    x4        id350     -200
    x4        id352     300
    x4        id354     300
    x4        id443     100
    x4        id445     200
    x4        id447     300
    x4        id449     200
    x4        id453     -200
    x4        id455     -400
    x4        id457     -200
    x4        id460     -200
    x4        id464     100
    x4        id466     700
    x4        id468     200
    x4        id472     -200
    x4        id474     -200
    x4        id476     -133.333999633789
    x4        id477     -66.6660003662109
    x4        id479     -200
    x4        id482     100
    x4        id484     700
    x4        id486     100
    x4        id490     -400
    x4        id492     -500
    x4        id495     -400
    x4        id497     300
    x4        id499     200
    x4        id501     300
    x4        id503     300
    x4        id507     -100
    x4        id509     -200
    x4        id511     -100
    x4        id512     -100
    x4        id514     -200
    x4        id517     100
    x4        id519     900
    x4        id523     -300
    x4        id525     -200
    x4        id527     -500
    x5        OBJ       2
    x5        id25      1
    x5        id98      -200
    x5        id100     -400
    x5        id102     -200
    x5        id104     100
    x5        id105     -200
    x5        id107     125
    x5        id108     -25
    x5        id110     200
    x5        id112     200
    x5        id114     400
    x5        id245     -200
    x5        id247     -200
    x5        id249     -200
    x5        id252     -100
    x5        id254     -200
    x5        id256     200
    x5        id258     300
    x5        id260     200
    x5        id262     200
    x5        id357     200
    x5        id358     300
    x5        id362     -200
    x5        id364     -700
    x5        id366     -200
    x5        id368     400
    x5        id370     200
    x5        id443     -100
    x5        id445     -200
    x5        id447     -300
    x5        id449     -200
    x5        id453     200
    x5        id455     400
    x5        id457     200
    x5        id530     -200
    x5        id534     200
    x5        id536     200
    x5        id538     400
    x5        id540     200
    x5        id544     -400
    x5        id546     -200
    x5        id547     -200
    x5        id550     200
    x5        id552     200
    x5        id554     400
    x5        id556     100
    x5        id560     -200
    x5        id562     -200
    x5        id564     -200
    x5        id566     -300
    x5        id569     -200
    x5        id571     -200
    x5        id573     400
    x5        id575     200
    x5        id577     200
    x5        id579     300
    x5        id583     -100
    x5        id585     -200
    x5        id587     -150
    x5        id588     -50
    x5        id590     -200
    x5        id593     200
    x5        id595     200
    x5        id597     600
    x5        id601     -500
    x5        id603     -200
    x5        id605     -300
    x6        OBJ       2
    x6        id26      1
    x6        id119     -800
    x6        id121     -200
    x6        id123     100
    x6        id124     -200
    x6        id126     166.665985107422
    x6        id127     -66.6659851074219
    x6        id129     200
    x6        id131     300
    x6        id132     100
    x6        id134     400
    x6        id267     -600
    x6        id269     -200
    x6        id270     -100
    x6        id272     -200
    x6        id274     500
    x6        id276     200
    x6        id278     66.6659851074219
    x6        id279     133.334014892578
    x6        id281     200
    x6        id373     200
    x6        id374     300
    x6        id378     -1100
    x6        id380     -200
    x6        id382     200
    x6        id384     200
    x6        id386     200
    x6        id387     200
    x6        id460     200
    x6        id464     -100
    x6        id466     -700
    x6        id468     -200
    x6        id472     200
    x6        id474     200
    x6        id476     133.333999633789
    x6        id477     66.6660003662109
    x6        id479     200
    x6        id530     200
    x6        id534     -200
    x6        id536     -200
    x6        id538     -400
    x6        id540     -200
    x6        id544     400
    x6        id546     200
    x6        id547     200
    x6        id608     -500
    x6        id610     200
    x6        id612     300
    x6        id613     100
    x6        id615     400
    x6        id617     100
    x6        id621     -200
    x6        id623     -400
    x6        id626     -400
    x6        id628     200
    x6        id630     400
    x6        id632     200
    x6        id633     200
    x6        id635     300
    x6        id639     -100
    x6        id641     -300
    x6        id644     -100
    x6        id646     -400
    x6        id649     -500
    x6        id651     200
    x6        id653     300
    x6        id654     100
    x6        id656     600
    x6        id660     -300
    x6        id662     -400
    x7        OBJ       2
    x7        id27      1
    x7        id137     300
    x7        id141     -800
    x7        id143     -100
    x7        id145     66.6659851074219
    x7        id146     -66.6659851074219
    x7        id148     -100
    x7        id150     200
    x7        id151     -100
    x7        id153     200
    x7        id155     400
    x7        id284     300
    x7        id288     -600
    x7        id290     -100
    x7        id291     -200
    x7        id293     -100
    x7        id295     300
    x7        id297     200
    x7        id299     200
    x7        id390     200
    x7        id391     300
    x7        id393     300
    x7        id397     -1100
    x7        id399     -100
    x7        id401     200
    x7        id403     200
    x7        id482     -100
    x7        id484     -700
    x7        id486     -100
    x7        id490     400
    x7        id492     500
    x7        id550     -200
    x7        id552     -200
    x7        id554     -400
    x7        id556     -100
    x7        id560     200
    x7        id562     200
    x7        id564     200
    x7        id566     300
    x7        id608     500
    x7        id610     -200
    x7        id612     -300
    x7        id613     -100
    x7        id615     -400
    x7        id617     -100
    x7        id621     200
    x7        id623     400
    x7        id665     -200
    x7        id667     -100
    x7        id669     200
    x7        id671     200
    x7        id673     200
    x7        id675     600
    x7        id677     -100
    x7        id679     -400
    x7        id680     100
    x7        id682     -100
    x7        id684     -400
    x7        id687     200
    x7        id689     600
    x7        id691     300
    x7        id693     -300
    x7        id695     -400
    x7        id697     -300
    x7        id699     -100
    x8        OBJ       2
    x8        id28      1
    x8        id158     200
    x8        id162     -200
    x8        id164     -200
    x8        id166     -400
    x8        id168     -300
    x8        id170     100
    x8        id171     -200
    x8        id173     100
    x8        id175     40
    x8        id176     -40
    x8        id178     100
    x8        id180     300
    x8        id181     40
    x8        id182     -40
    x8        id184     100
    x8        id186     400
    x8        id302     200
    x8        id306     -200
    x8        id308     -200
    x8        id310     -200
    x8        id312     -200
    x8        id313     -100
    x8        id315     -300
    x8        id317     100
    x8        id319     300
    x8        id321     100
    x8        id322     300
    x8        id324     200
    x8        id406     200
    x8        id407     300
    x8        id409     200
    x8        id413     -200
    x8        id415     -200
    x8        id417     -700
    x8        id419     -300
    x8        id421     300
    x8        id423     250
    x8        id424     150
    x8        id495     400
    x8        id497     -300
    x8        id499     -200
    x8        id501     -300
    x8        id503     -300
    x8        id507     100
    x8        id509     200
    x8        id511     100
    x8        id512     100
    x8        id514     200
    x8        id569     200
    x8        id571     200
    x8        id573     -400
    x8        id575     -200
    x8        id577     -200
    x8        id579     -300
    x8        id583     100
    x8        id585     200
    x8        id587     150
    x8        id588     50
    x8        id590     200
    x8        id626     400
    x8        id628     -200
    x8        id630     -400
    x8        id632     -200
    x8        id633     -200
    x8        id635     -300
    x8        id639     100
    x8        id641     300
    x8        id644     100
    x8        id646     400
    x8        id665     200
    x8        id667     100
    x8        id669     -200
    x8        id671     -200
    x8        id673     -200
    x8        id675     -600
    x8        id677     100
    x8        id679     400
    x8        id680     -100
    x8        id682     100
    x8        id684     400
    x8        id702     -600
    x8        id704     100
    x8        id706     400
    x8        id707     -100
    x8        id709     100
    x8        id711     600
    x8        id713     200
    x8        id715     -200
    x8        id717     -500
    x9        OBJ       2
    x9        id29      1
    x9        id189     300
    x9        id193     -1000
    x9        id195     100
    x9        id196     -200
    x9        id198     166.665985107422
    x9        id199     -66.6659851074219
    x9        id201     300
    x9        id203     400
    x9        id327     300
    x9        id331     -800
    x9        id334     -300
    x9        id336     600
    x9        id338     200
    x9        id427     200
    x9        id428     300
    x9        id430     300
    x9        id434     -1300
    x9        id436     200
    x9        id438     300
    x9        id517     -100
    x9        id519     -900
    x9        id523     300
    x9        id525     200
    x9        id527     500
    x9        id593     -200
    x9        id595     -200
    x9        id597     -600
    x9        id601     500
    x9        id603     200
    x9        id605     300
    x9        id649     500
    x9        id651     -200
    x9        id653     -300
    x9        id654     -100
    x9        id656     -600
    x9        id660     300
    x9        id662     400
    x9        id687     -200
    x9        id689     -600
    x9        id691     -300
    x9        id693     300
    x9        id695     400
    x9        id697     300
    x9        id699     100
    x9        id702     600
    x9        id704     -100
    x9        id706     -400
    x9        id707     100
    x9        id709     -100
    x9        id711     -600
    x9        id713     -200
    x9        id715     200
    x9        id717     500
    lung      OBJ       1000000
    lung      id21      -1
    lung      id22      -1
    lung      id23      -1
    lung      id24      -1
    lung      id25      -1
    lung      id26      -1
    lung      id27      -1
    lung      id28      -1
    lung      id29      -1
    y1        OBJ       1
    y1        id31      -200
    y1        id34      -700
    y1        id36      -300
    y1        id40      300
    y1        id41      100
    y1        id43      500
    y1        id45      50
    y1        id46      250
    y1        id51      -700
    y1        id53      -400
    y1        id57      200
    y1        id60      200
    y1        id62      66.6659851074219
    y1        id63      133.334014892578
    y1        id67      60
    y1        id68      40
    y1        id70      200
    y1        id75      -1000
    y1        id77      -100
    y1        id81      200
    y1        id83      200
    y1        id84      200
    y1        id86      200
    y1        id88      20
    y1        id89      80
    y1        id91      200
    y1        id96      -1100
    y1        id98      -200
    y1        id102     100
    y1        id104     200
    y1        id105     200
    y1        id107     250
    y1        id108     50
    y1        id110     400
    y1        id112     100
    y1        id117     -1200
    y1        id121     200
    y1        id123     200
    y1        id124     200
    y1        id126     166.666000366211
    y1        id127     133.333999633789
    y1        id129     200
    y1        id132     100
    y1        id137     -300
    y1        id139     -700
    y1        id143     200
    y1        id145     133.333984375
    y1        id146     66.666015625
    y1        id148     200
    y1        id150     100
    y1        id151     200
    y1        id153     100
    y1        id158     -200
    y1        id160     -700
    y1        id162     -400
    y1        id164     -200
    y1        id168     300
    y1        id170     200
    y1        id171     200
    y1        id173     200
    y1        id175     20
    y1        id176     80
    y1        id178     200
    y1        id181     20
    y1        id182     80
    y1        id184     200
    y1        id189     -300
    y1        id191     -700
    y1        id195     200
    y1        id196     200
    y1        id198     166.666000366211
    y1        id199     133.333999633789
    y1        id201     300
    y2        OBJ       1
    y2        id31      200
    y2        id34      700
    y2        id36      300
    y2        id40      -300
    y2        id41      -100
    y2        id43      -500
    y2        id45      -50
    y2        id46      -250
    y2        id206     -500
    y2        id208     -400
    y2        id212     200
    y2        id215     200
    y2        id220     300
    y2        id225     -800
    y2        id227     -100
    y2        id231     200
    y2        id234     200
    y2        id236     200
    y2        id238     300
    y2        id243     -900
    y2        id245     -200
    y2        id249     100
    y2        id251     100
    y2        id254     100
    y2        id256     400
    y2        id258     300
    y2        id260     100
    y2        id265     -1000
    y2        id269     200
    y2        id272     200
    y2        id274     500
    y2        id278     -33.3339996337891
    y2        id279     133.333999633789
    y2        id284     -300
    y2        id286     -500
    y2        id290     200
    y2        id293     200
    y2        id295     300
    y2        id297     100
    y2        id302     -200
    y2        id304     -500
    y2        id306     -400
    y2        id308     -200
    y2        id312     200
    y2        id315     300
    y2        id317     200
    y2        id319     300
    y2        id322     300
    y2        id327     -300
    y2        id329     -500
    y2        id333     200
    y2        id336     600
    y3        OBJ       1
    y3        id51      700
    y3        id53      400
    y3        id57      -200
    y3        id60      -200
    y3        id62      -66.6659851074219
    y3        id63      -133.334014892578
    y3        id67      -60
    y3        id68      -40
    y3        id70      -200
    y3        id206     500
    y3        id208     400
    y3        id212     -200
    y3        id215     -200
    y3        id220     -300
    y3        id341     -200
    y3        id344     -500
    y3        id346     -100
    y3        id350     200
    y3        id352     600
    y3        id357     -200
    y3        id360     -600
    y3        id362     -200
    y3        id366     100
    y3        id368     800
    y3        id370     100
    y3        id373     -200
    y3        id380     200
    y3        id382     400
    y3        id384     200
    y3        id386     -100
    y3        id387     200
    y3        id390     -200
    y3        id393     -300
    y3        id395     -200
    y3        id399     200
    y3        id401     400
    y3        id403     100
    y3        id406     -200
    y3        id409     -200
    y3        id413     -400
    y3        id415     -200
    y3        id419     300
    y3        id421     600
    y3        id424     300
    y3        id427     -200
    y3        id430     -300
    y3        id436     400
    y3        id438     300
    y4        OBJ       1
    y4        id75      1000
    y4        id77      100
    y4        id81      -200
    y4        id83      -200
    y4        id84      -200
    y4        id86      -200
    y4        id88      -20
    y4        id89      -80
    y4        id91      -200
    y4        id225     800
    y4        id227     100
    y4        id231     -200
    y4        id234     -200
    y4        id236     -200
    y4        id238     -300
    y4        id341     200
    y4        id344     500
    y4        id346     100
    y4        id350     -200
    y4        id352     -600
    y4        id441     -400
    y4        id443     -200
    y4        id445     -200
    y4        id449     100
    y4        id451     300
    y4        id453     400
    y4        id455     200
    y4        id457     -200
    y4        id460     -200
    y4        id462     -500
    y4        id464     -200
    y4        id468     200
    y4        id470     300
    y4        id472     200
    y4        id474     100
    y4        id476     -66.6659851074219
    y4        id477     66.6659851074219
    y4        id479     100
    y4        id482     -200
    y4        id486     200
    y4        id488     300
    y4        id490     200
    y4        id492     -500
    y4        id495     -400
    y4        id497     -600
    y4        id499     -200
    y4        id503     300
    y4        id505     300
    y4        id507     200
    y4        id509     100
    y4        id512     200
    y4        id514     100
    y4        id517     -200
    y4        id521     300
    y4        id523     300
    y4        id525     100
    y4        id527     -500
    y5        OBJ       1
    y5        id96      1100
    y5        id98      200
    y5        id102     -100
    y5        id104     -200
    y5        id105     -200
    y5        id107     -250
    y5        id108     -50
    y5        id110     -400
    y5        id112     -100
    y5        id243     900
    y5        id245     200
    y5        id249     -100
    y5        id251     -100
    y5        id254     -100
    y5        id256     -400
    y5        id258     -300
    y5        id260     -100
    y5        id357     200
    y5        id360     600
    y5        id362     200
    y5        id366     -100
    y5        id368     -800
    y5        id370     -100
    y5        id441     400
    y5        id443     200
    y5        id445     200
    y5        id449     -100
    y5        id451     -300
    y5        id453     -400
    y5        id455     -200
    y5        id457     200
    y5        id530     -100
    y5        id532     -500
    y5        id534     -400
    y5        id536     -100
    y5        id540     200
    y5        id542     400
    y5        id544     400
    y5        id546     -100
    y5        id547     200
    y5        id550     -400
    y5        id552     -100
    y5        id556     200
    y5        id558     400
    y5        id560     200
    y5        id562     100
    y5        id564     -100
    y5        id566     -300
    y5        id569     -100
    y5        id571     -200
    y5        id573     -800
    y5        id575     -200
    y5        id577     -100
    y5        id579     300
    y5        id581     400
    y5        id583     200
    y5        id585     200
    y5        id588     100
    y5        id590     200
    y5        id593     -400
    y5        id595     -100
    y5        id599     400
    y5        id601     500
    y5        id603     -100
    y5        id605     -300
    y6        OBJ       1
    y6        id117     1200
    y6        id121     -200
    y6        id123     -200
    y6        id124     -200
    y6        id126     -166.666000366211
    y6        id127     -133.333999633789
    y6        id129     -200
    y6        id132     -100
    y6        id265     1000
    y6        id269     -200
    y6        id272     -200
    y6        id274     -500
    y6        id278     33.3339996337891
    y6        id279     -133.333999633789
    y6        id373     200
    y6        id380     -200
    y6        id382     -400
    y6        id384     -200
    y6        id386     100
    y6        id387     -200
    y6        id460     200
    y6        id462     500
    y6        id464     200
    y6        id468     -200
    y6        id470     -300
    y6        id472     -200
    y6        id474     -100
    y6        id476     66.6659851074219
    y6        id477     -66.6659851074219
    y6        id479     -100
    y6        id530     100
    y6        id532     500
    y6        id534     400
    y6        id536     100
    y6        id540     -200
    y6        id542     -400
    y6        id544     -400
    y6        id546     100
    y6        id547     -200
    y6        id608     -500
    y6        id610     -200
    y6        id613     -100
    y6        id617     200
    y6        id619     500
    y6        id621     100
    y6        id626     -400
    y6        id628     -400
    y6        id630     -400
    y6        id632     100
    y6        id633     -200
    y6        id635     300
    y6        id639     200
    y6        id642     100
    y6        id644     200
    y6        id649     -500
    y6        id651     -200
    y6        id654     -100
    y6        id658     500
    y6        id660     300
    y7        OBJ       1
    y7        id137     300
    y7        id139     700
    y7        id143     -200
    y7        id145     -133.333984375
    y7        id146     -66.666015625
    y7        id148     -200
    y7        id150     -100
    y7        id151     -200
    y7        id153     -100
    y7        id284     300
    y7        id286     500
    y7        id290     -200
    y7        id293     -200
    y7        id295     -300
    y7        id297     -100
    y7        id390     200
    y7        id393     300
    y7        id395     200
    y7        id399     -200
    y7        id401     -400
    y7        id403     -100
    y7        id482     200
    y7        id486     -200
    y7        id488     -300
    y7        id490     -200
    y7        id492     500
    y7        id550     400
    y7        id552     100
    y7        id556     -200
    y7        id558     -400
    y7        id560     -200
    y7        id562     -100
    y7        id564     100
    y7        id566     300
    y7        id608     500
    y7        id610     200
    y7        id613     100
    y7        id617     -200
    y7        id619     -500
    y7        id621     -100
    y7        id665     -200
    y7        id667     -200
    y7        id669     -400
    y7        id671     -200
    y7        id673     -100
    y7        id675     600
    y7        id677     200
    y7        id680     100
    y7        id682     200
    y7        id687     -100
    y7        id691     300
    y7        id693     300
    y7        id697     -300
    y7        id699     -200
    y8        OBJ       1
    y8        id158     200
    y8        id160     700
    y8        id162     400
    y8        id164     200
    y8        id168     -300
    y8        id170     -200
    y8        id171     -200
    y8        id173     -200
    y8        id175     -20
    y8        id176     -80
    y8        id178     -200
    y8        id181     -20
    y8        id182     -80
    y8        id184     -200
    y8        id302     200
    y8        id304     500
    y8        id306     400
    y8        id308     200
    y8        id312     -200
    y8        id315     -300
    y8        id317     -200
    y8        id319     -300
    y8        id322     -300
    y8        id406     200
    y8        id409     200
    y8        id413     400
    y8        id415     200
    y8        id419     -300
    y8        id421     -600
    y8        id424     -300
    y8        id495     400
    y8        id497     600
    y8        id499     200
    y8        id503     -300
    y8        id505     -300
    y8        id507     -200
    y8        id509     -100
    y8        id512     -200
    y8        id514     -100
    y8        id569     100
    y8        id571     200
    y8        id573     800
    y8        id575     200
    y8        id577     100
    y8        id579     -300
    y8        id581     -400
    y8        id583     -200
    y8        id585     -200
    y8        id588     -100
    y8        id590     -200
    y8        id626     400
    y8        id628     400
    y8        id630     400
    y8        id632     -100
    y8        id633     200
    y8        id635     -300
    y8        id639     -200
    y8        id642     -100
    y8        id644     -200
    y8        id665     200
    y8        id667     200
    y8        id669     400
    y8        id671     200
    y8        id673     100
    y8        id675     -600
    y8        id677     -200
    y8        id680     -100
    y8        id682     -200
    y8        id702     -600
    y8        id704     -200
    y8        id707     -100
    y8        id709     -200
    y8        id713     200
    y8        id715     400
    y8        id717     500
    y9        OBJ       1
    y9        id189     300
    y9        id191     700
    y9        id195     -200
    y9        id196     -200
    y9        id198     -166.666000366211
    y9        id199     -133.333999633789
    y9        id201     -300
    y9        id327     300
    y9        id329     500
    y9        id333     -200
    y9        id336     -600
    y9        id427     200
    y9        id430     300
    y9        id436     -400
    y9        id438     -300
    y9        id517     200
    y9        id521     -300
    y9        id523     -300
    y9        id525     -100
    y9        id527     500
    y9        id593     400
    y9        id595     100
    y9        id599     -400
    y9        id601     -500
    y9        id603     100
    y9        id605     300
    y9        id649     500
    y9        id651     200
    y9        id654     100
    y9        id658     -500
    y9        id660     -300
    y9        id687     100
    y9        id691     -300
    y9        id693     -300
    y9        id697     300
    y9        id699     200
    y9        id702     600
    y9        id704     200
    y9        id707     100
    y9        id709     200
    y9        id713     -200
    y9        id715     -400
    y9        id717     -500
    MARKER    'MARKER'                 'INTORG'
    z1&2.0    id34      280000
    z1&2.0    id31      180000
    z1&2.0    id32      8400000
    z1&2.0    id49      1
    z1&2.1    id31      200000
    z1&2.1    id34      840000
    z1&2.1    id49      1
    z1&2.2    id36      8400000
    z1&2.2    id49      1
    z1&2.3    id38      8400000
    z1&2.3    id49      1
    z1&2.4    id46      200000
    z1&2.4    id43      400000
    z1&2.4    id40      330000
    z1&2.4    id41      8400000
    z1&2.4    id49      1
    z1&2.5    id46      250000
    z1&2.5    id40      300000
    z1&2.5    id43      600000
    z1&2.5    id49      1
    z1&2.6    id43      400000
    z1&2.6    id40      240000
    z1&2.6    id45      8400000
    z1&2.6    id46      275000
    z1&2.6    id49      1
    z1&2.7    id48      8400000
    z1&2.7    id49      1
    z1&3.0    id51      840000
    z1&3.0    id73      1
    z1&3.1    id53      8400000
    z1&3.1    id73      1
    z1&3.2    id55      8400000
    z1&3.2    id73      1
    z1&3.3    id57      8400000
    z1&3.3    id58      8400000
    z1&3.3    id73      1
    z1&3.4    id70      200000
    z1&3.4    id60      220000
    z1&3.4    id73      1
    z1&3.5    id62      8400000
    z1&3.5    id63      8400000
    z1&3.5    id73      1
    z1&3.7    id67      8400000
    z1&3.7    id68      8400000
    z1&3.7    id73      1
    z1&3.8    id60      200000
    z1&3.8    id70      220000
    z1&3.8    id73      1
    z1&3.9    id72      8400000
    z1&3.9    id73      1
    z1&4.0    id75      1200000
    z1&4.0    id94      1
    z1&4.1    id77      8400000
    z1&4.1    id94      1
    z1&4.2    id79      8400000
    z1&4.2    id94      1
    z1&4.3    id81      8400000
    z1&4.3    id94      1
    z1&4.4    id83      8400000
    z1&4.4    id84      8400000
    z1&4.4    id94      1
    z1&4.5    id86      8400000
    z1&4.5    id94      1
    z1&4.6    id88      8400000
    z1&4.6    id89      8400000
    z1&4.6    id94      1
    z1&4.7    id91      8400000
    z1&4.7    id94      1
    z1&4.8    id93      8400000
    z1&4.8    id94      1
    z1&5.0    id96      1320000
    z1&5.0    id115     1
    z1&5.1    id98      8400000
    z1&5.1    id115     1
    z1&5.2    id100     8400000
    z1&5.2    id115     1
    z1&5.3    id102     8400000
    z1&5.3    id115     1
    z1&5.4    id104     8400000
    z1&5.4    id105     8400000
    z1&5.4    id115     1
    z1&5.5    id107     8400000
    z1&5.5    id108     8400000
    z1&5.5    id115     1
    z1&5.6    id110     8400000
    z1&5.6    id115     1
    z1&5.7    id112     8400000
    z1&5.7    id115     1
    z1&5.8    id114     8400000
    z1&5.8    id115     1
    z1&6.0    id117     1440000
    z1&6.0    id135     1
    z1&6.1    id119     8400000
    z1&6.1    id135     1
    z1&6.2    id121     8400000
    z1&6.2    id135     1
    z1&6.3    id123     8400000
    z1&6.3    id124     8400000
    z1&6.3    id135     1
    z1&6.4    id126     8400000
    z1&6.4    id127     8400000
    z1&6.4    id135     1
    z1&6.5    id129     8400000
    z1&6.5    id135     1
    z1&6.6    id131     8400000
    z1&6.6    id132     8400000
    z1&6.6    id135     1
    z1&6.7    id134     8400000
    z1&6.7    id135     1
    z1&7.0    id137     8400000
    z1&7.0    id156     1
    z1&7.1    id139     840000
    z1&7.1    id156     1
    z1&7.2    id141     8400000
    z1&7.2    id156     1
    z1&7.3    id143     8400000
    z1&7.3    id156     1
    z1&7.4    id145     8400000
    z1&7.4    id146     8400000
    z1&7.4    id156     1
    z1&7.5    id148     8400000
    z1&7.5    id156     1
    z1&7.6    id150     8400000
    z1&7.6    id151     8400000
    z1&7.6    id156     1
    z1&7.7    id153     8400000
    z1&7.7    id156     1
    z1&7.8    id155     8400000
    z1&7.8    id156     1
    z1&8.0    id158     8400000
    z1&8.0    id187     1
    z1&8.1    id160     840000
    z1&8.1    id187     1
    z1&8.2    id162     8400000
    z1&8.2    id187     1
    z1&8.3    id164     8400000
    z1&8.3    id187     1
    z1&8.4    id166     8400000
    z1&8.4    id187     1
    z1&8.5    id168     8400000
    z1&8.5    id187     1
    z1&8.6    id170     8400000
    z1&8.6    id171     8400000
    z1&8.6    id187     1
    z1&8.7    id173     8400000
    z1&8.7    id187     1
    z1&8.8    id175     8400000
    z1&8.8    id176     8400000
    z1&8.8    id187     1
    z1&8.9    id178     8400000
    z1&8.9    id187     1
    z1&8.10   id180     8400000
    z1&8.10   id181     8400000
    z1&8.10   id182     8400000
    z1&8.10   id187     1
    z1&8.11   id184     8400000
    z1&8.11   id187     1
    z1&8.12   id186     8400000
    z1&8.12   id187     1
    z1&9.0    id189     8400000
    z1&9.0    id204     1
    z1&9.1    id191     840000
    z1&9.1    id204     1
    z1&9.2    id193     8400000
    z1&9.2    id204     1
    z1&9.3    id195     8400000
    z1&9.3    id196     8400000
    z1&9.3    id204     1
    z1&9.4    id198     8400000
    z1&9.4    id199     8400000
    z1&9.4    id204     1
    z1&9.5    id201     8400000
    z1&9.5    id204     1
    z1&9.6    id203     8400000
    z1&9.6    id204     1
    z2&3.0    id206     600000
    z2&3.0    id223     1
    z2&3.1    id208     8400000
    z2&3.1    id223     1
    z2&3.2    id210     8400000
    z2&3.2    id223     1
    z2&3.3    id212     8400000
    z2&3.3    id213     8400000
    z2&3.3    id223     1
    z2&3.4    id215     180000
    z2&3.4    id216     8400000
    z2&3.4    id223     1
    z2&3.5    id215     240000
    z2&3.5    id223     1
    z2&3.6    id220     8400000
    z2&3.6    id223     1
    z2&3.7    id222     8400000
    z2&3.7    id223     1
    z2&4.0    id225     960000
    z2&4.0    id241     1
    z2&4.1    id227     8400000
    z2&4.1    id241     1
    z2&4.2    id229     8400000
    z2&4.2    id241     1
    z2&4.3    id231     8400000
    z2&4.3    id232     8400000
    z2&4.3    id241     1
    z2&4.4    id234     8400000
    z2&4.4    id241     1
    z2&4.5    id236     8400000
    z2&4.5    id241     1
    z2&4.6    id238     8400000
    z2&4.6    id241     1
    z2&4.7    id240     8400000
    z2&4.7    id241     1
    z2&5.0    id243     1080000
    z2&5.0    id263     1
    z2&5.1    id245     8400000
    z2&5.1    id263     1
    z2&5.2    id247     8400000
    z2&5.2    id263     1
    z2&5.3    id249     8400000
    z2&5.3    id263     1
    z2&5.4    id251     90000
    z2&5.4    id252     8400000
    z2&5.4    id263     1
    z2&5.5    id254     8400000
    z2&5.5    id263     1
    z2&5.6    id256     8400000
    z2&5.6    id263     1
    z2&5.7    id258     8400000
    z2&5.7    id263     1
    z2&5.8    id260     8400000
    z2&5.8    id263     1
    z2&5.9    id262     8400000
    z2&5.9    id263     1
    z2&6.0    id265     1200000
    z2&6.0    id282     1
    z2&6.1    id267     8400000
    z2&6.1    id282     1
    z2&6.2    id269     8400000
    z2&6.2    id270     8400000
    z2&6.2    id282     1
    z2&6.3    id272     8400000
    z2&6.3    id282     1
    z2&6.4    id274     8400000
    z2&6.4    id282     1
    z2&6.5    id276     8400000
    z2&6.5    id282     1
    z2&6.6    id278     8400000
    z2&6.6    id279     8400000
    z2&6.6    id282     1
    z2&6.7    id281     8400000
    z2&6.7    id282     1
    z2&7.0    id284     8400000
    z2&7.0    id300     1
    z2&7.1    id286     600000
    z2&7.1    id300     1
    z2&7.2    id288     8400000
    z2&7.2    id300     1
    z2&7.3    id290     8400000
    z2&7.3    id291     8400000
    z2&7.3    id300     1
    z2&7.4    id293     8400000
    z2&7.4    id300     1
    z2&7.5    id295     8400000
    z2&7.5    id300     1
    z2&7.6    id297     8400000
    z2&7.6    id300     1
    z2&7.7    id299     8400000
    z2&7.7    id300     1
    z2&8.0    id302     8400000
    z2&8.0    id325     1
    z2&8.1    id304     600000
    z2&8.1    id325     1
    z2&8.2    id306     8400000
    z2&8.2    id325     1
    z2&8.3    id308     8400000
    z2&8.3    id325     1
    z2&8.4    id310     8400000
    z2&8.4    id325     1
    z2&8.5    id312     8400000
    z2&8.5    id313     8400000
    z2&8.5    id325     1
    z2&8.6    id315     8400000
    z2&8.6    id325     1
    z2&8.7    id317     8400000
    z2&8.7    id325     1
    z2&8.8    id319     8400000
    z2&8.8    id325     1
    z2&8.9    id321     8400000
    z2&8.9    id322     8400000
    z2&8.9    id325     1
    z2&8.10   id324     8400000
    z2&8.10   id325     1
    z2&9.0    id327     8400000
    z2&9.0    id339     1
    z2&9.1    id329     600000
    z2&9.1    id339     1
    z2&9.2    id331     8400000
    z2&9.2    id339     1
    z2&9.3    id333     180000
    z2&9.3    id334     8400000
    z2&9.3    id339     1
    z2&9.4    id336     8400000
    z2&9.4    id339     1
    z2&9.5    id338     8400000
    z2&9.5    id339     1
    z3&4.0    id341     8400000
    z3&4.0    id342     8400000
    z3&4.0    id355     1
    z3&4.1    id344     600000
    z3&4.1    id355     1
    z3&4.2    id346     8400000
    z3&4.2    id355     1
    z3&4.3    id348     8400000
    z3&4.3    id355     1
    z3&4.4    id350     8400000
    z3&4.4    id355     1
    z3&4.5    id352     8400000
    z3&4.5    id355     1
    z3&4.6    id354     8400000
    z3&4.6    id355     1
    z3&5.0    id357     8400000
    z3&5.0    id358     8400000
    z3&5.0    id371     1
    z3&5.1    id360     720000
    z3&5.1    id371     1
    z3&5.2    id362     8400000
    z3&5.2    id371     1
    z3&5.3    id364     8400000
    z3&5.3    id371     1
    z3&5.4    id366     8400000
    z3&5.4    id371     1
    z3&5.5    id368     8400000
    z3&5.5    id371     1
    z3&5.6    id370     8400000
    z3&5.6    id371     1
    z3&6.0    id373     8400000
    z3&6.0    id374     8400000
    z3&6.0    id388     1
    z3&6.2    id378     8400000
    z3&6.2    id388     1
    z3&6.3    id380     8400000
    z3&6.3    id388     1
    z3&6.4    id382     8400000
    z3&6.4    id388     1
    z3&6.5    id384     8400000
    z3&6.5    id388     1
    z3&6.6    id386     8400000
    z3&6.6    id387     8400000
    z3&6.6    id388     1
    z3&7.0    id390     8400000
    z3&7.0    id391     8400000
    z3&7.0    id404     1
    z3&7.1    id393     8400000
    z3&7.1    id404     1
    z3&7.2    id395     240000
    z3&7.2    id404     1
    z3&7.3    id397     8400000
    z3&7.3    id404     1
    z3&7.4    id399     8400000
    z3&7.4    id404     1
    z3&7.5    id401     8400000
    z3&7.5    id404     1
    z3&7.6    id403     8400000
    z3&7.6    id404     1
    z3&8.0    id406     8400000
    z3&8.0    id407     8400000
    z3&8.0    id425     1
    z3&8.1    id409     8400000
    z3&8.1    id425     1
    z3&8.3    id413     8400000
    z3&8.3    id425     1
    z3&8.4    id415     8400000
    z3&8.4    id425     1
    z3&8.5    id417     8400000
    z3&8.5    id425     1
    z3&8.6    id419     8400000
    z3&8.6    id425     1
    z3&8.7    id421     8400000
    z3&8.7    id425     1
    z3&8.8    id423     8400000
    z3&8.8    id424     8400000
    z3&8.8    id425     1
    z3&9.0    id427     8400000
    z3&9.0    id428     8400000
    z3&9.0    id439     1
    z3&9.1    id430     8400000
    z3&9.1    id439     1
    z3&9.3    id434     8400000
    z3&9.3    id439     1
    z3&9.4    id436     8400000
    z3&9.4    id439     1
    z3&9.5    id438     8400000
    z3&9.5    id439     1
    z4&5.0    id441     480000
    z4&5.0    id458     1
    z4&5.1    id443     8400000
    z4&5.1    id458     1
    z4&5.2    id445     8400000
    z4&5.2    id458     1
    z4&5.3    id447     8400000
    z4&5.3    id458     1
    z4&5.4    id449     8400000
    z4&5.4    id458     1
    z4&5.5    id451     360000
    z4&5.5    id458     1
    z4&5.6    id453     8400000
    z4&5.6    id458     1
    z4&5.7    id455     8400000
    z4&5.7    id458     1
    z4&5.8    id457     8400000
    z4&5.8    id458     1
    z4&6.0    id460     8400000
    z4&6.0    id480     1
    z4&6.1    id462     600000
    z4&6.1    id480     1
    z4&6.2    id464     8400000
    z4&6.2    id480     1
    z4&6.3    id466     8400000
    z4&6.3    id480     1
    z4&6.4    id468     8400000
    z4&6.4    id480     1
    z4&6.5    id470     360000
    z4&6.5    id480     1
    z4&6.6    id472     8400000
    z4&6.6    id480     1
    z4&6.7    id474     8400000
    z4&6.7    id480     1
    z4&6.8    id476     8400000
    z4&6.8    id477     8400000
    z4&6.8    id480     1
    z4&6.9    id479     8400000
    z4&6.9    id480     1
    z4&7.0    id482     8400000
    z4&7.0    id493     1
    z4&7.1    id484     8400000
    z4&7.1    id493     1
    z4&7.2    id486     8400000
    z4&7.2    id493     1
    z4&7.3    id488     360000
    z4&7.3    id493     1
    z4&7.4    id490     8400000
    z4&7.4    id493     1
    z4&7.5    id492     8400000
    z4&7.5    id493     1
    z4&8.0    id495     8400000
    z4&8.0    id515     1
    z4&8.1    id497     8400000
    z4&8.1    id515     1
    z4&8.2    id499     8400000
    z4&8.2    id515     1
    z4&8.3    id501     8400000
    z4&8.3    id515     1
    z4&8.4    id503     8400000
    z4&8.4    id515     1
    z4&8.5    id505     360000
    z4&8.5    id515     1
    z4&8.6    id507     8400000
    z4&8.6    id515     1
    z4&8.7    id509     8400000
    z4&8.7    id515     1
    z4&8.8    id511     8400000
    z4&8.8    id512     8400000
    z4&8.8    id515     1
    z4&8.9    id514     8400000
    z4&8.9    id515     1
    z4&9.0    id517     8400000
    z4&9.0    id528     1
    z4&9.1    id519     8400000
    z4&9.1    id528     1
    z4&9.2    id521     360000
    z4&9.2    id528     1
    z4&9.3    id523     8400000
    z4&9.3    id528     1
    z4&9.4    id525     8400000
    z4&9.4    id528     1
    z4&9.5    id527     8400000
    z4&9.5    id528     1
    z5&6.0    id530     8400000
    z5&6.0    id548     1
    z5&6.1    id532     600000
    z5&6.1    id548     1
    z5&6.2    id534     8400000
    z5&6.2    id548     1
    z5&6.3    id536     8400000
    z5&6.3    id548     1
    z5&6.4    id538     8400000
    z5&6.4    id548     1
    z5&6.5    id540     8400000
    z5&6.5    id548     1
    z5&6.6    id542     480000
    z5&6.6    id548     1
    z5&6.7    id544     8400000
    z5&6.7    id548     1
    z5&6.8    id546     8400000
    z5&6.8    id547     8400000
    z5&6.8    id548     1
    z5&7.0    id550     8400000
    z5&7.0    id567     1
    z5&7.1    id552     8400000
    z5&7.1    id567     1
    z5&7.2    id554     8400000
    z5&7.2    id567     1
    z5&7.3    id556     8400000
    z5&7.3    id567     1
    z5&7.4    id558     480000
    z5&7.4    id567     1
    z5&7.5    id560     8400000
    z5&7.5    id567     1
    z5&7.6    id562     8400000
    z5&7.6    id567     1
    z5&7.7    id564     8400000
    z5&7.7    id567     1
    z5&7.8    id566     8400000
    z5&7.8    id567     1
    z5&8.0    id569     8400000
    z5&8.0    id591     1
    z5&8.1    id571     8400000
    z5&8.1    id591     1
    z5&8.2    id573     8400000
    z5&8.2    id591     1
    z5&8.3    id575     8400000
    z5&8.3    id591     1
    z5&8.4    id577     8400000
    z5&8.4    id591     1
    z5&8.5    id579     8400000
    z5&8.5    id591     1
    z5&8.6    id581     480000
    z5&8.6    id591     1
    z5&8.7    id583     8400000
    z5&8.7    id591     1
    z5&8.8    id585     8400000
    z5&8.8    id591     1
    z5&8.9    id587     8400000
    z5&8.9    id588     8400000
    z5&8.9    id591     1
    z5&8.10   id590     8400000
    z5&8.10   id591     1
    z5&9.0    id593     8400000
    z5&9.0    id606     1
    z5&9.1    id595     8400000
    z5&9.1    id606     1
    z5&9.2    id597     8400000
    z5&9.2    id606     1
    z5&9.3    id599     480000
    z5&9.3    id606     1
    z5&9.4    id601     8400000
    z5&9.4    id606     1
    z5&9.5    id603     8400000
    z5&9.5    id606     1
    z5&9.6    id605     8400000
    z5&9.6    id606     1
    z6&7.0    id608     8400000
    z6&7.0    id624     1
    z6&7.1    id610     8400000
    z6&7.1    id624     1
    z6&7.2    id612     8400000
    z6&7.2    id613     8400000
    z6&7.2    id624     1
    z6&7.3    id615     8400000
    z6&7.3    id624     1
    z6&7.4    id617     8400000
    z6&7.4    id624     1
    z6&7.5    id619     600000
    z6&7.5    id624     1
    z6&7.6    id621     8400000
    z6&7.6    id624     1
    z6&7.7    id623     8400000
    z6&7.7    id624     1
    z6&8.0    id626     8400000
    z6&8.0    id647     1
    z6&8.1    id628     8400000
    z6&8.1    id647     1
    z6&8.2    id630     8400000
    z6&8.2    id647     1
    z6&8.3    id632     8400000
    z6&8.3    id633     8400000
    z6&8.3    id647     1
    z6&8.4    id635     8400000
    z6&8.4    id647     1
    z6&8.6    id639     8400000
    z6&8.6    id647     1
    z6&8.7    id641     8400000
    z6&8.7    id642     80000
    z6&8.7    id647     1
    z6&8.8    id644     8400000
    z6&8.8    id647     1
    z6&8.9    id646     8400000
    z6&8.9    id647     1
    z6&9.0    id649     8400000
    z6&9.0    id663     1
    z6&9.1    id651     8400000
    z6&9.1    id663     1
    z6&9.2    id653     8400000
    z6&9.2    id654     8400000
    z6&9.2    id663     1
    z6&9.3    id656     8400000
    z6&9.3    id663     1
    z6&9.4    id658     600000
    z6&9.4    id663     1
    z6&9.5    id660     8400000
    z6&9.5    id663     1
    z6&9.6    id662     8400000
    z6&9.6    id663     1
    z7&8.0    id665     8400000
    z7&8.0    id685     1
    z7&8.1    id667     8400000
    z7&8.1    id685     1
    z7&8.2    id669     8400000
    z7&8.2    id685     1
    z7&8.3    id671     8400000
    z7&8.3    id685     1
    z7&8.4    id673     8400000
    z7&8.4    id685     1
    z7&8.5    id675     8400000
    z7&8.5    id685     1
    z7&8.6    id677     8400000
    z7&8.6    id685     1
    z7&8.7    id679     8400000
    z7&8.7    id680     8400000
    z7&8.7    id685     1
    z7&8.8    id682     8400000
    z7&8.8    id685     1
    z7&8.9    id684     8400000
    z7&8.9    id685     1
    z7&9.0    id687     8400000
    z7&9.0    id700     1
    z7&9.1    id689     8400000
    z7&9.1    id700     1
    z7&9.2    id691     8400000
    z7&9.2    id700     1
    z7&9.3    id693     8400000
    z7&9.3    id700     1
    z7&9.4    id695     8400000
    z7&9.4    id700     1
    z7&9.5    id697     8400000
    z7&9.5    id700     1
    z7&9.6    id699     8400000
    z7&9.6    id700     1
    z8&9.0    id702     8400000
    z8&9.0    id718     1
    z8&9.1    id704     8400000
    z8&9.1    id718     1
    z8&9.2    id706     8400000
    z8&9.2    id707     8400000
    z8&9.2    id718     1
    z8&9.3    id709     8400000
    z8&9.3    id718     1
    z8&9.4    id711     8400000
    z8&9.4    id718     1
    z8&9.5    id713     8400000
    z8&9.5    id718     1
    z8&9.6    id715     8400000
    z8&9.6    id718     1
    z8&9.7    id717     8400000
    z8&9.7    id718     1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      id21      -700
    RHS1      id22      -500
    RHS1      id23      -200
    RHS1      id24      -200
    RHS1      id25      -500
    RHS1      id26      -300
    RHS1      id27      -100
    RHS1      id28      -500
    RHS1      id29      -300
    RHS1      id31      140000
    RHS1      id32      8310000
    RHS1      id34      490000
    RHS1      id36      8130000
    RHS1      id38      7980000
    RHS1      id40      210000
    RHS1      id41      8320000
    RHS1      id43      350000
    RHS1      id45      8355000
    RHS1      id46      175000
    RHS1      id48      8100000
    RHS1      id49      1
    RHS1      id51      350000
    RHS1      id53      8020000
    RHS1      id55      8040000
    RHS1      id57      8240000
    RHS1      id58      8190000
    RHS1      id60      140000
    RHS1      id62      8390000.61328125
    RHS1      id63      8293332.7890625
    RHS1      id67      8382000
    RHS1      id68      8384000
    RHS1      id70      140000
    RHS1      id72      8180000
    RHS1      id73      1
    RHS1      id75      800000
    RHS1      id77      8200000
    RHS1      id79      8040000
    RHS1      id81      8180000
    RHS1      id83      8390000
    RHS1      id84      8240000
    RHS1      id86      8330000
    RHS1      id88      8396000
    RHS1      id89      8368000
    RHS1      id91      8320000
    RHS1      id93      8260000
    RHS1      id94      1
    RHS1      id96      880000
    RHS1      id98      8200000
    RHS1      id100     8080000
    RHS1      id102     8220000
    RHS1      id104     8390000
    RHS1      id105     8240000
    RHS1      id107     8312500
    RHS1      id108     8380000
    RHS1      id110     8240000
    RHS1      id112     8300000
    RHS1      id114     8200000
    RHS1      id115     1
    RHS1      id117     720000
    RHS1      id119     7680000
    RHS1      id121     8180000
    RHS1      id123     8390000
    RHS1      id124     8240000
    RHS1      id126     8366666.79492188
    RHS1      id127     8346666.40039062
    RHS1      id129     8320000
    RHS1      id131     8340000
    RHS1      id132     8390000
    RHS1      id134     8280000
    RHS1      id135     1
    RHS1      id137     8310000
    RHS1      id139     490000
    RHS1      id141     7680000
    RHS1      id143     8250000
    RHS1      id145     8393332.59570312
    RHS1      id146     8340000.6015625
    RHS1      id148     8270000
    RHS1      id150     8410000
    RHS1      id151     8320000
    RHS1      id153     8360000
    RHS1      id155     8360000
    RHS1      id156     1
    RHS1      id158     8200000
    RHS1      id160     350000
    RHS1      id162     8040000
    RHS1      id164     8140000
    RHS1      id166     8000000
    RHS1      id168     8070000
    RHS1      id170     8390000
    RHS1      id171     8240000
    RHS1      id173     8330000
    RHS1      id175     8396000
    RHS1      id176     8368000
    RHS1      id178     8320000
    RHS1      id180     8340000
    RHS1      id181     8392000
    RHS1      id182     8412000
    RHS1      id184     8370000
    RHS1      id186     8200000
    RHS1      id187     1
    RHS1      id189     8220000
    RHS1      id191     420000
    RHS1      id193     7700000
    RHS1      id195     8390000
    RHS1      id196     8240000
    RHS1      id198     8366666.79492188
    RHS1      id199     8346666.40039062
    RHS1      id201     8280000
    RHS1      id203     8280000
    RHS1      id204     1
    RHS1      id206     250000
    RHS1      id208     8060000
    RHS1      id210     8260000
    RHS1      id212     8320000
    RHS1      id213     8250000
    RHS1      id215     140000
    RHS1      id216     8310000
    RHS1      id220     8280000
    RHS1      id222     8220000
    RHS1      id223     1
    RHS1      id225     640000
    RHS1      id227     8240000
    RHS1      id229     8260000
    RHS1      id231     8260000
    RHS1      id232     8350000
    RHS1      id234     8240000
    RHS1      id236     8330000
    RHS1      id238     8310000
    RHS1      id240     8300000
    RHS1      id241     1
    RHS1      id243     720000
    RHS1      id245     8240000
    RHS1      id247     8280000
    RHS1      id249     8280000
    RHS1      id251     70000
    RHS1      id252     8360000
    RHS1      id254     8290000
    RHS1      id256     8260000
    RHS1      id258     8280000
    RHS1      id260     8320000
    RHS1      id262     8300000
    RHS1      id263     1
    RHS1      id265     600000
    RHS1      id267     7980000
    RHS1      id269     8260000
    RHS1      id270     8350000
    RHS1      id272     8240000
    RHS1      id274     8300000
    RHS1      id276     8360000
    RHS1      id278     8380000.00390625
    RHS1      id279     8413333.39453125
    RHS1      id281     8340000
    RHS1      id282     1
    RHS1      id284     8310000
    RHS1      id286     350000
    RHS1      id288     7980000
    RHS1      id290     8310000
    RHS1      id291     8300000
    RHS1      id293     8270000
    RHS1      id295     8340000
    RHS1      id297     8380000
    RHS1      id299     8380000
    RHS1      id300     1
    RHS1      id302     8200000
    RHS1      id304     250000
    RHS1      id306     8080000
    RHS1      id308     8180000
    RHS1      id310     8240000
    RHS1      id312     8260000
    RHS1      id313     8340000
    RHS1      id315     8160000
    RHS1      id317     8330000
    RHS1      id319     8310000
    RHS1      id321     8380000
    RHS1      id322     8340000
    RHS1      id324     8300000
    RHS1      id325     1
    RHS1      id327     8220000
    RHS1      id329     300000
    RHS1      id331     8000000
    RHS1      id333     140000
    RHS1      id334     8310000
    RHS1      id336     8280000
    RHS1      id338     8340000
    RHS1      id339     1
    RHS1      id341     8340000
    RHS1      id342     8340000
    RHS1      id344     400000
    RHS1      id346     8300000
    RHS1      id348     8120000
    RHS1      id350     8220000
    RHS1      id352     8040000
    RHS1      id354     8280000
    RHS1      id355     1
    RHS1      id357     8280000
    RHS1      id358     8250000
    RHS1      id360     480000
    RHS1      id362     8300000
    RHS1      id364     8190000
    RHS1      id366     8290000
    RHS1      id368     7920000
    RHS1      id370     8250000
    RHS1      id371     1
    RHS1      id373     8280000
    RHS1      id374     8310000
    RHS1      id378     7960000
    RHS1      id380     8220000
    RHS1      id382     8160000
    RHS1      id384     8260000
    RHS1      id386     8350000
    RHS1      id387     8320000
    RHS1      id388     1
    RHS1      id390     8400000
    RHS1      id391     8370000
    RHS1      id393     8310000
    RHS1      id395     140000
    RHS1      id397     7960000
    RHS1      id399     8240000
    RHS1      id401     8160000
    RHS1      id403     8310000
    RHS1      id404     1
    RHS1      id406     8260000
    RHS1      id407     8250000
    RHS1      id409     8200000
    RHS1      id413     8140000
    RHS1      id415     8240000
    RHS1      id417     8050000
    RHS1      id419     8130000
    RHS1      id421     8040000
    RHS1      id423     8300000
    RHS1      id424     8295000
    RHS1      id425     1
    RHS1      id427     8340000
    RHS1      id428     8310000
    RHS1      id430     8220000
    RHS1      id434     8140000
    RHS1      id436     8160000
    RHS1      id438     8190000
    RHS1      id439     1
    RHS1      id441     320000
    RHS1      id443     8330000
    RHS1      id445     8320000
    RHS1      id447     8310000
    RHS1      id449     8320000
    RHS1      id451     240000
    RHS1      id453     8220000
    RHS1      id455     8160000
    RHS1      id457     8220000
    RHS1      id458     1
    RHS1      id460     8220000
    RHS1      id462     300000
    RHS1      id464     8260000
    RHS1      id466     8120000
    RHS1      id468     8280000
    RHS1      id470     240000
    RHS1      id472     8300000
    RHS1      id474     8320000
    RHS1      id476     8346666.40039062
    RHS1      id477     8386666.796875
    RHS1      id479     8340000
    RHS1      id480     1
    RHS1      id482     8280000
    RHS1      id484     8120000
    RHS1      id486     8300000
    RHS1      id488     240000
    RHS1      id490     8280000
    RHS1      id492     8250000
    RHS1      id493     1
    RHS1      id495     8000000
    RHS1      id497     8070000
    RHS1      id499     8260000
    RHS1      id501     8250000
    RHS1      id503     8220000
    RHS1      id505     240000
    RHS1      id507     8310000
    RHS1      id509     8310000
    RHS1      id511     8360000
    RHS1      id512     8360000
    RHS1      id514     8290000
    RHS1      id515     1
    RHS1      id517     8280000
    RHS1      id519     8220000
    RHS1      id521     240000
    RHS1      id523     8250000
    RHS1      id525     8310000
    RHS1      id527     8100000
    RHS1      id528     1
    RHS1      id530     8280000
    RHS1      id532     300000
    RHS1      id534     8120000
    RHS1      id536     8240000
    RHS1      id538     8120000
    RHS1      id540     8220000
    RHS1      id542     320000
    RHS1      id544     8280000
    RHS1      id546     8340000
    RHS1      id547     8400000
    RHS1      id548     1
    RHS1      id550     8160000
    RHS1      id552     8250000
    RHS1      id554     8120000
    RHS1      id556     8270000
    RHS1      id558     320000
    RHS1      id560     8340000
    RHS1      id562     8360000
    RHS1      id564     8360000
    RHS1      id566     8310000
    RHS1      id567     1
    RHS1      id569     8250000
    RHS1      id571     8200000
    RHS1      id573     7960000
    RHS1      id575     8240000
    RHS1      id577     8250000
    RHS1      id579     8130000
    RHS1      id581     320000
    RHS1      id583     8330000
    RHS1      id585     8320000
    RHS1      id587     8355000
    RHS1      id588     8390000
    RHS1      id590     8340000
    RHS1      id591     1
    RHS1      id593     8160000
    RHS1      id595     8280000
    RHS1      id597     8100000
    RHS1      id599     320000
    RHS1      id601     8250000
    RHS1      id603     8310000
    RHS1      id605     8220000
    RHS1      id606     1
    RHS1      id608     8250000
    RHS1      id610     8260000
    RHS1      id612     8280000
    RHS1      id613     8360000
    RHS1      id615     8200000
    RHS1      id617     8250000
    RHS1      id619     300000
    RHS1      id621     8300000
    RHS1      id623     8280000
    RHS1      id624     1
    RHS1      id626     8000000
    RHS1      id628     8180000
    RHS1      id630     8160000
    RHS1      id632     8310000
    RHS1      id633     8340000
    RHS1      id635     8130000
    RHS1      id639     8260000
    RHS1      id641     8280000
    RHS1      id642     60000
    RHS1      id644     8310000
    RHS1      id646     8120000
    RHS1      id647     1
    RHS1      id649     8100000
    RHS1      id651     8280000
    RHS1      id653     8340000
    RHS1      id654     8370000
    RHS1      id656     8220000
    RHS1      id658     300000
    RHS1      id660     8160000
    RHS1      id662     8200000
    RHS1      id663     1
    RHS1      id665     8180000
    RHS1      id667     8230000
    RHS1      id669     8180000
    RHS1      id671     8280000
    RHS1      id673     8310000
    RHS1      id675     8220000
    RHS1      id677     8280000
    RHS1      id679     8240000
    RHS1      id680     8440000
    RHS1      id682     8330000
    RHS1      id684     8120000
    RHS1      id685     1
    RHS1      id687     8340000
    RHS1      id689     8340000
    RHS1      id691     8310000
    RHS1      id693     8190000
    RHS1      id695     8200000
    RHS1      id697     8190000
    RHS1      id699     8280000
    RHS1      id700     1
    RHS1      id702     8040000
    RHS1      id704     8280000
    RHS1      id706     8320000
    RHS1      id707     8410000
    RHS1      id709     8330000
    RHS1      id711     8100000
    RHS1      id713     8200000
    RHS1      id715     8180000
    RHS1      id717     8100000
    RHS1      id718     1
BOUNDS
 LO BND1      x3        200
 LO BND1      x4        200
 LO BND1      x5        100
 LO BND1      x6        200
 LO BND1      x7        200
 LO BND1      x8        300
 LO BND1      lung      800
 UP BND1      y1        700
 UP BND1      y2        700
 UP BND1      y3        500
 UP BND1      y4        800
 UP BND1      y5        800
 UP BND1      y6        600
 UP BND1      y7        700
 UP BND1      y8        500
 UP BND1      y9        600
 BV BND1      z1&2.0  
 BV BND1      z1&2.1  
 BV BND1      z1&2.2  
 BV BND1      z1&2.3  
 BV BND1      z1&2.4  
 BV BND1      z1&2.5  
 BV BND1      z1&2.6  
 BV BND1      z1&2.7  
 BV BND1      z1&3.0  
 BV BND1      z1&3.1  
 BV BND1      z1&3.2  
 BV BND1      z1&3.3  
 BV BND1      z1&3.4  
 BV BND1      z1&3.5  
 BV BND1      z1&3.7  
 BV BND1      z1&3.8  
 BV BND1      z1&3.9  
 BV BND1      z1&4.0  
 BV BND1      z1&4.1  
 BV BND1      z1&4.2  
 BV BND1      z1&4.3  
 BV BND1      z1&4.4  
 BV BND1      z1&4.5  
 BV BND1      z1&4.6  
 BV BND1      z1&4.7  
 BV BND1      z1&4.8  
 BV BND1      z1&5.0  
 BV BND1      z1&5.1  
 BV BND1      z1&5.2  
 BV BND1      z1&5.3  
 BV BND1      z1&5.4  
 BV BND1      z1&5.5  
 BV BND1      z1&5.6  
 BV BND1      z1&5.7  
 BV BND1      z1&5.8  
 BV BND1      z1&6.0  
 BV BND1      z1&6.1  
 BV BND1      z1&6.2  
 BV BND1      z1&6.3  
 BV BND1      z1&6.4  
 BV BND1      z1&6.5  
 BV BND1      z1&6.6  
 BV BND1      z1&6.7  
 BV BND1      z1&7.0  
 BV BND1      z1&7.1  
 BV BND1      z1&7.2  
 BV BND1      z1&7.3  
 BV BND1      z1&7.4  
 BV BND1      z1&7.5  
 BV BND1      z1&7.6  
 BV BND1      z1&7.7  
 BV BND1      z1&7.8  
 BV BND1      z1&8.0  
 BV BND1      z1&8.1  
 BV BND1      z1&8.2  
 BV BND1      z1&8.3  
 BV BND1      z1&8.4  
 BV BND1      z1&8.5  
 BV BND1      z1&8.6  
 BV BND1      z1&8.7  
 BV BND1      z1&8.8  
 BV BND1      z1&8.9  
 BV BND1      z1&8.10 
 BV BND1      z1&8.11 
 BV BND1      z1&8.12 
 BV BND1      z1&9.0  
 BV BND1      z1&9.1  
 BV BND1      z1&9.2  
 BV BND1      z1&9.3  
 BV BND1      z1&9.4  
 BV BND1      z1&9.5  
 BV BND1      z1&9.6  
 BV BND1      z2&3.0  
 BV BND1      z2&3.1  
 BV BND1      z2&3.2  
 BV BND1      z2&3.3  
 BV BND1      z2&3.4  
 BV BND1      z2&3.5  
 BV BND1      z2&3.6  
 BV BND1      z2&3.7  
 BV BND1      z2&4.0  
 BV BND1      z2&4.1  
 BV BND1      z2&4.2  
 BV BND1      z2&4.3  
 BV BND1      z2&4.4  
 BV BND1      z2&4.5  
 BV BND1      z2&4.6  
 BV BND1      z2&4.7  
 BV BND1      z2&5.0  
 BV BND1      z2&5.1  
 BV BND1      z2&5.2  
 BV BND1      z2&5.3  
 BV BND1      z2&5.4  
 BV BND1      z2&5.5  
 BV BND1      z2&5.6  
 BV BND1      z2&5.7  
 BV BND1      z2&5.8  
 BV BND1      z2&5.9  
 BV BND1      z2&6.0  
 BV BND1      z2&6.1  
 BV BND1      z2&6.2  
 BV BND1      z2&6.3  
 BV BND1      z2&6.4  
 BV BND1      z2&6.5  
 BV BND1      z2&6.6  
 BV BND1      z2&6.7  
 BV BND1      z2&7.0  
 BV BND1      z2&7.1  
 BV BND1      z2&7.2  
 BV BND1      z2&7.3  
 BV BND1      z2&7.4  
 BV BND1      z2&7.5  
 BV BND1      z2&7.6  
 BV BND1      z2&7.7  
 BV BND1      z2&8.0  
 BV BND1      z2&8.1  
 BV BND1      z2&8.2  
 BV BND1      z2&8.3  
 BV BND1      z2&8.4  
 BV BND1      z2&8.5  
 BV BND1      z2&8.6  
 BV BND1      z2&8.7  
 BV BND1      z2&8.8  
 BV BND1      z2&8.9  
 BV BND1      z2&8.10 
 BV BND1      z2&9.0  
 BV BND1      z2&9.1  
 BV BND1      z2&9.2  
 BV BND1      z2&9.3  
 BV BND1      z2&9.4  
 BV BND1      z2&9.5  
 BV BND1      z3&4.0  
 BV BND1      z3&4.1  
 BV BND1      z3&4.2  
 BV BND1      z3&4.3  
 BV BND1      z3&4.4  
 BV BND1      z3&4.5  
 BV BND1      z3&4.6  
 BV BND1      z3&5.0  
 BV BND1      z3&5.1  
 BV BND1      z3&5.2  
 BV BND1      z3&5.3  
 BV BND1      z3&5.4  
 BV BND1      z3&5.5  
 BV BND1      z3&5.6  
 BV BND1      z3&6.0  
 BV BND1      z3&6.2  
 BV BND1      z3&6.3  
 BV BND1      z3&6.4  
 BV BND1      z3&6.5  
 BV BND1      z3&6.6  
 BV BND1      z3&7.0  
 BV BND1      z3&7.1  
 BV BND1      z3&7.2  
 BV BND1      z3&7.3  
 BV BND1      z3&7.4  
 BV BND1      z3&7.5  
 BV BND1      z3&7.6  
 BV BND1      z3&8.0  
 BV BND1      z3&8.1  
 BV BND1      z3&8.3  
 BV BND1      z3&8.4  
 BV BND1      z3&8.5  
 BV BND1      z3&8.6  
 BV BND1      z3&8.7  
 BV BND1      z3&8.8  
 BV BND1      z3&9.0  
 BV BND1      z3&9.1  
 BV BND1      z3&9.3  
 BV BND1      z3&9.4  
 BV BND1      z3&9.5  
 BV BND1      z4&5.0  
 BV BND1      z4&5.1  
 BV BND1      z4&5.2  
 BV BND1      z4&5.3  
 BV BND1      z4&5.4  
 BV BND1      z4&5.5  
 BV BND1      z4&5.6  
 BV BND1      z4&5.7  
 BV BND1      z4&5.8  
 BV BND1      z4&6.0  
 BV BND1      z4&6.1  
 BV BND1      z4&6.2  
 BV BND1      z4&6.3  
 BV BND1      z4&6.4  
 BV BND1      z4&6.5  
 BV BND1      z4&6.6  
 BV BND1      z4&6.7  
 BV BND1      z4&6.8  
 BV BND1      z4&6.9  
 BV BND1      z4&7.0  
 BV BND1      z4&7.1  
 BV BND1      z4&7.2  
 BV BND1      z4&7.3  
 BV BND1      z4&7.4  
 BV BND1      z4&7.5  
 BV BND1      z4&8.0  
 BV BND1      z4&8.1  
 BV BND1      z4&8.2  
 BV BND1      z4&8.3  
 BV BND1      z4&8.4  
 BV BND1      z4&8.5  
 BV BND1      z4&8.6  
 BV BND1      z4&8.7  
 BV BND1      z4&8.8  
 BV BND1      z4&8.9  
 BV BND1      z4&9.0  
 BV BND1      z4&9.1  
 BV BND1      z4&9.2  
 BV BND1      z4&9.3  
 BV BND1      z4&9.4  
 BV BND1      z4&9.5  
 BV BND1      z5&6.0  
 BV BND1      z5&6.1  
 BV BND1      z5&6.2  
 BV BND1      z5&6.3  
 BV BND1      z5&6.4  
 BV BND1      z5&6.5  
 BV BND1      z5&6.6  
 BV BND1      z5&6.7  
 BV BND1      z5&6.8  
 BV BND1      z5&7.0  
 BV BND1      z5&7.1  
 BV BND1      z5&7.2  
 BV BND1      z5&7.3  
 BV BND1      z5&7.4  
 BV BND1      z5&7.5  
 BV BND1      z5&7.6  
 BV BND1      z5&7.7  
 BV BND1      z5&7.8  
 BV BND1      z5&8.0  
 BV BND1      z5&8.1  
 BV BND1      z5&8.2  
 BV BND1      z5&8.3  
 BV BND1      z5&8.4  
 BV BND1      z5&8.5  
 BV BND1      z5&8.6  
 BV BND1      z5&8.7  
 BV BND1      z5&8.8  
 BV BND1      z5&8.9  
 BV BND1      z5&8.10 
 BV BND1      z5&9.0  
 BV BND1      z5&9.1  
 BV BND1      z5&9.2  
 BV BND1      z5&9.3  
 BV BND1      z5&9.4  
 BV BND1      z5&9.5  
 BV BND1      z5&9.6  
 BV BND1      z6&7.0  
 BV BND1      z6&7.1  
 BV BND1      z6&7.2  
 BV BND1      z6&7.3  
 BV BND1      z6&7.4  
 BV BND1      z6&7.5  
 BV BND1      z6&7.6  
 BV BND1      z6&7.7  
 BV BND1      z6&8.0  
 BV BND1      z6&8.1  
 BV BND1      z6&8.2  
 BV BND1      z6&8.3  
 BV BND1      z6&8.4  
 BV BND1      z6&8.6  
 BV BND1      z6&8.7  
 BV BND1      z6&8.8  
 BV BND1      z6&8.9  
 BV BND1      z6&9.0  
 BV BND1      z6&9.1  
 BV BND1      z6&9.2  
 BV BND1      z6&9.3  
 BV BND1      z6&9.4  
 BV BND1      z6&9.5  
 BV BND1      z6&9.6  
 BV BND1      z7&8.0  
 BV BND1      z7&8.1  
 BV BND1      z7&8.2  
 BV BND1      z7&8.3  
 BV BND1      z7&8.4  
 BV BND1      z7&8.5  
 BV BND1      z7&8.6  
 BV BND1      z7&8.7  
 BV BND1      z7&8.8  
 BV BND1      z7&8.9  
 BV BND1      z7&9.0  
 BV BND1      z7&9.1  
 BV BND1      z7&9.2  
 BV BND1      z7&9.3  
 BV BND1      z7&9.4  
 BV BND1      z7&9.5  
 BV BND1      z7&9.6  
 BV BND1      z8&9.0  
 BV BND1      z8&9.1  
 BV BND1      z8&9.2  
 BV BND1      z8&9.3  
 BV BND1      z8&9.4  
 BV BND1      z8&9.5  
 BV BND1      z8&9.6  
 BV BND1      z8&9.7  
ENDATA
