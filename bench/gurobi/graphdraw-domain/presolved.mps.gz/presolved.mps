NAME graphdraw-domain_pre
ROWS
 N  OBJ
 E  choose1[Client,CertificateTemplate]
 E  choose1[Client,Course]
 E  choose1[Client,Role]
 E  choose1[Client,User]
 E  choose1[Client,CourseSession]
 E  choose1[Client,Clinic]
 E  choose1[Client,Location]
 E  choose1[Client,Therapist]
 E  choose1[Client,Instructor]
 E  choose1[CertificateTemplate,Course]
 E  choose1[CertificateTemplate,Role]
 E  choose1[CertificateTemplate,User]
 E  choose1[CertificateTemplate,CourseSession]
 E  choose1[CertificateTemplate,Clinic]
 E  choose1[CertificateTemplate,Location]
 E  choose1[CertificateTemplate,Therapist]
 E  choose1[CertificateTemplate,Instructor]
 E  choose1[Course,Role]
 E  choose1[Course,User]
 E  choose1[Course,CourseSession]
 E  choose1[Course,Clinic]
 E  choose1[Course,Location]
 E  choose1[Course,Therapist]
 E  choose1[Course,Instructor]
 E  choose1[Role,User]
 E  choose1[Role,CourseSession]
 E  choose1[Role,Clinic]
 E  choose1[Role,Location]
 E  choose1[Role,Therapist]
 E  choose1[Role,Instructor]
 E  choose1[User,CourseSession]
 E  choose1[User,Clinic]
 E  choose1[User,Location]
 E  choose1[User,Therapist]
 E  choose1[User,Instructor]
 E  choose1[CourseSession,Clinic]
 E  choose1[CourseSession,Location]
 E  choose1[CourseSession,Therapist]
 E  choose1[CourseSession,Instructor]
 E  choose1[Clinic,Location]
 E  choose1[Clinic,Therapist]
 E  choose1[Clinic,Instructor]
 E  choose1[Location,Therapist]
 E  choose1[Location,Instructor]
 E  choose1[Therapist,Instructor]
 L  centerDistAxis2[r,Client]
 L  centerDistAxis2[r,CertificateTemplate]
 L  centerDistAxis2[r,Course]
 L  centerDistAxis2[r,Role]
 L  centerDistAxis2[r,User]
 L  centerDistAxis2[r,CourseSession]
 L  centerDistAxis2[r,Clinic]
 L  centerDistAxis2[r,Location]
 L  centerDistAxis2[r,Therapist]
 L  centerDistAxis2[r,Instructor]
 L  centerDistAxis2[c,Client]
 L  centerDistAxis2[c,CertificateTemplate]
 L  centerDistAxis2[c,Course]
 L  centerDistAxis2[c,Role]
 L  centerDistAxis2[c,User]
 L  centerDistAxis2[c,CourseSession]
 L  centerDistAxis2[c,Clinic]
 L  centerDistAxis2[c,Location]
 L  centerDistAxis2[c,Therapist]
 L  centerDistAxis2[c,Instructor]
 L  axisVdifLB[r,Client,CertificateTemplate]
 L  axisVdifLB[r,Client,Course]
 L  axisVdifLB[r,Client,Role]
 L  axisVdifLB[r,Client,User]
 L  axisVdifLB[r,Client,CourseSession]
 L  axisVdifLB[r,Client,Clinic]
 L  axisVdifLB[r,Client,Location]
 L  axisVdifLB[r,Client,Therapist]
 L  axisVdifLB[r,Client,Instructor]
 L  axisVdifLB[r,CertificateTemplate,Course]
 L  axisVdifLB[r,CertificateTemplate,Role]
 L  axisVdifLB[r,CertificateTemplate,User]
 L  axisVdifLB[r,CertificateTemplate,CourseSession]
 L  axisVdifLB[r,CertificateTemplate,Clinic]
 L  axisVdifLB[r,CertificateTemplate,Location]
 L  axisVdifLB[r,CertificateTemplate,Therapist]
 L  axisVdifLB[r,CertificateTemplate,Instructor]
 L  axisVdifLB[r,Course,Role]
 L  axisVdifLB[r,Course,User]
 L  axisVdifLB[r,Course,CourseSession]
 L  axisVdifLB[r,Course,Clinic]
 L  axisVdifLB[r,Course,Location]
 L  axisVdifLB[r,Course,Therapist]
 L  axisVdifLB[r,Course,Instructor]
 L  axisVdifLB[r,Role,User]
 L  axisVdifLB[r,Role,CourseSession]
 L  axisVdifLB[r,Role,Clinic]
 L  axisVdifLB[r,Role,Location]
 L  axisVdifLB[r,Role,Therapist]
 L  axisVdifLB[r,Role,Instructor]
 L  axisVdifLB[r,User,CourseSession]
 L  axisVdifLB[r,User,Clinic]
 L  axisVdifLB[r,User,Location]
 L  axisVdifLB[r,User,Therapist]
 L  axisVdifLB[r,User,Instructor]
 L  axisVdifLB[r,CourseSession,Clinic]
 L  axisVdifLB[r,CourseSession,Location]
 L  axisVdifLB[r,CourseSession,Therapist]
 L  axisVdifLB[r,CourseSession,Instructor]
 L  axisVdifLB[r,Clinic,Location]
 L  axisVdifLB[r,Clinic,Therapist]
 L  axisVdifLB[r,Clinic,Instructor]
 L  axisVdifLB[r,Location,Therapist]
 L  axisVdifLB[r,Location,Instructor]
 L  axisVdifLB[r,Therapist,Instructor]
 L  axisVdifLB[c,Client,CertificateTemplate]
 L  axisVdifLB[c,Client,Course]
 L  axisVdifLB[c,Client,Role]
 L  axisVdifLB[c,Client,User]
 L  axisVdifLB[c,Client,CourseSession]
 L  axisVdifLB[c,Client,Clinic]
 L  axisVdifLB[c,Client,Location]
 L  axisVdifLB[c,Client,Therapist]
 L  axisVdifLB[c,Client,Instructor]
 L  axisVdifLB[c,CertificateTemplate,Course]
 L  axisVdifLB[c,CertificateTemplate,Role]
 L  axisVdifLB[c,CertificateTemplate,User]
 L  axisVdifLB[c,CertificateTemplate,CourseSession]
 L  axisVdifLB[c,CertificateTemplate,Clinic]
 L  axisVdifLB[c,CertificateTemplate,Location]
 L  axisVdifLB[c,CertificateTemplate,Therapist]
 L  axisVdifLB[c,CertificateTemplate,Instructor]
 L  axisVdifLB[c,Course,Role]
 L  axisVdifLB[c,Course,User]
 L  axisVdifLB[c,Course,CourseSession]
 L  axisVdifLB[c,Course,Clinic]
 L  axisVdifLB[c,Course,Location]
 L  axisVdifLB[c,Course,Therapist]
 L  axisVdifLB[c,Course,Instructor]
 L  axisVdifLB[c,Role,User]
 L  axisVdifLB[c,Role,CourseSession]
 L  axisVdifLB[c,Role,Clinic]
 L  axisVdifLB[c,Role,Location]
 L  axisVdifLB[c,Role,Therapist]
 L  axisVdifLB[c,Role,Instructor]
 L  axisVdifLB[c,User,CourseSession]
 L  axisVdifLB[c,User,Clinic]
 L  axisVdifLB[c,User,Location]
 L  axisVdifLB[c,User,Therapist]
 L  axisVdifLB[c,User,Instructor]
 L  axisVdifLB[c,CourseSession,Clinic]
 L  axisVdifLB[c,CourseSession,Location]
 L  axisVdifLB[c,CourseSession,Therapist]
 L  axisVdifLB[c,CourseSession,Instructor]
 L  axisVdifLB[c,Clinic,Location]
 L  axisVdifLB[c,Clinic,Therapist]
 L  axisVdifLB[c,Clinic,Instructor]
 L  axisVdifLB[c,Location,Therapist]
 L  axisVdifLB[c,Location,Instructor]
 L  axisVdifLB[c,Therapist,Instructor]
 L  axisVdifRT[r,Client,CertificateTemplate]
 L  axisVdifRT[r,Client,Course]
 L  axisVdifRT[r,Client,Role]
 L  axisVdifRT[r,Client,User]
 L  axisVdifRT[r,Client,CourseSession]
 L  axisVdifRT[r,Client,Clinic]
 L  axisVdifRT[r,Client,Location]
 L  axisVdifRT[r,Client,Therapist]
 L  axisVdifRT[r,Client,Instructor]
 L  axisVdifRT[r,CertificateTemplate,Course]
 L  axisVdifRT[r,CertificateTemplate,Role]
 L  axisVdifRT[r,CertificateTemplate,User]
 L  axisVdifRT[r,CertificateTemplate,CourseSession]
 L  axisVdifRT[r,CertificateTemplate,Clinic]
 L  axisVdifRT[r,CertificateTemplate,Location]
 L  axisVdifRT[r,CertificateTemplate,Therapist]
 L  axisVdifRT[r,CertificateTemplate,Instructor]
 L  axisVdifRT[r,Course,Role]
 L  axisVdifRT[r,Course,User]
 L  axisVdifRT[r,Course,CourseSession]
 L  axisVdifRT[r,Course,Clinic]
 L  axisVdifRT[r,Course,Location]
 L  axisVdifRT[r,Course,Therapist]
 L  axisVdifRT[r,Course,Instructor]
 L  axisVdifRT[r,Role,User]
 L  axisVdifRT[r,Role,CourseSession]
 L  axisVdifRT[r,Role,Clinic]
 L  axisVdifRT[r,Role,Location]
 L  axisVdifRT[r,Role,Therapist]
 L  axisVdifRT[r,Role,Instructor]
 L  axisVdifRT[r,User,CourseSession]
 L  axisVdifRT[r,User,Clinic]
 L  axisVdifRT[r,User,Location]
 L  axisVdifRT[r,User,Therapist]
 L  axisVdifRT[r,User,Instructor]
 L  axisVdifRT[r,CourseSession,Clinic]
 L  axisVdifRT[r,CourseSession,Location]
 L  axisVdifRT[r,CourseSession,Therapist]
 L  axisVdifRT[r,CourseSession,Instructor]
 L  axisVdifRT[r,Clinic,Location]
 L  axisVdifRT[r,Clinic,Therapist]
 L  axisVdifRT[r,Clinic,Instructor]
 L  axisVdifRT[r,Location,Therapist]
 L  axisVdifRT[r,Location,Instructor]
 L  axisVdifRT[r,Therapist,Instructor]
 L  axisVdifRT[c,Client,CertificateTemplate]
 L  axisVdifRT[c,Client,Course]
 L  axisVdifRT[c,Client,Role]
 L  axisVdifRT[c,Client,User]
 L  axisVdifRT[c,Client,CourseSession]
 L  axisVdifRT[c,Client,Clinic]
 L  axisVdifRT[c,Client,Location]
 L  axisVdifRT[c,Client,Therapist]
 L  axisVdifRT[c,Client,Instructor]
 L  axisVdifRT[c,CertificateTemplate,Course]
 L  axisVdifRT[c,CertificateTemplate,Role]
 L  axisVdifRT[c,CertificateTemplate,User]
 L  axisVdifRT[c,CertificateTemplate,CourseSession]
 L  axisVdifRT[c,CertificateTemplate,Clinic]
 L  axisVdifRT[c,CertificateTemplate,Location]
 L  axisVdifRT[c,CertificateTemplate,Therapist]
 L  axisVdifRT[c,CertificateTemplate,Instructor]
 L  axisVdifRT[c,Course,Role]
 L  axisVdifRT[c,Course,User]
 L  axisVdifRT[c,Course,CourseSession]
 L  axisVdifRT[c,Course,Clinic]
 L  axisVdifRT[c,Course,Location]
 L  axisVdifRT[c,Course,Therapist]
 L  axisVdifRT[c,Course,Instructor]
 L  axisVdifRT[c,Role,User]
 L  axisVdifRT[c,Role,CourseSession]
 L  axisVdifRT[c,Role,Clinic]
 L  axisVdifRT[c,Role,Location]
 L  axisVdifRT[c,Role,Therapist]
 L  axisVdifRT[c,Role,Instructor]
 L  axisVdifRT[c,User,CourseSession]
 L  axisVdifRT[c,User,Clinic]
 L  axisVdifRT[c,User,Location]
 L  axisVdifRT[c,User,Therapist]
 L  axisVdifRT[c,User,Instructor]
 L  axisVdifRT[c,CourseSession,Clinic]
 L  axisVdifRT[c,CourseSession,Location]
 L  axisVdifRT[c,CourseSession,Therapist]
 L  axisVdifRT[c,CourseSession,Instructor]
 L  axisVdifRT[c,Clinic,Location]
 L  axisVdifRT[c,Clinic,Therapist]
 L  axisVdifRT[c,Clinic,Instructor]
 L  axisVdifRT[c,Location,Therapist]
 L  axisVdifRT[c,Location,Instructor]
 L  axisVdifRT[c,Therapist,Instructor]
 L  compDistAxis1[r,Client,CertificateTemplate]
 L  compDistAxis1[r,Client,CourseSession]
 L  compDistAxis1[r,Client,Instructor]
 L  compDistAxis1[r,Client,Location]
 L  compDistAxis1[r,Client,User]
 L  compDistAxis1[r,CertificateTemplate,CourseSession]
 L  compDistAxis1[r,Course,CourseSession]
 L  compDistAxis1[r,CourseSession,Instructor]
 L  compDistAxis1[r,Instructor,Location]
 L  compDistAxis1[r,Clinic,Location]
 L  compDistAxis1[r,Clinic,Therapist]
 L  compDistAxis1[r,Location,Therapist]
 L  compDistAxis1[r,Location,CourseSession]
 L  compDistAxis1[r,Therapist,CourseSession]
 L  compDistAxis1[r,Role,User]
 L  compDistAxis1[r,User,Instructor]
 L  compDistAxis1[r,User,Therapist]
 L  compDistAxis1[c,Client,CertificateTemplate]
 L  compDistAxis1[c,Client,CourseSession]
 L  compDistAxis1[c,Client,Instructor]
 L  compDistAxis1[c,Client,Location]
 L  compDistAxis1[c,Client,User]
 L  compDistAxis1[c,CertificateTemplate,CourseSession]
 L  compDistAxis1[c,Course,CourseSession]
 L  compDistAxis1[c,CourseSession,Instructor]
 L  compDistAxis1[c,Instructor,Location]
 L  compDistAxis1[c,Clinic,Location]
 L  compDistAxis1[c,Clinic,Therapist]
 L  compDistAxis1[c,Location,Therapist]
 L  compDistAxis1[c,Location,CourseSession]
 L  compDistAxis1[c,Therapist,CourseSession]
 L  compDistAxis1[c,Role,User]
 L  compDistAxis1[c,User,Instructor]
 L  compDistAxis1[c,User,Therapist]
 L  compDistAxis2[r,Client,CertificateTemplate]
 L  compDistAxis2[r,Client,CourseSession]
 L  compDistAxis2[r,Client,Instructor]
 L  compDistAxis2[r,Client,Location]
 L  compDistAxis2[r,Client,User]
 L  compDistAxis2[r,CertificateTemplate,CourseSession]
 L  compDistAxis2[r,Course,CourseSession]
 L  compDistAxis2[r,CourseSession,Instructor]
 L  compDistAxis2[r,Instructor,Location]
 L  compDistAxis2[r,Clinic,Location]
 L  compDistAxis2[r,Clinic,Therapist]
 L  compDistAxis2[r,Location,Therapist]
 L  compDistAxis2[r,Location,CourseSession]
 L  compDistAxis2[r,Therapist,CourseSession]
 L  compDistAxis2[r,Role,User]
 L  compDistAxis2[r,User,Instructor]
 L  compDistAxis2[r,User,Therapist]
 L  compDistAxis2[c,Client,CertificateTemplate]
 L  compDistAxis2[c,Client,CourseSession]
 L  compDistAxis2[c,Client,Instructor]
 L  compDistAxis2[c,Client,Location]
 L  compDistAxis2[c,Client,User]
 L  compDistAxis2[c,CertificateTemplate,CourseSession]
 L  compDistAxis2[c,Course,CourseSession]
 L  compDistAxis2[c,CourseSession,Instructor]
 L  compDistAxis2[c,Instructor,Location]
 L  compDistAxis2[c,Clinic,Location]
 L  compDistAxis2[c,Clinic,Therapist]
 L  compDistAxis2[c,Location,Therapist]
 L  compDistAxis2[c,Location,CourseSession]
 L  compDistAxis2[c,Therapist,CourseSession]
 L  compDistAxis2[c,Role,User]
 L  compDistAxis2[c,User,Instructor]
 L  compDistAxis2[c,User,Therapist]
 L  DistSumLB[Client,CertificateTemplate]
 L  DistSumLB[Client,CourseSession]
 L  DistSumLB[Client,Instructor]
 L  DistSumLB[Client,Location]
 L  DistSumLB[Client,User]
 L  DistSumLB[CertificateTemplate,CourseSession]
 L  DistSumLB[Course,CourseSession]
 L  DistSumLB[CourseSession,Instructor]
 L  DistSumLB[Instructor,Location]
 L  DistSumLB[Clinic,Location]
 L  DistSumLB[Clinic,Therapist]
 L  DistSumLB[Location,Therapist]
 L  DistSumLB[Location,CourseSession]
 L  DistSumLB[Therapist,CourseSession]
 L  DistSumLB[Role,User]
 L  DistSumLB[User,Instructor]
 L  DistSumLB[User,Therapist]
 L  CenterDistSumLB
 L  DistAxisLB1[r,Client,CertificateTemplate]
 L  DistAxisLB1[r,Client,CourseSession]
 L  DistAxisLB1[r,Client,Instructor]
 L  DistAxisLB1[r,Client,Location]
 L  DistAxisLB1[r,Client,User]
 L  DistAxisLB1[r,CertificateTemplate,CourseSession]
 L  DistAxisLB1[r,Course,CourseSession]
 L  DistAxisLB1[r,CourseSession,Instructor]
 L  DistAxisLB1[r,Instructor,Location]
 L  DistAxisLB1[r,Clinic,Location]
 L  DistAxisLB1[r,Clinic,Therapist]
 L  DistAxisLB1[r,Location,Therapist]
 L  DistAxisLB1[r,Location,CourseSession]
 L  DistAxisLB1[r,Therapist,CourseSession]
 L  DistAxisLB1[r,Role,User]
 L  DistAxisLB1[r,User,Instructor]
 L  DistAxisLB1[r,User,Therapist]
 L  DistAxisLB1[c,Client,CertificateTemplate]
 L  DistAxisLB1[c,Client,CourseSession]
 L  DistAxisLB1[c,Client,Instructor]
 L  DistAxisLB1[c,Client,Location]
 L  DistAxisLB1[c,Client,User]
 L  DistAxisLB1[c,CertificateTemplate,CourseSession]
 L  DistAxisLB1[c,Course,CourseSession]
 L  DistAxisLB1[c,CourseSession,Instructor]
 L  DistAxisLB1[c,Instructor,Location]
 L  DistAxisLB1[c,Clinic,Location]
 L  DistAxisLB1[c,Clinic,Therapist]
 L  DistAxisLB1[c,Location,Therapist]
 L  DistAxisLB1[c,Location,CourseSession]
 L  DistAxisLB1[c,Therapist,CourseSession]
 L  DistAxisLB1[c,Role,User]
 L  DistAxisLB1[c,User,Instructor]
 L  DistAxisLB1[c,User,Therapist]
 L  triangle1[Client,CertificateTemplate,Course,r]
 L  triangle1[Client,CertificateTemplate,Course,c]
 L  triangle1[Client,CertificateTemplate,Role,r]
 L  triangle1[Client,CertificateTemplate,Role,c]
 L  triangle1[Client,CertificateTemplate,User,r]
 L  triangle1[Client,CertificateTemplate,User,c]
 L  triangle1[Client,CertificateTemplate,CourseSession,r]
 L  triangle1[Client,CertificateTemplate,CourseSession,c]
 L  triangle1[Client,CertificateTemplate,Clinic,r]
 L  triangle1[Client,CertificateTemplate,Clinic,c]
 L  triangle1[Client,CertificateTemplate,Location,r]
 L  triangle1[Client,CertificateTemplate,Location,c]
 L  triangle1[Client,CertificateTemplate,Therapist,r]
 L  triangle1[Client,CertificateTemplate,Therapist,c]
 L  triangle1[Client,CertificateTemplate,Instructor,r]
 L  triangle1[Client,CertificateTemplate,Instructor,c]
 L  triangle1[Client,Course,Role,r]
 L  triangle1[Client,Course,Role,c]
 L  triangle1[Client,Course,User,r]
 L  triangle1[Client,Course,User,c]
 L  triangle1[Client,Course,CourseSession,r]
 L  triangle1[Client,Course,CourseSession,c]
 L  triangle1[Client,Course,Clinic,r]
 L  triangle1[Client,Course,Clinic,c]
 L  triangle1[Client,Course,Location,r]
 L  triangle1[Client,Course,Location,c]
 L  triangle1[Client,Course,Therapist,r]
 L  triangle1[Client,Course,Therapist,c]
 L  triangle1[Client,Course,Instructor,r]
 L  triangle1[Client,Course,Instructor,c]
 L  triangle1[Client,Role,User,r]
 L  triangle1[Client,Role,User,c]
 L  triangle1[Client,Role,CourseSession,r]
 L  triangle1[Client,Role,CourseSession,c]
 L  triangle1[Client,Role,Clinic,r]
 L  triangle1[Client,Role,Clinic,c]
 L  triangle1[Client,Role,Location,r]
 L  triangle1[Client,Role,Location,c]
 L  triangle1[Client,Role,Therapist,r]
 L  triangle1[Client,Role,Therapist,c]
 L  triangle1[Client,Role,Instructor,r]
 L  triangle1[Client,Role,Instructor,c]
 L  triangle1[Client,User,CourseSession,r]
 L  triangle1[Client,User,CourseSession,c]
 L  triangle1[Client,User,Clinic,r]
 L  triangle1[Client,User,Clinic,c]
 L  triangle1[Client,User,Location,r]
 L  triangle1[Client,User,Location,c]
 L  triangle1[Client,User,Therapist,r]
 L  triangle1[Client,User,Therapist,c]
 L  triangle1[Client,User,Instructor,r]
 L  triangle1[Client,User,Instructor,c]
 L  triangle1[Client,CourseSession,Clinic,r]
 L  triangle1[Client,CourseSession,Clinic,c]
 L  triangle1[Client,CourseSession,Location,r]
 L  triangle1[Client,CourseSession,Location,c]
 L  triangle1[Client,CourseSession,Therapist,r]
 L  triangle1[Client,CourseSession,Therapist,c]
 L  triangle1[Client,CourseSession,Instructor,r]
 L  triangle1[Client,CourseSession,Instructor,c]
 L  triangle1[Client,Clinic,Location,r]
 L  triangle1[Client,Clinic,Location,c]
 L  triangle1[Client,Clinic,Therapist,r]
 L  triangle1[Client,Clinic,Therapist,c]
 L  triangle1[Client,Clinic,Instructor,r]
 L  triangle1[Client,Clinic,Instructor,c]
 L  triangle1[Client,Location,Therapist,r]
 L  triangle1[Client,Location,Therapist,c]
 L  triangle1[Client,Location,Instructor,r]
 L  triangle1[Client,Location,Instructor,c]
 L  triangle1[Client,Therapist,Instructor,r]
 L  triangle1[Client,Therapist,Instructor,c]
 L  triangle1[CertificateTemplate,Course,Role,r]
 L  triangle1[CertificateTemplate,Course,Role,c]
 L  triangle1[CertificateTemplate,Course,User,r]
 L  triangle1[CertificateTemplate,Course,User,c]
 L  triangle1[CertificateTemplate,Course,CourseSession,r]
 L  triangle1[CertificateTemplate,Course,CourseSession,c]
 L  triangle1[CertificateTemplate,Course,Clinic,r]
 L  triangle1[CertificateTemplate,Course,Clinic,c]
 L  triangle1[CertificateTemplate,Course,Location,r]
 L  triangle1[CertificateTemplate,Course,Location,c]
 L  triangle1[CertificateTemplate,Course,Therapist,r]
 L  triangle1[CertificateTemplate,Course,Therapist,c]
 L  triangle1[CertificateTemplate,Course,Instructor,r]
 L  triangle1[CertificateTemplate,Course,Instructor,c]
 L  triangle1[CertificateTemplate,Role,User,r]
 L  triangle1[CertificateTemplate,Role,User,c]
 L  triangle1[CertificateTemplate,Role,CourseSession,r]
 L  triangle1[CertificateTemplate,Role,CourseSession,c]
 L  triangle1[CertificateTemplate,Role,Clinic,r]
 L  triangle1[CertificateTemplate,Role,Clinic,c]
 L  triangle1[CertificateTemplate,Role,Location,r]
 L  triangle1[CertificateTemplate,Role,Location,c]
 L  triangle1[CertificateTemplate,Role,Therapist,r]
 L  triangle1[CertificateTemplate,Role,Therapist,c]
 L  triangle1[CertificateTemplate,Role,Instructor,r]
 L  triangle1[CertificateTemplate,Role,Instructor,c]
 L  triangle1[CertificateTemplate,User,CourseSession,r]
 L  triangle1[CertificateTemplate,User,CourseSession,c]
 L  triangle1[CertificateTemplate,User,Clinic,r]
 L  triangle1[CertificateTemplate,User,Clinic,c]
 L  triangle1[CertificateTemplate,User,Location,r]
 L  triangle1[CertificateTemplate,User,Location,c]
 L  triangle1[CertificateTemplate,User,Therapist,r]
 L  triangle1[CertificateTemplate,User,Therapist,c]
 L  triangle1[CertificateTemplate,User,Instructor,r]
 L  triangle1[CertificateTemplate,User,Instructor,c]
 L  triangle1[CertificateTemplate,CourseSession,Clinic,r]
 L  triangle1[CertificateTemplate,CourseSession,Clinic,c]
 L  triangle1[CertificateTemplate,CourseSession,Location,r]
 L  triangle1[CertificateTemplate,CourseSession,Location,c]
 L  triangle1[CertificateTemplate,CourseSession,Therapist,r]
 L  triangle1[CertificateTemplate,CourseSession,Therapist,c]
 L  triangle1[CertificateTemplate,CourseSession,Instructor,r]
 L  triangle1[CertificateTemplate,CourseSession,Instructor,c]
 L  triangle1[CertificateTemplate,Clinic,Location,r]
 L  triangle1[CertificateTemplate,Clinic,Location,c]
 L  triangle1[CertificateTemplate,Clinic,Therapist,r]
 L  triangle1[CertificateTemplate,Clinic,Therapist,c]
 L  triangle1[CertificateTemplate,Clinic,Instructor,r]
 L  triangle1[CertificateTemplate,Clinic,Instructor,c]
 L  triangle1[CertificateTemplate,Location,Therapist,r]
 L  triangle1[CertificateTemplate,Location,Therapist,c]
 L  triangle1[CertificateTemplate,Location,Instructor,r]
 L  triangle1[CertificateTemplate,Location,Instructor,c]
 L  triangle1[CertificateTemplate,Therapist,Instructor,r]
 L  triangle1[CertificateTemplate,Therapist,Instructor,c]
 L  triangle1[Course,Role,User,r]
 L  triangle1[Course,Role,User,c]
 L  triangle1[Course,Role,CourseSession,r]
 L  triangle1[Course,Role,CourseSession,c]
 L  triangle1[Course,Role,Clinic,r]
 L  triangle1[Course,Role,Clinic,c]
 L  triangle1[Course,Role,Location,r]
 L  triangle1[Course,Role,Location,c]
 L  triangle1[Course,Role,Therapist,r]
 L  triangle1[Course,Role,Therapist,c]
 L  triangle1[Course,Role,Instructor,r]
 L  triangle1[Course,Role,Instructor,c]
 L  triangle1[Course,User,CourseSession,r]
 L  triangle1[Course,User,CourseSession,c]
 L  triangle1[Course,User,Clinic,r]
 L  triangle1[Course,User,Clinic,c]
 L  triangle1[Course,User,Location,r]
 L  triangle1[Course,User,Location,c]
 L  triangle1[Course,User,Therapist,r]
 L  triangle1[Course,User,Therapist,c]
 L  triangle1[Course,User,Instructor,r]
 L  triangle1[Course,User,Instructor,c]
 L  triangle1[Course,CourseSession,Clinic,r]
 L  triangle1[Course,CourseSession,Clinic,c]
 L  triangle1[Course,CourseSession,Location,r]
 L  triangle1[Course,CourseSession,Location,c]
 L  triangle1[Course,CourseSession,Therapist,r]
 L  triangle1[Course,CourseSession,Therapist,c]
 L  triangle1[Course,CourseSession,Instructor,r]
 L  triangle1[Course,CourseSession,Instructor,c]
 L  triangle1[Course,Clinic,Location,r]
 L  triangle1[Course,Clinic,Location,c]
 L  triangle1[Course,Clinic,Therapist,r]
 L  triangle1[Course,Clinic,Therapist,c]
 L  triangle1[Course,Clinic,Instructor,r]
 L  triangle1[Course,Clinic,Instructor,c]
 L  triangle1[Course,Location,Therapist,r]
 L  triangle1[Course,Location,Therapist,c]
 L  triangle1[Course,Location,Instructor,r]
 L  triangle1[Course,Location,Instructor,c]
 L  triangle1[Course,Therapist,Instructor,r]
 L  triangle1[Course,Therapist,Instructor,c]
 L  triangle1[Role,User,CourseSession,r]
 L  triangle1[Role,User,CourseSession,c]
 L  triangle1[Role,User,Clinic,r]
 L  triangle1[Role,User,Clinic,c]
 L  triangle1[Role,User,Location,r]
 L  triangle1[Role,User,Location,c]
 L  triangle1[Role,User,Therapist,r]
 L  triangle1[Role,User,Therapist,c]
 L  triangle1[Role,User,Instructor,r]
 L  triangle1[Role,User,Instructor,c]
 L  triangle1[Role,CourseSession,Clinic,r]
 L  triangle1[Role,CourseSession,Clinic,c]
 L  triangle1[Role,CourseSession,Location,r]
 L  triangle1[Role,CourseSession,Location,c]
 L  triangle1[Role,CourseSession,Therapist,r]
 L  triangle1[Role,CourseSession,Therapist,c]
 L  triangle1[Role,CourseSession,Instructor,r]
 L  triangle1[Role,CourseSession,Instructor,c]
 L  triangle1[Role,Clinic,Location,r]
 L  triangle1[Role,Clinic,Location,c]
 L  triangle1[Role,Clinic,Therapist,r]
 L  triangle1[Role,Clinic,Therapist,c]
 L  triangle1[Role,Clinic,Instructor,r]
 L  triangle1[Role,Clinic,Instructor,c]
 L  triangle1[Role,Location,Therapist,r]
 L  triangle1[Role,Location,Therapist,c]
 L  triangle1[Role,Location,Instructor,r]
 L  triangle1[Role,Location,Instructor,c]
 L  triangle1[Role,Therapist,Instructor,r]
 L  triangle1[Role,Therapist,Instructor,c]
 L  triangle1[User,CourseSession,Clinic,r]
 L  triangle1[User,CourseSession,Clinic,c]
 L  triangle1[User,CourseSession,Location,r]
 L  triangle1[User,CourseSession,Location,c]
 L  triangle1[User,CourseSession,Therapist,r]
 L  triangle1[User,CourseSession,Therapist,c]
 L  triangle1[User,CourseSession,Instructor,r]
 L  triangle1[User,CourseSession,Instructor,c]
 L  triangle1[User,Clinic,Location,r]
 L  triangle1[User,Clinic,Location,c]
 L  triangle1[User,Clinic,Therapist,r]
 L  triangle1[User,Clinic,Therapist,c]
 L  triangle1[User,Clinic,Instructor,r]
 L  triangle1[User,Clinic,Instructor,c]
 L  triangle1[User,Location,Therapist,r]
 L  triangle1[User,Location,Therapist,c]
 L  triangle1[User,Location,Instructor,r]
 L  triangle1[User,Location,Instructor,c]
 L  triangle1[User,Therapist,Instructor,r]
 L  triangle1[User,Therapist,Instructor,c]
 L  triangle1[CourseSession,Clinic,Location,r]
 L  triangle1[CourseSession,Clinic,Location,c]
 L  triangle1[CourseSession,Clinic,Therapist,r]
 L  triangle1[CourseSession,Clinic,Therapist,c]
 L  triangle1[CourseSession,Clinic,Instructor,r]
 L  triangle1[CourseSession,Clinic,Instructor,c]
 L  triangle1[CourseSession,Location,Therapist,r]
 L  triangle1[CourseSession,Location,Therapist,c]
 L  triangle1[CourseSession,Location,Instructor,r]
 L  triangle1[CourseSession,Location,Instructor,c]
 L  triangle1[CourseSession,Therapist,Instructor,r]
 L  triangle1[CourseSession,Therapist,Instructor,c]
 L  triangle1[Clinic,Location,Therapist,r]
 L  triangle1[Clinic,Location,Therapist,c]
 L  triangle1[Clinic,Location,Instructor,r]
 L  triangle1[Clinic,Location,Instructor,c]
 L  triangle1[Clinic,Therapist,Instructor,r]
 L  triangle1[Clinic,Therapist,Instructor,c]
 L  triangle1[Location,Therapist,Instructor,r]
 L  triangle1[Location,Therapist,Instructor,c]
 L  triangle2[Client,CertificateTemplate,Course,r]
 L  triangle2[Client,CertificateTemplate,Course,c]
 L  triangle2[Client,CertificateTemplate,Role,r]
 L  triangle2[Client,CertificateTemplate,Role,c]
 L  triangle2[Client,CertificateTemplate,User,r]
 L  triangle2[Client,CertificateTemplate,User,c]
 L  triangle2[Client,CertificateTemplate,CourseSession,r]
 L  triangle2[Client,CertificateTemplate,CourseSession,c]
 L  triangle2[Client,CertificateTemplate,Clinic,r]
 L  triangle2[Client,CertificateTemplate,Clinic,c]
 L  triangle2[Client,CertificateTemplate,Location,r]
 L  triangle2[Client,CertificateTemplate,Location,c]
 L  triangle2[Client,CertificateTemplate,Therapist,r]
 L  triangle2[Client,CertificateTemplate,Therapist,c]
 L  triangle2[Client,CertificateTemplate,Instructor,r]
 L  triangle2[Client,CertificateTemplate,Instructor,c]
 L  triangle2[Client,Course,Role,r]
 L  triangle2[Client,Course,Role,c]
 L  triangle2[Client,Course,User,r]
 L  triangle2[Client,Course,User,c]
 L  triangle2[Client,Course,CourseSession,r]
 L  triangle2[Client,Course,CourseSession,c]
 L  triangle2[Client,Course,Clinic,r]
 L  triangle2[Client,Course,Clinic,c]
 L  triangle2[Client,Course,Location,r]
 L  triangle2[Client,Course,Location,c]
 L  triangle2[Client,Course,Therapist,r]
 L  triangle2[Client,Course,Therapist,c]
 L  triangle2[Client,Course,Instructor,r]
 L  triangle2[Client,Course,Instructor,c]
 L  triangle2[Client,Role,User,r]
 L  triangle2[Client,Role,User,c]
 L  triangle2[Client,Role,CourseSession,r]
 L  triangle2[Client,Role,CourseSession,c]
 L  triangle2[Client,Role,Clinic,r]
 L  triangle2[Client,Role,Clinic,c]
 L  triangle2[Client,Role,Location,r]
 L  triangle2[Client,Role,Location,c]
 L  triangle2[Client,Role,Therapist,r]
 L  triangle2[Client,Role,Therapist,c]
 L  triangle2[Client,Role,Instructor,r]
 L  triangle2[Client,Role,Instructor,c]
 L  triangle2[Client,User,CourseSession,r]
 L  triangle2[Client,User,CourseSession,c]
 L  triangle2[Client,User,Clinic,r]
 L  triangle2[Client,User,Clinic,c]
 L  triangle2[Client,User,Location,r]
 L  triangle2[Client,User,Location,c]
 L  triangle2[Client,User,Therapist,r]
 L  triangle2[Client,User,Therapist,c]
 L  triangle2[Client,User,Instructor,r]
 L  triangle2[Client,User,Instructor,c]
 L  triangle2[Client,CourseSession,Clinic,r]
 L  triangle2[Client,CourseSession,Clinic,c]
 L  triangle2[Client,CourseSession,Location,r]
 L  triangle2[Client,CourseSession,Location,c]
 L  triangle2[Client,CourseSession,Therapist,r]
 L  triangle2[Client,CourseSession,Therapist,c]
 L  triangle2[Client,CourseSession,Instructor,r]
 L  triangle2[Client,CourseSession,Instructor,c]
 L  triangle2[Client,Clinic,Location,r]
 L  triangle2[Client,Clinic,Location,c]
 L  triangle2[Client,Clinic,Therapist,r]
 L  triangle2[Client,Clinic,Therapist,c]
 L  triangle2[Client,Clinic,Instructor,r]
 L  triangle2[Client,Clinic,Instructor,c]
 L  triangle2[Client,Location,Therapist,r]
 L  triangle2[Client,Location,Therapist,c]
 L  triangle2[Client,Location,Instructor,r]
 L  triangle2[Client,Location,Instructor,c]
 L  triangle2[Client,Therapist,Instructor,r]
 L  triangle2[Client,Therapist,Instructor,c]
 L  triangle2[CertificateTemplate,Course,Role,r]
 L  triangle2[CertificateTemplate,Course,Role,c]
 L  triangle2[CertificateTemplate,Course,User,r]
 L  triangle2[CertificateTemplate,Course,User,c]
 L  triangle2[CertificateTemplate,Course,CourseSession,r]
 L  triangle2[CertificateTemplate,Course,CourseSession,c]
 L  triangle2[CertificateTemplate,Course,Clinic,r]
 L  triangle2[CertificateTemplate,Course,Clinic,c]
 L  triangle2[CertificateTemplate,Course,Location,r]
 L  triangle2[CertificateTemplate,Course,Location,c]
 L  triangle2[CertificateTemplate,Course,Therapist,r]
 L  triangle2[CertificateTemplate,Course,Therapist,c]
 L  triangle2[CertificateTemplate,Course,Instructor,r]
 L  triangle2[CertificateTemplate,Course,Instructor,c]
 L  triangle2[CertificateTemplate,Role,User,r]
 L  triangle2[CertificateTemplate,Role,User,c]
 L  triangle2[CertificateTemplate,Role,CourseSession,r]
 L  triangle2[CertificateTemplate,Role,CourseSession,c]
 L  triangle2[CertificateTemplate,Role,Clinic,r]
 L  triangle2[CertificateTemplate,Role,Clinic,c]
 L  triangle2[CertificateTemplate,Role,Location,r]
 L  triangle2[CertificateTemplate,Role,Location,c]
 L  triangle2[CertificateTemplate,Role,Therapist,r]
 L  triangle2[CertificateTemplate,Role,Therapist,c]
 L  triangle2[CertificateTemplate,Role,Instructor,r]
 L  triangle2[CertificateTemplate,Role,Instructor,c]
 L  triangle2[CertificateTemplate,User,CourseSession,r]
 L  triangle2[CertificateTemplate,User,CourseSession,c]
 L  triangle2[CertificateTemplate,User,Clinic,r]
 L  triangle2[CertificateTemplate,User,Clinic,c]
 L  triangle2[CertificateTemplate,User,Location,r]
 L  triangle2[CertificateTemplate,User,Location,c]
 L  triangle2[CertificateTemplate,User,Therapist,r]
 L  triangle2[CertificateTemplate,User,Therapist,c]
 L  triangle2[CertificateTemplate,User,Instructor,r]
 L  triangle2[CertificateTemplate,User,Instructor,c]
 L  triangle2[CertificateTemplate,CourseSession,Clinic,r]
 L  triangle2[CertificateTemplate,CourseSession,Clinic,c]
 L  triangle2[CertificateTemplate,CourseSession,Location,r]
 L  triangle2[CertificateTemplate,CourseSession,Location,c]
 L  triangle2[CertificateTemplate,CourseSession,Therapist,r]
 L  triangle2[CertificateTemplate,CourseSession,Therapist,c]
 L  triangle2[CertificateTemplate,CourseSession,Instructor,r]
 L  triangle2[CertificateTemplate,CourseSession,Instructor,c]
 L  triangle2[CertificateTemplate,Clinic,Location,r]
 L  triangle2[CertificateTemplate,Clinic,Location,c]
 L  triangle2[CertificateTemplate,Clinic,Therapist,r]
 L  triangle2[CertificateTemplate,Clinic,Therapist,c]
 L  triangle2[CertificateTemplate,Clinic,Instructor,r]
 L  triangle2[CertificateTemplate,Clinic,Instructor,c]
 L  triangle2[CertificateTemplate,Location,Therapist,r]
 L  triangle2[CertificateTemplate,Location,Therapist,c]
 L  triangle2[CertificateTemplate,Location,Instructor,r]
 L  triangle2[CertificateTemplate,Location,Instructor,c]
 L  triangle2[CertificateTemplate,Therapist,Instructor,r]
 L  triangle2[CertificateTemplate,Therapist,Instructor,c]
 L  triangle2[Course,Role,User,r]
 L  triangle2[Course,Role,User,c]
 L  triangle2[Course,Role,CourseSession,r]
 L  triangle2[Course,Role,CourseSession,c]
 L  triangle2[Course,Role,Clinic,r]
 L  triangle2[Course,Role,Clinic,c]
 L  triangle2[Course,Role,Location,r]
 L  triangle2[Course,Role,Location,c]
 L  triangle2[Course,Role,Therapist,r]
 L  triangle2[Course,Role,Therapist,c]
 L  triangle2[Course,Role,Instructor,r]
 L  triangle2[Course,Role,Instructor,c]
 L  triangle2[Course,User,CourseSession,r]
 L  triangle2[Course,User,CourseSession,c]
 L  triangle2[Course,User,Clinic,r]
 L  triangle2[Course,User,Clinic,c]
 L  triangle2[Course,User,Location,r]
 L  triangle2[Course,User,Location,c]
 L  triangle2[Course,User,Therapist,r]
 L  triangle2[Course,User,Therapist,c]
 L  triangle2[Course,User,Instructor,r]
 L  triangle2[Course,User,Instructor,c]
 L  triangle2[Course,CourseSession,Clinic,r]
 L  triangle2[Course,CourseSession,Clinic,c]
 L  triangle2[Course,CourseSession,Location,r]
 L  triangle2[Course,CourseSession,Location,c]
 L  triangle2[Course,CourseSession,Therapist,r]
 L  triangle2[Course,CourseSession,Therapist,c]
 L  triangle2[Course,CourseSession,Instructor,r]
 L  triangle2[Course,CourseSession,Instructor,c]
 L  triangle2[Course,Clinic,Location,r]
 L  triangle2[Course,Clinic,Location,c]
 L  triangle2[Course,Clinic,Therapist,r]
 L  triangle2[Course,Clinic,Therapist,c]
 L  triangle2[Course,Clinic,Instructor,r]
 L  triangle2[Course,Clinic,Instructor,c]
 L  triangle2[Course,Location,Therapist,r]
 L  triangle2[Course,Location,Therapist,c]
 L  triangle2[Course,Location,Instructor,r]
 L  triangle2[Course,Location,Instructor,c]
 L  triangle2[Course,Therapist,Instructor,r]
 L  triangle2[Course,Therapist,Instructor,c]
 L  triangle2[Role,User,CourseSession,r]
 L  triangle2[Role,User,CourseSession,c]
 L  triangle2[Role,User,Clinic,r]
 L  triangle2[Role,User,Clinic,c]
 L  triangle2[Role,User,Location,r]
 L  triangle2[Role,User,Location,c]
 L  triangle2[Role,User,Therapist,r]
 L  triangle2[Role,User,Therapist,c]
 L  triangle2[Role,User,Instructor,r]
 L  triangle2[Role,User,Instructor,c]
 L  triangle2[Role,CourseSession,Clinic,r]
 L  triangle2[Role,CourseSession,Clinic,c]
 L  triangle2[Role,CourseSession,Location,r]
 L  triangle2[Role,CourseSession,Location,c]
 L  triangle2[Role,CourseSession,Therapist,r]
 L  triangle2[Role,CourseSession,Therapist,c]
 L  triangle2[Role,CourseSession,Instructor,r]
 L  triangle2[Role,CourseSession,Instructor,c]
 L  triangle2[Role,Clinic,Location,r]
 L  triangle2[Role,Clinic,Location,c]
 L  triangle2[Role,Clinic,Therapist,r]
 L  triangle2[Role,Clinic,Therapist,c]
 L  triangle2[Role,Clinic,Instructor,r]
 L  triangle2[Role,Clinic,Instructor,c]
 L  triangle2[Role,Location,Therapist,r]
 L  triangle2[Role,Location,Therapist,c]
 L  triangle2[Role,Location,Instructor,r]
 L  triangle2[Role,Location,Instructor,c]
 L  triangle2[Role,Therapist,Instructor,r]
 L  triangle2[Role,Therapist,Instructor,c]
 L  triangle2[User,CourseSession,Clinic,r]
 L  triangle2[User,CourseSession,Clinic,c]
 L  triangle2[User,CourseSession,Location,r]
 L  triangle2[User,CourseSession,Location,c]
 L  triangle2[User,CourseSession,Therapist,r]
 L  triangle2[User,CourseSession,Therapist,c]
 L  triangle2[User,CourseSession,Instructor,r]
 L  triangle2[User,CourseSession,Instructor,c]
 L  triangle2[User,Clinic,Location,r]
 L  triangle2[User,Clinic,Location,c]
 L  triangle2[User,Clinic,Therapist,r]
 L  triangle2[User,Clinic,Therapist,c]
 L  triangle2[User,Clinic,Instructor,r]
 L  triangle2[User,Clinic,Instructor,c]
 L  triangle2[User,Location,Therapist,r]
 L  triangle2[User,Location,Therapist,c]
 L  triangle2[User,Location,Instructor,r]
 L  triangle2[User,Location,Instructor,c]
 L  triangle2[User,Therapist,Instructor,r]
 L  triangle2[User,Therapist,Instructor,c]
 L  triangle2[CourseSession,Clinic,Location,r]
 L  triangle2[CourseSession,Clinic,Location,c]
 L  triangle2[CourseSession,Clinic,Therapist,r]
 L  triangle2[CourseSession,Clinic,Therapist,c]
 L  triangle2[CourseSession,Clinic,Instructor,r]
 L  triangle2[CourseSession,Clinic,Instructor,c]
 L  triangle2[CourseSession,Location,Therapist,r]
 L  triangle2[CourseSession,Location,Therapist,c]
 L  triangle2[CourseSession,Location,Instructor,r]
 L  triangle2[CourseSession,Location,Instructor,c]
 L  triangle2[CourseSession,Therapist,Instructor,r]
 L  triangle2[CourseSession,Therapist,Instructor,c]
 L  triangle2[Clinic,Location,Therapist,r]
 L  triangle2[Clinic,Location,Therapist,c]
 L  triangle2[Clinic,Location,Instructor,r]
 L  triangle2[Clinic,Location,Instructor,c]
 L  triangle2[Clinic,Therapist,Instructor,r]
 L  triangle2[Clinic,Therapist,Instructor,c]
 L  triangle2[Location,Therapist,Instructor,r]
 L  triangle2[Location,Therapist,Instructor,c]
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[r,Client]  OBJ       -1
    x[r,Client]  CenterDistSumLB  1
    x[r,Client]  centerDistAxis2[r,Client]  2
    x[r,Client]  axisVdifLB[r,Client,CertificateTemplate]  1
    x[r,Client]  axisVdifLB[r,Client,Course]  1
    x[r,Client]  axisVdifLB[r,Client,Role]  1
    x[r,Client]  axisVdifLB[r,Client,User]  1
    x[r,Client]  axisVdifLB[r,Client,CourseSession]  1
    x[r,Client]  axisVdifLB[r,Client,Clinic]  1
    x[r,Client]  axisVdifLB[r,Client,Location]  1
    x[r,Client]  axisVdifLB[r,Client,Therapist]  1
    x[r,Client]  axisVdifLB[r,Client,Instructor]  1
    x[r,Client]  axisVdifRT[r,Client,CertificateTemplate]  -1
    x[r,Client]  axisVdifRT[r,Client,Course]  -1
    x[r,Client]  axisVdifRT[r,Client,Role]  -1
    x[r,Client]  axisVdifRT[r,Client,User]  -1
    x[r,Client]  axisVdifRT[r,Client,CourseSession]  -1
    x[r,Client]  axisVdifRT[r,Client,Clinic]  -1
    x[r,Client]  axisVdifRT[r,Client,Location]  -1
    x[r,Client]  axisVdifRT[r,Client,Therapist]  -1
    x[r,Client]  axisVdifRT[r,Client,Instructor]  -1
    x[r,Client]  compDistAxis1[r,Client,CertificateTemplate]  1
    x[r,Client]  compDistAxis1[r,Client,CourseSession]  1
    x[r,Client]  compDistAxis1[r,Client,Instructor]  1
    x[r,Client]  compDistAxis1[r,Client,Location]  1
    x[r,Client]  compDistAxis1[r,Client,User]  1
    x[r,Client]  compDistAxis2[r,Client,CertificateTemplate]  -1
    x[r,Client]  compDistAxis2[r,Client,CourseSession]  -1
    x[r,Client]  compDistAxis2[r,Client,Instructor]  -1
    x[r,Client]  compDistAxis2[r,Client,Location]  -1
    x[r,Client]  compDistAxis2[r,Client,User]  -1
    x[r,CertificateTemplate]  OBJ       -1
    x[r,CertificateTemplate]  CenterDistSumLB  1
    x[r,CertificateTemplate]  centerDistAxis2[r,CertificateTemplate]  2
    x[r,CertificateTemplate]  axisVdifLB[r,Client,CertificateTemplate]  -1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,Course]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,Role]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,User]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,CourseSession]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,Clinic]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,Location]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,Therapist]  1
    x[r,CertificateTemplate]  axisVdifLB[r,CertificateTemplate,Instructor]  1
    x[r,CertificateTemplate]  axisVdifRT[r,Client,CertificateTemplate]  1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,Course]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,Role]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,User]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,CourseSession]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,Clinic]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,Location]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,Therapist]  -1
    x[r,CertificateTemplate]  axisVdifRT[r,CertificateTemplate,Instructor]  -1
    x[r,CertificateTemplate]  compDistAxis1[r,Client,CertificateTemplate]  -1
    x[r,CertificateTemplate]  compDistAxis1[r,CertificateTemplate,CourseSession]  1
    x[r,CertificateTemplate]  compDistAxis2[r,Client,CertificateTemplate]  1
    x[r,CertificateTemplate]  compDistAxis2[r,CertificateTemplate,CourseSession]  -1
    x[r,Course]  OBJ       -1
    x[r,Course]  CenterDistSumLB  1
    x[r,Course]  centerDistAxis2[r,Course]  2
    x[r,Course]  axisVdifLB[r,Client,Course]  -1
    x[r,Course]  axisVdifLB[r,CertificateTemplate,Course]  -1
    x[r,Course]  axisVdifLB[r,Course,Role]  1
    x[r,Course]  axisVdifLB[r,Course,User]  1
    x[r,Course]  axisVdifLB[r,Course,CourseSession]  1
    x[r,Course]  axisVdifLB[r,Course,Clinic]  1
    x[r,Course]  axisVdifLB[r,Course,Location]  1
    x[r,Course]  axisVdifLB[r,Course,Therapist]  1
    x[r,Course]  axisVdifLB[r,Course,Instructor]  1
    x[r,Course]  axisVdifRT[r,Client,Course]  1
    x[r,Course]  axisVdifRT[r,CertificateTemplate,Course]  1
    x[r,Course]  axisVdifRT[r,Course,Role]  -1
    x[r,Course]  axisVdifRT[r,Course,User]  -1
    x[r,Course]  axisVdifRT[r,Course,CourseSession]  -1
    x[r,Course]  axisVdifRT[r,Course,Clinic]  -1
    x[r,Course]  axisVdifRT[r,Course,Location]  -1
    x[r,Course]  axisVdifRT[r,Course,Therapist]  -1
    x[r,Course]  axisVdifRT[r,Course,Instructor]  -1
    x[r,Course]  compDistAxis1[r,Course,CourseSession]  1
    x[r,Course]  compDistAxis2[r,Course,CourseSession]  -1
    x[r,Role]  OBJ       -1
    x[r,Role]  CenterDistSumLB  1
    x[r,Role]  centerDistAxis2[r,Role]  2
    x[r,Role]  axisVdifLB[r,Client,Role]  -1
    x[r,Role]  axisVdifLB[r,CertificateTemplate,Role]  -1
    x[r,Role]  axisVdifLB[r,Course,Role]  -1
    x[r,Role]  axisVdifLB[r,Role,User]  1
    x[r,Role]  axisVdifLB[r,Role,CourseSession]  1
    x[r,Role]  axisVdifLB[r,Role,Clinic]  1
    x[r,Role]  axisVdifLB[r,Role,Location]  1
    x[r,Role]  axisVdifLB[r,Role,Therapist]  1
    x[r,Role]  axisVdifLB[r,Role,Instructor]  1
    x[r,Role]  axisVdifRT[r,Client,Role]  1
    x[r,Role]  axisVdifRT[r,CertificateTemplate,Role]  1
    x[r,Role]  axisVdifRT[r,Course,Role]  1
    x[r,Role]  axisVdifRT[r,Role,User]  -1
    x[r,Role]  axisVdifRT[r,Role,CourseSession]  -1
    x[r,Role]  axisVdifRT[r,Role,Clinic]  -1
    x[r,Role]  axisVdifRT[r,Role,Location]  -1
    x[r,Role]  axisVdifRT[r,Role,Therapist]  -1
    x[r,Role]  axisVdifRT[r,Role,Instructor]  -1
    x[r,Role]  compDistAxis1[r,Role,User]  1
    x[r,Role]  compDistAxis2[r,Role,User]  -1
    x[r,User]  OBJ       -1
    x[r,User]  CenterDistSumLB  1
    x[r,User]  centerDistAxis2[r,User]  2
    x[r,User]  axisVdifLB[r,Client,User]  -1
    x[r,User]  axisVdifLB[r,CertificateTemplate,User]  -1
    x[r,User]  axisVdifLB[r,Course,User]  -1
    x[r,User]  axisVdifLB[r,Role,User]  -1
    x[r,User]  axisVdifLB[r,User,CourseSession]  1
    x[r,User]  axisVdifLB[r,User,Clinic]  1
    x[r,User]  axisVdifLB[r,User,Location]  1
    x[r,User]  axisVdifLB[r,User,Therapist]  1
    x[r,User]  axisVdifLB[r,User,Instructor]  1
    x[r,User]  axisVdifRT[r,Client,User]  1
    x[r,User]  axisVdifRT[r,CertificateTemplate,User]  1
    x[r,User]  axisVdifRT[r,Course,User]  1
    x[r,User]  axisVdifRT[r,Role,User]  1
    x[r,User]  axisVdifRT[r,User,CourseSession]  -1
    x[r,User]  axisVdifRT[r,User,Clinic]  -1
    x[r,User]  axisVdifRT[r,User,Location]  -1
    x[r,User]  axisVdifRT[r,User,Therapist]  -1
    x[r,User]  axisVdifRT[r,User,Instructor]  -1
    x[r,User]  compDistAxis1[r,Client,User]  -1
    x[r,User]  compDistAxis1[r,Role,User]  -1
    x[r,User]  compDistAxis1[r,User,Instructor]  1
    x[r,User]  compDistAxis1[r,User,Therapist]  1
    x[r,User]  compDistAxis2[r,Client,User]  1
    x[r,User]  compDistAxis2[r,Role,User]  1
    x[r,User]  compDistAxis2[r,User,Instructor]  -1
    x[r,User]  compDistAxis2[r,User,Therapist]  -1
    x[r,CourseSession]  OBJ       -1
    x[r,CourseSession]  CenterDistSumLB  1
    x[r,CourseSession]  centerDistAxis2[r,CourseSession]  2
    x[r,CourseSession]  axisVdifLB[r,Client,CourseSession]  -1
    x[r,CourseSession]  axisVdifLB[r,CertificateTemplate,CourseSession]  -1
    x[r,CourseSession]  axisVdifLB[r,Course,CourseSession]  -1
    x[r,CourseSession]  axisVdifLB[r,Role,CourseSession]  -1
    x[r,CourseSession]  axisVdifLB[r,User,CourseSession]  -1
    x[r,CourseSession]  axisVdifLB[r,CourseSession,Clinic]  1
    x[r,CourseSession]  axisVdifLB[r,CourseSession,Location]  1
    x[r,CourseSession]  axisVdifLB[r,CourseSession,Therapist]  1
    x[r,CourseSession]  axisVdifLB[r,CourseSession,Instructor]  1
    x[r,CourseSession]  axisVdifRT[r,Client,CourseSession]  1
    x[r,CourseSession]  axisVdifRT[r,CertificateTemplate,CourseSession]  1
    x[r,CourseSession]  axisVdifRT[r,Course,CourseSession]  1
    x[r,CourseSession]  axisVdifRT[r,Role,CourseSession]  1
    x[r,CourseSession]  axisVdifRT[r,User,CourseSession]  1
    x[r,CourseSession]  axisVdifRT[r,CourseSession,Clinic]  -1
    x[r,CourseSession]  axisVdifRT[r,CourseSession,Location]  -1
    x[r,CourseSession]  axisVdifRT[r,CourseSession,Therapist]  -1
    x[r,CourseSession]  axisVdifRT[r,CourseSession,Instructor]  -1
    x[r,CourseSession]  compDistAxis1[r,Client,CourseSession]  -1
    x[r,CourseSession]  compDistAxis1[r,CertificateTemplate,CourseSession]  -1
    x[r,CourseSession]  compDistAxis1[r,Course,CourseSession]  -1
    x[r,CourseSession]  compDistAxis1[r,CourseSession,Instructor]  1
    x[r,CourseSession]  compDistAxis1[r,Location,CourseSession]  -1
    x[r,CourseSession]  compDistAxis1[r,Therapist,CourseSession]  -1
    x[r,CourseSession]  compDistAxis2[r,Client,CourseSession]  1
    x[r,CourseSession]  compDistAxis2[r,CertificateTemplate,CourseSession]  1
    x[r,CourseSession]  compDistAxis2[r,Course,CourseSession]  1
    x[r,CourseSession]  compDistAxis2[r,CourseSession,Instructor]  -1
    x[r,CourseSession]  compDistAxis2[r,Location,CourseSession]  1
    x[r,CourseSession]  compDistAxis2[r,Therapist,CourseSession]  1
    x[r,Clinic]  OBJ       -1
    x[r,Clinic]  CenterDistSumLB  1
    x[r,Clinic]  centerDistAxis2[r,Clinic]  2
    x[r,Clinic]  axisVdifLB[r,Client,Clinic]  -1
    x[r,Clinic]  axisVdifLB[r,CertificateTemplate,Clinic]  -1
    x[r,Clinic]  axisVdifLB[r,Course,Clinic]  -1
    x[r,Clinic]  axisVdifLB[r,Role,Clinic]  -1
    x[r,Clinic]  axisVdifLB[r,User,Clinic]  -1
    x[r,Clinic]  axisVdifLB[r,CourseSession,Clinic]  -1
    x[r,Clinic]  axisVdifLB[r,Clinic,Location]  1
    x[r,Clinic]  axisVdifLB[r,Clinic,Therapist]  1
    x[r,Clinic]  axisVdifLB[r,Clinic,Instructor]  1
    x[r,Clinic]  axisVdifRT[r,Client,Clinic]  1
    x[r,Clinic]  axisVdifRT[r,CertificateTemplate,Clinic]  1
    x[r,Clinic]  axisVdifRT[r,Course,Clinic]  1
    x[r,Clinic]  axisVdifRT[r,Role,Clinic]  1
    x[r,Clinic]  axisVdifRT[r,User,Clinic]  1
    x[r,Clinic]  axisVdifRT[r,CourseSession,Clinic]  1
    x[r,Clinic]  axisVdifRT[r,Clinic,Location]  -1
    x[r,Clinic]  axisVdifRT[r,Clinic,Therapist]  -1
    x[r,Clinic]  axisVdifRT[r,Clinic,Instructor]  -1
    x[r,Clinic]  compDistAxis1[r,Clinic,Location]  1
    x[r,Clinic]  compDistAxis1[r,Clinic,Therapist]  1
    x[r,Clinic]  compDistAxis2[r,Clinic,Location]  -1
    x[r,Clinic]  compDistAxis2[r,Clinic,Therapist]  -1
    x[r,Location]  OBJ       -1
    x[r,Location]  CenterDistSumLB  1
    x[r,Location]  centerDistAxis2[r,Location]  2
    x[r,Location]  axisVdifLB[r,Client,Location]  -1
    x[r,Location]  axisVdifLB[r,CertificateTemplate,Location]  -1
    x[r,Location]  axisVdifLB[r,Course,Location]  -1
    x[r,Location]  axisVdifLB[r,Role,Location]  -1
    x[r,Location]  axisVdifLB[r,User,Location]  -1
    x[r,Location]  axisVdifLB[r,CourseSession,Location]  -1
    x[r,Location]  axisVdifLB[r,Clinic,Location]  -1
    x[r,Location]  axisVdifLB[r,Location,Therapist]  1
    x[r,Location]  axisVdifLB[r,Location,Instructor]  1
    x[r,Location]  axisVdifRT[r,Client,Location]  1
    x[r,Location]  axisVdifRT[r,CertificateTemplate,Location]  1
    x[r,Location]  axisVdifRT[r,Course,Location]  1
    x[r,Location]  axisVdifRT[r,Role,Location]  1
    x[r,Location]  axisVdifRT[r,User,Location]  1
    x[r,Location]  axisVdifRT[r,CourseSession,Location]  1
    x[r,Location]  axisVdifRT[r,Clinic,Location]  1
    x[r,Location]  axisVdifRT[r,Location,Therapist]  -1
    x[r,Location]  axisVdifRT[r,Location,Instructor]  -1
    x[r,Location]  compDistAxis1[r,Client,Location]  -1
    x[r,Location]  compDistAxis1[r,Instructor,Location]  -1
    x[r,Location]  compDistAxis1[r,Clinic,Location]  -1
    x[r,Location]  compDistAxis1[r,Location,Therapist]  1
    x[r,Location]  compDistAxis1[r,Location,CourseSession]  1
    x[r,Location]  compDistAxis2[r,Client,Location]  1
    x[r,Location]  compDistAxis2[r,Instructor,Location]  1
    x[r,Location]  compDistAxis2[r,Clinic,Location]  1
    x[r,Location]  compDistAxis2[r,Location,Therapist]  -1
    x[r,Location]  compDistAxis2[r,Location,CourseSession]  -1
    x[r,Therapist]  OBJ       -1
    x[r,Therapist]  CenterDistSumLB  1
    x[r,Therapist]  centerDistAxis2[r,Therapist]  2
    x[r,Therapist]  axisVdifLB[r,Client,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,CertificateTemplate,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,Course,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,Role,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,User,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,CourseSession,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,Clinic,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,Location,Therapist]  -1
    x[r,Therapist]  axisVdifLB[r,Therapist,Instructor]  1
    x[r,Therapist]  axisVdifRT[r,Client,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,CertificateTemplate,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,Course,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,Role,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,User,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,CourseSession,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,Clinic,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,Location,Therapist]  1
    x[r,Therapist]  axisVdifRT[r,Therapist,Instructor]  -1
    x[r,Therapist]  compDistAxis1[r,Clinic,Therapist]  -1
    x[r,Therapist]  compDistAxis1[r,Location,Therapist]  -1
    x[r,Therapist]  compDistAxis1[r,Therapist,CourseSession]  1
    x[r,Therapist]  compDistAxis1[r,User,Therapist]  -1
    x[r,Therapist]  compDistAxis2[r,Clinic,Therapist]  1
    x[r,Therapist]  compDistAxis2[r,Location,Therapist]  1
    x[r,Therapist]  compDistAxis2[r,Therapist,CourseSession]  -1
    x[r,Therapist]  compDistAxis2[r,User,Therapist]  1
    x[r,Instructor]  OBJ       -1
    x[r,Instructor]  CenterDistSumLB  1
    x[r,Instructor]  centerDistAxis2[r,Instructor]  2
    x[r,Instructor]  axisVdifLB[r,Client,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,CertificateTemplate,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,Course,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,Role,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,User,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,CourseSession,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,Clinic,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,Location,Instructor]  -1
    x[r,Instructor]  axisVdifLB[r,Therapist,Instructor]  -1
    x[r,Instructor]  axisVdifRT[r,Client,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,CertificateTemplate,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,Course,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,Role,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,User,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,CourseSession,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,Clinic,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,Location,Instructor]  1
    x[r,Instructor]  axisVdifRT[r,Therapist,Instructor]  1
    x[r,Instructor]  compDistAxis1[r,Client,Instructor]  -1
    x[r,Instructor]  compDistAxis1[r,CourseSession,Instructor]  -1
    x[r,Instructor]  compDistAxis1[r,Instructor,Location]  1
    x[r,Instructor]  compDistAxis1[r,User,Instructor]  -1
    x[r,Instructor]  compDistAxis2[r,Client,Instructor]  1
    x[r,Instructor]  compDistAxis2[r,CourseSession,Instructor]  1
    x[r,Instructor]  compDistAxis2[r,Instructor,Location]  -1
    x[r,Instructor]  compDistAxis2[r,User,Instructor]  1
    x[c,Client]  OBJ       -1
    x[c,Client]  CenterDistSumLB  1
    x[c,Client]  centerDistAxis2[c,Client]  2
    x[c,Client]  axisVdifLB[c,Client,CertificateTemplate]  1
    x[c,Client]  axisVdifLB[c,Client,Course]  1
    x[c,Client]  axisVdifLB[c,Client,Role]  1
    x[c,Client]  axisVdifLB[c,Client,User]  1
    x[c,Client]  axisVdifLB[c,Client,CourseSession]  1
    x[c,Client]  axisVdifLB[c,Client,Clinic]  1
    x[c,Client]  axisVdifLB[c,Client,Location]  1
    x[c,Client]  axisVdifLB[c,Client,Therapist]  1
    x[c,Client]  axisVdifLB[c,Client,Instructor]  1
    x[c,Client]  axisVdifRT[c,Client,CertificateTemplate]  -1
    x[c,Client]  axisVdifRT[c,Client,Course]  -1
    x[c,Client]  axisVdifRT[c,Client,Role]  -1
    x[c,Client]  axisVdifRT[c,Client,User]  -1
    x[c,Client]  axisVdifRT[c,Client,CourseSession]  -1
    x[c,Client]  axisVdifRT[c,Client,Clinic]  -1
    x[c,Client]  axisVdifRT[c,Client,Location]  -1
    x[c,Client]  axisVdifRT[c,Client,Therapist]  -1
    x[c,Client]  axisVdifRT[c,Client,Instructor]  -1
    x[c,Client]  compDistAxis1[c,Client,CertificateTemplate]  1
    x[c,Client]  compDistAxis1[c,Client,CourseSession]  1
    x[c,Client]  compDistAxis1[c,Client,Instructor]  1
    x[c,Client]  compDistAxis1[c,Client,Location]  1
    x[c,Client]  compDistAxis1[c,Client,User]  1
    x[c,Client]  compDistAxis2[c,Client,CertificateTemplate]  -1
    x[c,Client]  compDistAxis2[c,Client,CourseSession]  -1
    x[c,Client]  compDistAxis2[c,Client,Instructor]  -1
    x[c,Client]  compDistAxis2[c,Client,Location]  -1
    x[c,Client]  compDistAxis2[c,Client,User]  -1
    x[c,CertificateTemplate]  OBJ       -1
    x[c,CertificateTemplate]  CenterDistSumLB  1
    x[c,CertificateTemplate]  centerDistAxis2[c,CertificateTemplate]  2
    x[c,CertificateTemplate]  axisVdifLB[c,Client,CertificateTemplate]  -1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,Course]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,Role]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,User]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,CourseSession]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,Clinic]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,Location]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,Therapist]  1
    x[c,CertificateTemplate]  axisVdifLB[c,CertificateTemplate,Instructor]  1
    x[c,CertificateTemplate]  axisVdifRT[c,Client,CertificateTemplate]  1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,Course]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,Role]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,User]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,CourseSession]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,Clinic]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,Location]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,Therapist]  -1
    x[c,CertificateTemplate]  axisVdifRT[c,CertificateTemplate,Instructor]  -1
    x[c,CertificateTemplate]  compDistAxis1[c,Client,CertificateTemplate]  -1
    x[c,CertificateTemplate]  compDistAxis1[c,CertificateTemplate,CourseSession]  1
    x[c,CertificateTemplate]  compDistAxis2[c,Client,CertificateTemplate]  1
    x[c,CertificateTemplate]  compDistAxis2[c,CertificateTemplate,CourseSession]  -1
    x[c,Course]  OBJ       -1
    x[c,Course]  CenterDistSumLB  1
    x[c,Course]  centerDistAxis2[c,Course]  2
    x[c,Course]  axisVdifLB[c,Client,Course]  -1
    x[c,Course]  axisVdifLB[c,CertificateTemplate,Course]  -1
    x[c,Course]  axisVdifLB[c,Course,Role]  1
    x[c,Course]  axisVdifLB[c,Course,User]  1
    x[c,Course]  axisVdifLB[c,Course,CourseSession]  1
    x[c,Course]  axisVdifLB[c,Course,Clinic]  1
    x[c,Course]  axisVdifLB[c,Course,Location]  1
    x[c,Course]  axisVdifLB[c,Course,Therapist]  1
    x[c,Course]  axisVdifLB[c,Course,Instructor]  1
    x[c,Course]  axisVdifRT[c,Client,Course]  1
    x[c,Course]  axisVdifRT[c,CertificateTemplate,Course]  1
    x[c,Course]  axisVdifRT[c,Course,Role]  -1
    x[c,Course]  axisVdifRT[c,Course,User]  -1
    x[c,Course]  axisVdifRT[c,Course,CourseSession]  -1
    x[c,Course]  axisVdifRT[c,Course,Clinic]  -1
    x[c,Course]  axisVdifRT[c,Course,Location]  -1
    x[c,Course]  axisVdifRT[c,Course,Therapist]  -1
    x[c,Course]  axisVdifRT[c,Course,Instructor]  -1
    x[c,Course]  compDistAxis1[c,Course,CourseSession]  1
    x[c,Course]  compDistAxis2[c,Course,CourseSession]  -1
    x[c,Role]  OBJ       -1
    x[c,Role]  CenterDistSumLB  1
    x[c,Role]  centerDistAxis2[c,Role]  2
    x[c,Role]  axisVdifLB[c,Client,Role]  -1
    x[c,Role]  axisVdifLB[c,CertificateTemplate,Role]  -1
    x[c,Role]  axisVdifLB[c,Course,Role]  -1
    x[c,Role]  axisVdifLB[c,Role,User]  1
    x[c,Role]  axisVdifLB[c,Role,CourseSession]  1
    x[c,Role]  axisVdifLB[c,Role,Clinic]  1
    x[c,Role]  axisVdifLB[c,Role,Location]  1
    x[c,Role]  axisVdifLB[c,Role,Therapist]  1
    x[c,Role]  axisVdifLB[c,Role,Instructor]  1
    x[c,Role]  axisVdifRT[c,Client,Role]  1
    x[c,Role]  axisVdifRT[c,CertificateTemplate,Role]  1
    x[c,Role]  axisVdifRT[c,Course,Role]  1
    x[c,Role]  axisVdifRT[c,Role,User]  -1
    x[c,Role]  axisVdifRT[c,Role,CourseSession]  -1
    x[c,Role]  axisVdifRT[c,Role,Clinic]  -1
    x[c,Role]  axisVdifRT[c,Role,Location]  -1
    x[c,Role]  axisVdifRT[c,Role,Therapist]  -1
    x[c,Role]  axisVdifRT[c,Role,Instructor]  -1
    x[c,Role]  compDistAxis1[c,Role,User]  1
    x[c,Role]  compDistAxis2[c,Role,User]  -1
    x[c,User]  OBJ       -1
    x[c,User]  CenterDistSumLB  1
    x[c,User]  centerDistAxis2[c,User]  2
    x[c,User]  axisVdifLB[c,Client,User]  -1
    x[c,User]  axisVdifLB[c,CertificateTemplate,User]  -1
    x[c,User]  axisVdifLB[c,Course,User]  -1
    x[c,User]  axisVdifLB[c,Role,User]  -1
    x[c,User]  axisVdifLB[c,User,CourseSession]  1
    x[c,User]  axisVdifLB[c,User,Clinic]  1
    x[c,User]  axisVdifLB[c,User,Location]  1
    x[c,User]  axisVdifLB[c,User,Therapist]  1
    x[c,User]  axisVdifLB[c,User,Instructor]  1
    x[c,User]  axisVdifRT[c,Client,User]  1
    x[c,User]  axisVdifRT[c,CertificateTemplate,User]  1
    x[c,User]  axisVdifRT[c,Course,User]  1
    x[c,User]  axisVdifRT[c,Role,User]  1
    x[c,User]  axisVdifRT[c,User,CourseSession]  -1
    x[c,User]  axisVdifRT[c,User,Clinic]  -1
    x[c,User]  axisVdifRT[c,User,Location]  -1
    x[c,User]  axisVdifRT[c,User,Therapist]  -1
    x[c,User]  axisVdifRT[c,User,Instructor]  -1
    x[c,User]  compDistAxis1[c,Client,User]  -1
    x[c,User]  compDistAxis1[c,Role,User]  -1
    x[c,User]  compDistAxis1[c,User,Instructor]  1
    x[c,User]  compDistAxis1[c,User,Therapist]  1
    x[c,User]  compDistAxis2[c,Client,User]  1
    x[c,User]  compDistAxis2[c,Role,User]  1
    x[c,User]  compDistAxis2[c,User,Instructor]  -1
    x[c,User]  compDistAxis2[c,User,Therapist]  -1
    x[c,CourseSession]  OBJ       -1
    x[c,CourseSession]  CenterDistSumLB  1
    x[c,CourseSession]  centerDistAxis2[c,CourseSession]  2
    x[c,CourseSession]  axisVdifLB[c,Client,CourseSession]  -1
    x[c,CourseSession]  axisVdifLB[c,CertificateTemplate,CourseSession]  -1
    x[c,CourseSession]  axisVdifLB[c,Course,CourseSession]  -1
    x[c,CourseSession]  axisVdifLB[c,Role,CourseSession]  -1
    x[c,CourseSession]  axisVdifLB[c,User,CourseSession]  -1
    x[c,CourseSession]  axisVdifLB[c,CourseSession,Clinic]  1
    x[c,CourseSession]  axisVdifLB[c,CourseSession,Location]  1
    x[c,CourseSession]  axisVdifLB[c,CourseSession,Therapist]  1
    x[c,CourseSession]  axisVdifLB[c,CourseSession,Instructor]  1
    x[c,CourseSession]  axisVdifRT[c,Client,CourseSession]  1
    x[c,CourseSession]  axisVdifRT[c,CertificateTemplate,CourseSession]  1
    x[c,CourseSession]  axisVdifRT[c,Course,CourseSession]  1
    x[c,CourseSession]  axisVdifRT[c,Role,CourseSession]  1
    x[c,CourseSession]  axisVdifRT[c,User,CourseSession]  1
    x[c,CourseSession]  axisVdifRT[c,CourseSession,Clinic]  -1
    x[c,CourseSession]  axisVdifRT[c,CourseSession,Location]  -1
    x[c,CourseSession]  axisVdifRT[c,CourseSession,Therapist]  -1
    x[c,CourseSession]  axisVdifRT[c,CourseSession,Instructor]  -1
    x[c,CourseSession]  compDistAxis1[c,Client,CourseSession]  -1
    x[c,CourseSession]  compDistAxis1[c,CertificateTemplate,CourseSession]  -1
    x[c,CourseSession]  compDistAxis1[c,Course,CourseSession]  -1
    x[c,CourseSession]  compDistAxis1[c,CourseSession,Instructor]  1
    x[c,CourseSession]  compDistAxis1[c,Location,CourseSession]  -1
    x[c,CourseSession]  compDistAxis1[c,Therapist,CourseSession]  -1
    x[c,CourseSession]  compDistAxis2[c,Client,CourseSession]  1
    x[c,CourseSession]  compDistAxis2[c,CertificateTemplate,CourseSession]  1
    x[c,CourseSession]  compDistAxis2[c,Course,CourseSession]  1
    x[c,CourseSession]  compDistAxis2[c,CourseSession,Instructor]  -1
    x[c,CourseSession]  compDistAxis2[c,Location,CourseSession]  1
    x[c,CourseSession]  compDistAxis2[c,Therapist,CourseSession]  1
    x[c,Clinic]  OBJ       -1
    x[c,Clinic]  CenterDistSumLB  1
    x[c,Clinic]  centerDistAxis2[c,Clinic]  2
    x[c,Clinic]  axisVdifLB[c,Client,Clinic]  -1
    x[c,Clinic]  axisVdifLB[c,CertificateTemplate,Clinic]  -1
    x[c,Clinic]  axisVdifLB[c,Course,Clinic]  -1
    x[c,Clinic]  axisVdifLB[c,Role,Clinic]  -1
    x[c,Clinic]  axisVdifLB[c,User,Clinic]  -1
    x[c,Clinic]  axisVdifLB[c,CourseSession,Clinic]  -1
    x[c,Clinic]  axisVdifLB[c,Clinic,Location]  1
    x[c,Clinic]  axisVdifLB[c,Clinic,Therapist]  1
    x[c,Clinic]  axisVdifLB[c,Clinic,Instructor]  1
    x[c,Clinic]  axisVdifRT[c,Client,Clinic]  1
    x[c,Clinic]  axisVdifRT[c,CertificateTemplate,Clinic]  1
    x[c,Clinic]  axisVdifRT[c,Course,Clinic]  1
    x[c,Clinic]  axisVdifRT[c,Role,Clinic]  1
    x[c,Clinic]  axisVdifRT[c,User,Clinic]  1
    x[c,Clinic]  axisVdifRT[c,CourseSession,Clinic]  1
    x[c,Clinic]  axisVdifRT[c,Clinic,Location]  -1
    x[c,Clinic]  axisVdifRT[c,Clinic,Therapist]  -1
    x[c,Clinic]  axisVdifRT[c,Clinic,Instructor]  -1
    x[c,Clinic]  compDistAxis1[c,Clinic,Location]  1
    x[c,Clinic]  compDistAxis1[c,Clinic,Therapist]  1
    x[c,Clinic]  compDistAxis2[c,Clinic,Location]  -1
    x[c,Clinic]  compDistAxis2[c,Clinic,Therapist]  -1
    x[c,Location]  OBJ       -1
    x[c,Location]  CenterDistSumLB  1
    x[c,Location]  centerDistAxis2[c,Location]  2
    x[c,Location]  axisVdifLB[c,Client,Location]  -1
    x[c,Location]  axisVdifLB[c,CertificateTemplate,Location]  -1
    x[c,Location]  axisVdifLB[c,Course,Location]  -1
    x[c,Location]  axisVdifLB[c,Role,Location]  -1
    x[c,Location]  axisVdifLB[c,User,Location]  -1
    x[c,Location]  axisVdifLB[c,CourseSession,Location]  -1
    x[c,Location]  axisVdifLB[c,Clinic,Location]  -1
    x[c,Location]  axisVdifLB[c,Location,Therapist]  1
    x[c,Location]  axisVdifLB[c,Location,Instructor]  1
    x[c,Location]  axisVdifRT[c,Client,Location]  1
    x[c,Location]  axisVdifRT[c,CertificateTemplate,Location]  1
    x[c,Location]  axisVdifRT[c,Course,Location]  1
    x[c,Location]  axisVdifRT[c,Role,Location]  1
    x[c,Location]  axisVdifRT[c,User,Location]  1
    x[c,Location]  axisVdifRT[c,CourseSession,Location]  1
    x[c,Location]  axisVdifRT[c,Clinic,Location]  1
    x[c,Location]  axisVdifRT[c,Location,Therapist]  -1
    x[c,Location]  axisVdifRT[c,Location,Instructor]  -1
    x[c,Location]  compDistAxis1[c,Client,Location]  -1
    x[c,Location]  compDistAxis1[c,Instructor,Location]  -1
    x[c,Location]  compDistAxis1[c,Clinic,Location]  -1
    x[c,Location]  compDistAxis1[c,Location,Therapist]  1
    x[c,Location]  compDistAxis1[c,Location,CourseSession]  1
    x[c,Location]  compDistAxis2[c,Client,Location]  1
    x[c,Location]  compDistAxis2[c,Instructor,Location]  1
    x[c,Location]  compDistAxis2[c,Clinic,Location]  1
    x[c,Location]  compDistAxis2[c,Location,Therapist]  -1
    x[c,Location]  compDistAxis2[c,Location,CourseSession]  -1
    x[c,Therapist]  OBJ       -1
    x[c,Therapist]  CenterDistSumLB  1
    x[c,Therapist]  centerDistAxis2[c,Therapist]  2
    x[c,Therapist]  axisVdifLB[c,Client,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,CertificateTemplate,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,Course,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,Role,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,User,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,CourseSession,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,Clinic,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,Location,Therapist]  -1
    x[c,Therapist]  axisVdifLB[c,Therapist,Instructor]  1
    x[c,Therapist]  axisVdifRT[c,Client,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,CertificateTemplate,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,Course,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,Role,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,User,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,CourseSession,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,Clinic,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,Location,Therapist]  1
    x[c,Therapist]  axisVdifRT[c,Therapist,Instructor]  -1
    x[c,Therapist]  compDistAxis1[c,Clinic,Therapist]  -1
    x[c,Therapist]  compDistAxis1[c,Location,Therapist]  -1
    x[c,Therapist]  compDistAxis1[c,Therapist,CourseSession]  1
    x[c,Therapist]  compDistAxis1[c,User,Therapist]  -1
    x[c,Therapist]  compDistAxis2[c,Clinic,Therapist]  1
    x[c,Therapist]  compDistAxis2[c,Location,Therapist]  1
    x[c,Therapist]  compDistAxis2[c,Therapist,CourseSession]  -1
    x[c,Therapist]  compDistAxis2[c,User,Therapist]  1
    x[c,Instructor]  OBJ       -1
    x[c,Instructor]  CenterDistSumLB  1
    x[c,Instructor]  centerDistAxis2[c,Instructor]  2
    x[c,Instructor]  axisVdifLB[c,Client,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,CertificateTemplate,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,Course,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,Role,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,User,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,CourseSession,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,Clinic,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,Location,Instructor]  -1
    x[c,Instructor]  axisVdifLB[c,Therapist,Instructor]  -1
    x[c,Instructor]  axisVdifRT[c,Client,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,CertificateTemplate,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,Course,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,Role,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,User,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,CourseSession,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,Clinic,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,Location,Instructor]  1
    x[c,Instructor]  axisVdifRT[c,Therapist,Instructor]  1
    x[c,Instructor]  compDistAxis1[c,Client,Instructor]  -1
    x[c,Instructor]  compDistAxis1[c,CourseSession,Instructor]  -1
    x[c,Instructor]  compDistAxis1[c,Instructor,Location]  1
    x[c,Instructor]  compDistAxis1[c,User,Instructor]  -1
    x[c,Instructor]  compDistAxis2[c,Client,Instructor]  1
    x[c,Instructor]  compDistAxis2[c,CourseSession,Instructor]  1
    x[c,Instructor]  compDistAxis2[c,Instructor,Location]  -1
    x[c,Instructor]  compDistAxis2[c,User,Instructor]  1
    MARKER    'MARKER'                 'INTEND'
    center_dist[r,Client]  OBJ       1
    center_dist[r,Client]  centerDistAxis2[r,Client]  -1
    center_dist[r,Client]  CenterDistSumLB  -1
    center_dist[r,CertificateTemplate]  OBJ       1
    center_dist[r,CertificateTemplate]  centerDistAxis2[r,CertificateTemplate]  -1
    center_dist[r,CertificateTemplate]  CenterDistSumLB  -1
    center_dist[r,Course]  OBJ       1
    center_dist[r,Course]  centerDistAxis2[r,Course]  -1
    center_dist[r,Course]  CenterDistSumLB  -1
    center_dist[r,Role]  OBJ       1
    center_dist[r,Role]  centerDistAxis2[r,Role]  -1
    center_dist[r,Role]  CenterDistSumLB  -1
    center_dist[r,User]  OBJ       1
    center_dist[r,User]  centerDistAxis2[r,User]  -1
    center_dist[r,User]  CenterDistSumLB  -1
    center_dist[r,CourseSession]  OBJ       1
    center_dist[r,CourseSession]  centerDistAxis2[r,CourseSession]  -1
    center_dist[r,CourseSession]  CenterDistSumLB  -1
    center_dist[r,Clinic]  OBJ       1
    center_dist[r,Clinic]  centerDistAxis2[r,Clinic]  -1
    center_dist[r,Clinic]  CenterDistSumLB  -1
    center_dist[r,Location]  OBJ       1
    center_dist[r,Location]  centerDistAxis2[r,Location]  -1
    center_dist[r,Location]  CenterDistSumLB  -1
    center_dist[r,Therapist]  OBJ       1
    center_dist[r,Therapist]  centerDistAxis2[r,Therapist]  -1
    center_dist[r,Therapist]  CenterDistSumLB  -1
    center_dist[r,Instructor]  OBJ       1
    center_dist[r,Instructor]  centerDistAxis2[r,Instructor]  -1
    center_dist[r,Instructor]  CenterDistSumLB  -1
    center_dist[c,Client]  OBJ       1
    center_dist[c,Client]  centerDistAxis2[c,Client]  -1
    center_dist[c,Client]  CenterDistSumLB  -1
    center_dist[c,CertificateTemplate]  OBJ       1
    center_dist[c,CertificateTemplate]  centerDistAxis2[c,CertificateTemplate]  -1
    center_dist[c,CertificateTemplate]  CenterDistSumLB  -1
    center_dist[c,Course]  OBJ       1
    center_dist[c,Course]  centerDistAxis2[c,Course]  -1
    center_dist[c,Course]  CenterDistSumLB  -1
    center_dist[c,Role]  OBJ       1
    center_dist[c,Role]  centerDistAxis2[c,Role]  -1
    center_dist[c,Role]  CenterDistSumLB  -1
    center_dist[c,User]  OBJ       1
    center_dist[c,User]  centerDistAxis2[c,User]  -1
    center_dist[c,User]  CenterDistSumLB  -1
    center_dist[c,CourseSession]  OBJ       1
    center_dist[c,CourseSession]  centerDistAxis2[c,CourseSession]  -1
    center_dist[c,CourseSession]  CenterDistSumLB  -1
    center_dist[c,Clinic]  OBJ       1
    center_dist[c,Clinic]  centerDistAxis2[c,Clinic]  -1
    center_dist[c,Clinic]  CenterDistSumLB  -1
    center_dist[c,Location]  OBJ       1
    center_dist[c,Location]  centerDistAxis2[c,Location]  -1
    center_dist[c,Location]  CenterDistSumLB  -1
    center_dist[c,Therapist]  OBJ       1
    center_dist[c,Therapist]  centerDistAxis2[c,Therapist]  -1
    center_dist[c,Therapist]  CenterDistSumLB  -1
    center_dist[c,Instructor]  OBJ       1
    center_dist[c,Instructor]  centerDistAxis2[c,Instructor]  -1
    center_dist[c,Instructor]  CenterDistSumLB  -1
    dist[r,Client,CertificateTemplate]  OBJ       86
    dist[r,Client,CertificateTemplate]  compDistAxis1[r,Client,CertificateTemplate]  -1
    dist[r,Client,CertificateTemplate]  compDistAxis2[r,Client,CertificateTemplate]  -1
    dist[r,Client,CertificateTemplate]  DistSumLB[Client,CertificateTemplate]  -1
    dist[r,Client,CertificateTemplate]  DistAxisLB1[r,Client,CertificateTemplate]  -1
    dist[r,Client,CourseSession]  OBJ       86
    dist[r,Client,CourseSession]  compDistAxis1[r,Client,CourseSession]  -1
    dist[r,Client,CourseSession]  compDistAxis2[r,Client,CourseSession]  -1
    dist[r,Client,CourseSession]  DistSumLB[Client,CourseSession]  -1
    dist[r,Client,CourseSession]  DistAxisLB1[r,Client,CourseSession]  -1
    dist[r,Client,Instructor]  OBJ       86
    dist[r,Client,Instructor]  compDistAxis1[r,Client,Instructor]  -1
    dist[r,Client,Instructor]  compDistAxis2[r,Client,Instructor]  -1
    dist[r,Client,Instructor]  DistSumLB[Client,Instructor]  -1
    dist[r,Client,Instructor]  DistAxisLB1[r,Client,Instructor]  -1
    dist[r,Client,Location]  OBJ       86
    dist[r,Client,Location]  compDistAxis1[r,Client,Location]  -1
    dist[r,Client,Location]  compDistAxis2[r,Client,Location]  -1
    dist[r,Client,Location]  DistSumLB[Client,Location]  -1
    dist[r,Client,Location]  DistAxisLB1[r,Client,Location]  -1
    dist[r,Client,User]  OBJ       86
    dist[r,Client,User]  compDistAxis1[r,Client,User]  -1
    dist[r,Client,User]  compDistAxis2[r,Client,User]  -1
    dist[r,Client,User]  DistSumLB[Client,User]  -1
    dist[r,Client,User]  DistAxisLB1[r,Client,User]  -1
    dist[r,CertificateTemplate,CourseSession]  OBJ       86
    dist[r,CertificateTemplate,CourseSession]  compDistAxis1[r,CertificateTemplate,CourseSession]  -1
    dist[r,CertificateTemplate,CourseSession]  compDistAxis2[r,CertificateTemplate,CourseSession]  -1
    dist[r,CertificateTemplate,CourseSession]  DistSumLB[CertificateTemplate,CourseSession]  -1
    dist[r,CertificateTemplate,CourseSession]  DistAxisLB1[r,CertificateTemplate,CourseSession]  -1
    dist[r,Course,CourseSession]  OBJ       86
    dist[r,Course,CourseSession]  compDistAxis1[r,Course,CourseSession]  -1
    dist[r,Course,CourseSession]  compDistAxis2[r,Course,CourseSession]  -1
    dist[r,Course,CourseSession]  DistSumLB[Course,CourseSession]  -1
    dist[r,Course,CourseSession]  DistAxisLB1[r,Course,CourseSession]  -1
    dist[r,CourseSession,Instructor]  OBJ       86
    dist[r,CourseSession,Instructor]  compDistAxis1[r,CourseSession,Instructor]  -1
    dist[r,CourseSession,Instructor]  compDistAxis2[r,CourseSession,Instructor]  -1
    dist[r,CourseSession,Instructor]  DistSumLB[CourseSession,Instructor]  -1
    dist[r,CourseSession,Instructor]  DistAxisLB1[r,CourseSession,Instructor]  -1
    dist[r,Instructor,Location]  OBJ       86
    dist[r,Instructor,Location]  compDistAxis1[r,Instructor,Location]  -1
    dist[r,Instructor,Location]  compDistAxis2[r,Instructor,Location]  -1
    dist[r,Instructor,Location]  DistSumLB[Instructor,Location]  -1
    dist[r,Instructor,Location]  DistAxisLB1[r,Instructor,Location]  -1
    dist[r,Clinic,Location]  OBJ       86
    dist[r,Clinic,Location]  compDistAxis1[r,Clinic,Location]  -1
    dist[r,Clinic,Location]  compDistAxis2[r,Clinic,Location]  -1
    dist[r,Clinic,Location]  DistSumLB[Clinic,Location]  -1
    dist[r,Clinic,Location]  DistAxisLB1[r,Clinic,Location]  -1
    dist[r,Clinic,Therapist]  OBJ       86
    dist[r,Clinic,Therapist]  compDistAxis1[r,Clinic,Therapist]  -1
    dist[r,Clinic,Therapist]  compDistAxis2[r,Clinic,Therapist]  -1
    dist[r,Clinic,Therapist]  DistSumLB[Clinic,Therapist]  -1
    dist[r,Clinic,Therapist]  DistAxisLB1[r,Clinic,Therapist]  -1
    dist[r,Location,Therapist]  OBJ       86
    dist[r,Location,Therapist]  compDistAxis1[r,Location,Therapist]  -1
    dist[r,Location,Therapist]  compDistAxis2[r,Location,Therapist]  -1
    dist[r,Location,Therapist]  DistSumLB[Location,Therapist]  -1
    dist[r,Location,Therapist]  DistAxisLB1[r,Location,Therapist]  -1
    dist[r,Location,CourseSession]  OBJ       86
    dist[r,Location,CourseSession]  compDistAxis1[r,Location,CourseSession]  -1
    dist[r,Location,CourseSession]  compDistAxis2[r,Location,CourseSession]  -1
    dist[r,Location,CourseSession]  DistSumLB[Location,CourseSession]  -1
    dist[r,Location,CourseSession]  DistAxisLB1[r,Location,CourseSession]  -1
    dist[r,Therapist,CourseSession]  OBJ       86
    dist[r,Therapist,CourseSession]  compDistAxis1[r,Therapist,CourseSession]  -1
    dist[r,Therapist,CourseSession]  compDistAxis2[r,Therapist,CourseSession]  -1
    dist[r,Therapist,CourseSession]  DistSumLB[Therapist,CourseSession]  -1
    dist[r,Therapist,CourseSession]  DistAxisLB1[r,Therapist,CourseSession]  -1
    dist[r,Role,User]  OBJ       86
    dist[r,Role,User]  compDistAxis1[r,Role,User]  -1
    dist[r,Role,User]  compDistAxis2[r,Role,User]  -1
    dist[r,Role,User]  DistSumLB[Role,User]  -1
    dist[r,Role,User]  DistAxisLB1[r,Role,User]  -1
    dist[r,User,Instructor]  OBJ       86
    dist[r,User,Instructor]  compDistAxis1[r,User,Instructor]  -1
    dist[r,User,Instructor]  compDistAxis2[r,User,Instructor]  -1
    dist[r,User,Instructor]  DistSumLB[User,Instructor]  -1
    dist[r,User,Instructor]  DistAxisLB1[r,User,Instructor]  -1
    dist[r,User,Therapist]  OBJ       86
    dist[r,User,Therapist]  compDistAxis1[r,User,Therapist]  -1
    dist[r,User,Therapist]  compDistAxis2[r,User,Therapist]  -1
    dist[r,User,Therapist]  DistSumLB[User,Therapist]  -1
    dist[r,User,Therapist]  DistAxisLB1[r,User,Therapist]  -1
    dist[c,Client,CertificateTemplate]  OBJ       86
    dist[c,Client,CertificateTemplate]  compDistAxis1[c,Client,CertificateTemplate]  -1
    dist[c,Client,CertificateTemplate]  compDistAxis2[c,Client,CertificateTemplate]  -1
    dist[c,Client,CertificateTemplate]  DistSumLB[Client,CertificateTemplate]  -1
    dist[c,Client,CertificateTemplate]  DistAxisLB1[c,Client,CertificateTemplate]  -1
    dist[c,Client,CourseSession]  OBJ       86
    dist[c,Client,CourseSession]  compDistAxis1[c,Client,CourseSession]  -1
    dist[c,Client,CourseSession]  compDistAxis2[c,Client,CourseSession]  -1
    dist[c,Client,CourseSession]  DistSumLB[Client,CourseSession]  -1
    dist[c,Client,CourseSession]  DistAxisLB1[c,Client,CourseSession]  -1
    dist[c,Client,Instructor]  OBJ       86
    dist[c,Client,Instructor]  compDistAxis1[c,Client,Instructor]  -1
    dist[c,Client,Instructor]  compDistAxis2[c,Client,Instructor]  -1
    dist[c,Client,Instructor]  DistSumLB[Client,Instructor]  -1
    dist[c,Client,Instructor]  DistAxisLB1[c,Client,Instructor]  -1
    dist[c,Client,Location]  OBJ       86
    dist[c,Client,Location]  compDistAxis1[c,Client,Location]  -1
    dist[c,Client,Location]  compDistAxis2[c,Client,Location]  -1
    dist[c,Client,Location]  DistSumLB[Client,Location]  -1
    dist[c,Client,Location]  DistAxisLB1[c,Client,Location]  -1
    dist[c,Client,User]  OBJ       86
    dist[c,Client,User]  compDistAxis1[c,Client,User]  -1
    dist[c,Client,User]  compDistAxis2[c,Client,User]  -1
    dist[c,Client,User]  DistSumLB[Client,User]  -1
    dist[c,Client,User]  DistAxisLB1[c,Client,User]  -1
    dist[c,CertificateTemplate,CourseSession]  OBJ       86
    dist[c,CertificateTemplate,CourseSession]  compDistAxis1[c,CertificateTemplate,CourseSession]  -1
    dist[c,CertificateTemplate,CourseSession]  compDistAxis2[c,CertificateTemplate,CourseSession]  -1
    dist[c,CertificateTemplate,CourseSession]  DistSumLB[CertificateTemplate,CourseSession]  -1
    dist[c,CertificateTemplate,CourseSession]  DistAxisLB1[c,CertificateTemplate,CourseSession]  -1
    dist[c,Course,CourseSession]  OBJ       86
    dist[c,Course,CourseSession]  compDistAxis1[c,Course,CourseSession]  -1
    dist[c,Course,CourseSession]  compDistAxis2[c,Course,CourseSession]  -1
    dist[c,Course,CourseSession]  DistSumLB[Course,CourseSession]  -1
    dist[c,Course,CourseSession]  DistAxisLB1[c,Course,CourseSession]  -1
    dist[c,CourseSession,Instructor]  OBJ       86
    dist[c,CourseSession,Instructor]  compDistAxis1[c,CourseSession,Instructor]  -1
    dist[c,CourseSession,Instructor]  compDistAxis2[c,CourseSession,Instructor]  -1
    dist[c,CourseSession,Instructor]  DistSumLB[CourseSession,Instructor]  -1
    dist[c,CourseSession,Instructor]  DistAxisLB1[c,CourseSession,Instructor]  -1
    dist[c,Instructor,Location]  OBJ       86
    dist[c,Instructor,Location]  compDistAxis1[c,Instructor,Location]  -1
    dist[c,Instructor,Location]  compDistAxis2[c,Instructor,Location]  -1
    dist[c,Instructor,Location]  DistSumLB[Instructor,Location]  -1
    dist[c,Instructor,Location]  DistAxisLB1[c,Instructor,Location]  -1
    dist[c,Clinic,Location]  OBJ       86
    dist[c,Clinic,Location]  compDistAxis1[c,Clinic,Location]  -1
    dist[c,Clinic,Location]  compDistAxis2[c,Clinic,Location]  -1
    dist[c,Clinic,Location]  DistSumLB[Clinic,Location]  -1
    dist[c,Clinic,Location]  DistAxisLB1[c,Clinic,Location]  -1
    dist[c,Clinic,Therapist]  OBJ       86
    dist[c,Clinic,Therapist]  compDistAxis1[c,Clinic,Therapist]  -1
    dist[c,Clinic,Therapist]  compDistAxis2[c,Clinic,Therapist]  -1
    dist[c,Clinic,Therapist]  DistSumLB[Clinic,Therapist]  -1
    dist[c,Clinic,Therapist]  DistAxisLB1[c,Clinic,Therapist]  -1
    dist[c,Location,Therapist]  OBJ       86
    dist[c,Location,Therapist]  compDistAxis1[c,Location,Therapist]  -1
    dist[c,Location,Therapist]  compDistAxis2[c,Location,Therapist]  -1
    dist[c,Location,Therapist]  DistSumLB[Location,Therapist]  -1
    dist[c,Location,Therapist]  DistAxisLB1[c,Location,Therapist]  -1
    dist[c,Location,CourseSession]  OBJ       86
    dist[c,Location,CourseSession]  compDistAxis1[c,Location,CourseSession]  -1
    dist[c,Location,CourseSession]  compDistAxis2[c,Location,CourseSession]  -1
    dist[c,Location,CourseSession]  DistSumLB[Location,CourseSession]  -1
    dist[c,Location,CourseSession]  DistAxisLB1[c,Location,CourseSession]  -1
    dist[c,Therapist,CourseSession]  OBJ       86
    dist[c,Therapist,CourseSession]  compDistAxis1[c,Therapist,CourseSession]  -1
    dist[c,Therapist,CourseSession]  compDistAxis2[c,Therapist,CourseSession]  -1
    dist[c,Therapist,CourseSession]  DistSumLB[Therapist,CourseSession]  -1
    dist[c,Therapist,CourseSession]  DistAxisLB1[c,Therapist,CourseSession]  -1
    dist[c,Role,User]  OBJ       86
    dist[c,Role,User]  compDistAxis1[c,Role,User]  -1
    dist[c,Role,User]  compDistAxis2[c,Role,User]  -1
    dist[c,Role,User]  DistSumLB[Role,User]  -1
    dist[c,Role,User]  DistAxisLB1[c,Role,User]  -1
    dist[c,User,Instructor]  OBJ       86
    dist[c,User,Instructor]  compDistAxis1[c,User,Instructor]  -1
    dist[c,User,Instructor]  compDistAxis2[c,User,Instructor]  -1
    dist[c,User,Instructor]  DistSumLB[User,Instructor]  -1
    dist[c,User,Instructor]  DistAxisLB1[c,User,Instructor]  -1
    dist[c,User,Therapist]  OBJ       86
    dist[c,User,Therapist]  compDistAxis1[c,User,Therapist]  -1
    dist[c,User,Therapist]  compDistAxis2[c,User,Therapist]  -1
    dist[c,User,Therapist]  DistSumLB[User,Therapist]  -1
    dist[c,User,Therapist]  DistAxisLB1[c,User,Therapist]  -1
    MARKER    'MARKER'                 'INTORG'
    zV[r,rt,Client,CertificateTemplate]  choose1[Client,CertificateTemplate]  1
    zV[r,rt,Client,CertificateTemplate]  axisVdifRT[r,Client,CertificateTemplate]  42
    zV[r,rt,Client,CertificateTemplate]  DistAxisLB1[c,Client,CertificateTemplate]  -11.5
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Course,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Role,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,User,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,CourseSession,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Clinic,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Location,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Therapist,r]  1
    zV[r,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Instructor,r]  1
    zV[c,rt,Client,CertificateTemplate]  DistSumLB[Client,CertificateTemplate]  3.5
    zV[c,rt,Client,CertificateTemplate]  compDistAxis2[c,Client,CertificateTemplate]  4
    zV[c,rt,Client,CertificateTemplate]  choose1[Client,CertificateTemplate]  1
    zV[c,rt,Client,CertificateTemplate]  axisVdifRT[c,Client,CertificateTemplate]  42
    zV[c,rt,Client,CertificateTemplate]  DistAxisLB1[r,Client,CertificateTemplate]  -8
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Course,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Role,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,User,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,CourseSession,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Clinic,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Location,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Therapist,c]  1
    zV[c,rt,Client,CertificateTemplate]  triangle1[Client,CertificateTemplate,Instructor,c]  1
    zV[r,lb,Client,CertificateTemplate]  choose1[Client,CertificateTemplate]  1
    zV[r,lb,Client,CertificateTemplate]  axisVdifLB[r,Client,CertificateTemplate]  42
    zV[r,lb,Client,CertificateTemplate]  DistAxisLB1[c,Client,CertificateTemplate]  -11.5
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Course,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Role,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,User,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,CourseSession,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Clinic,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Location,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Therapist,r]  1
    zV[r,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Instructor,r]  1
    zV[c,lb,Client,CertificateTemplate]  DistSumLB[Client,CertificateTemplate]  3.5
    zV[c,lb,Client,CertificateTemplate]  compDistAxis1[c,Client,CertificateTemplate]  4
    zV[c,lb,Client,CertificateTemplate]  choose1[Client,CertificateTemplate]  1
    zV[c,lb,Client,CertificateTemplate]  axisVdifLB[c,Client,CertificateTemplate]  42
    zV[c,lb,Client,CertificateTemplate]  DistAxisLB1[r,Client,CertificateTemplate]  -8
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Course,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Role,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,User,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,CourseSession,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Clinic,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Location,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Therapist,c]  1
    zV[c,lb,Client,CertificateTemplate]  triangle2[Client,CertificateTemplate,Instructor,c]  1
    zV[r,rt,Client,Course]  choose1[Client,Course]  1
    zV[r,rt,Client,Course]  axisVdifRT[r,Client,Course]  42
    zV[r,rt,Client,Course]  triangle1[Client,Course,Role,r]  1
    zV[r,rt,Client,Course]  triangle1[Client,Course,User,r]  1
    zV[r,rt,Client,Course]  triangle1[Client,Course,CourseSession,r]  1
    zV[r,rt,Client,Course]  triangle1[Client,Course,Clinic,r]  1
    zV[r,rt,Client,Course]  triangle1[Client,Course,Location,r]  1
    zV[r,rt,Client,Course]  triangle1[Client,Course,Therapist,r]  1
    zV[r,rt,Client,Course]  triangle1[Client,Course,Instructor,r]  1
    zV[r,rt,Client,Course]  triangle2[Client,CertificateTemplate,Course,r]  1
    zV[c,rt,Client,Course]  choose1[Client,Course]  1
    zV[c,rt,Client,Course]  axisVdifRT[c,Client,Course]  42
    zV[c,rt,Client,Course]  triangle1[Client,Course,Role,c]  1
    zV[c,rt,Client,Course]  triangle1[Client,Course,User,c]  1
    zV[c,rt,Client,Course]  triangle1[Client,Course,CourseSession,c]  1
    zV[c,rt,Client,Course]  triangle1[Client,Course,Clinic,c]  1
    zV[c,rt,Client,Course]  triangle1[Client,Course,Location,c]  1
    zV[c,rt,Client,Course]  triangle1[Client,Course,Therapist,c]  1
    zV[c,rt,Client,Course]  triangle1[Client,Course,Instructor,c]  1
    zV[c,rt,Client,Course]  triangle2[Client,CertificateTemplate,Course,c]  1
    zV[r,lb,Client,Course]  choose1[Client,Course]  1
    zV[r,lb,Client,Course]  axisVdifLB[r,Client,Course]  42
    zV[r,lb,Client,Course]  triangle1[Client,CertificateTemplate,Course,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,Role,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,User,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,CourseSession,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,Clinic,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,Location,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,Therapist,r]  1
    zV[r,lb,Client,Course]  triangle2[Client,Course,Instructor,r]  1
    zV[c,lb,Client,Course]  choose1[Client,Course]  1
    zV[c,lb,Client,Course]  axisVdifLB[c,Client,Course]  42
    zV[c,lb,Client,Course]  triangle1[Client,CertificateTemplate,Course,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,Role,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,User,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,CourseSession,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,Clinic,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,Location,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,Therapist,c]  1
    zV[c,lb,Client,Course]  triangle2[Client,Course,Instructor,c]  1
    zV[r,rt,Client,Role]  choose1[Client,Role]  1
    zV[r,rt,Client,Role]  axisVdifRT[r,Client,Role]  42
    zV[r,rt,Client,Role]  triangle1[Client,Role,User,r]  1
    zV[r,rt,Client,Role]  triangle1[Client,Role,CourseSession,r]  1
    zV[r,rt,Client,Role]  triangle1[Client,Role,Clinic,r]  1
    zV[r,rt,Client,Role]  triangle1[Client,Role,Location,r]  1
    zV[r,rt,Client,Role]  triangle1[Client,Role,Therapist,r]  1
    zV[r,rt,Client,Role]  triangle1[Client,Role,Instructor,r]  1
    zV[r,rt,Client,Role]  triangle2[Client,CertificateTemplate,Role,r]  1
    zV[r,rt,Client,Role]  triangle2[Client,Course,Role,r]  1
    zV[c,rt,Client,Role]  choose1[Client,Role]  1
    zV[c,rt,Client,Role]  axisVdifRT[c,Client,Role]  42
    zV[c,rt,Client,Role]  triangle1[Client,Role,User,c]  1
    zV[c,rt,Client,Role]  triangle1[Client,Role,CourseSession,c]  1
    zV[c,rt,Client,Role]  triangle1[Client,Role,Clinic,c]  1
    zV[c,rt,Client,Role]  triangle1[Client,Role,Location,c]  1
    zV[c,rt,Client,Role]  triangle1[Client,Role,Therapist,c]  1
    zV[c,rt,Client,Role]  triangle1[Client,Role,Instructor,c]  1
    zV[c,rt,Client,Role]  triangle2[Client,CertificateTemplate,Role,c]  1
    zV[c,rt,Client,Role]  triangle2[Client,Course,Role,c]  1
    zV[r,lb,Client,Role]  choose1[Client,Role]  1
    zV[r,lb,Client,Role]  axisVdifLB[r,Client,Role]  42
    zV[r,lb,Client,Role]  triangle1[Client,CertificateTemplate,Role,r]  1
    zV[r,lb,Client,Role]  triangle1[Client,Course,Role,r]  1
    zV[r,lb,Client,Role]  triangle2[Client,Role,User,r]  1
    zV[r,lb,Client,Role]  triangle2[Client,Role,CourseSession,r]  1
    zV[r,lb,Client,Role]  triangle2[Client,Role,Clinic,r]  1
    zV[r,lb,Client,Role]  triangle2[Client,Role,Location,r]  1
    zV[r,lb,Client,Role]  triangle2[Client,Role,Therapist,r]  1
    zV[r,lb,Client,Role]  triangle2[Client,Role,Instructor,r]  1
    zV[c,lb,Client,Role]  choose1[Client,Role]  1
    zV[c,lb,Client,Role]  axisVdifLB[c,Client,Role]  42
    zV[c,lb,Client,Role]  triangle1[Client,CertificateTemplate,Role,c]  1
    zV[c,lb,Client,Role]  triangle1[Client,Course,Role,c]  1
    zV[c,lb,Client,Role]  triangle2[Client,Role,User,c]  1
    zV[c,lb,Client,Role]  triangle2[Client,Role,CourseSession,c]  1
    zV[c,lb,Client,Role]  triangle2[Client,Role,Clinic,c]  1
    zV[c,lb,Client,Role]  triangle2[Client,Role,Location,c]  1
    zV[c,lb,Client,Role]  triangle2[Client,Role,Therapist,c]  1
    zV[c,lb,Client,Role]  triangle2[Client,Role,Instructor,c]  1
    zV[r,rt,Client,User]  choose1[Client,User]  1
    zV[r,rt,Client,User]  axisVdifRT[r,Client,User]  42
    zV[r,rt,Client,User]  DistAxisLB1[c,Client,User]  -11
    zV[r,rt,Client,User]  triangle1[Client,User,CourseSession,r]  1
    zV[r,rt,Client,User]  triangle1[Client,User,Clinic,r]  1
    zV[r,rt,Client,User]  triangle1[Client,User,Location,r]  1
    zV[r,rt,Client,User]  triangle1[Client,User,Therapist,r]  1
    zV[r,rt,Client,User]  triangle1[Client,User,Instructor,r]  1
    zV[r,rt,Client,User]  triangle2[Client,CertificateTemplate,User,r]  1
    zV[r,rt,Client,User]  triangle2[Client,Course,User,r]  1
    zV[r,rt,Client,User]  triangle2[Client,Role,User,r]  1
    zV[c,rt,Client,User]  DistSumLB[Client,User]  3
    zV[c,rt,Client,User]  compDistAxis2[c,Client,User]  2
    zV[c,rt,Client,User]  choose1[Client,User]  1
    zV[c,rt,Client,User]  axisVdifRT[c,Client,User]  42
    zV[c,rt,Client,User]  DistAxisLB1[r,Client,User]  -8
    zV[c,rt,Client,User]  triangle1[Client,User,CourseSession,c]  1
    zV[c,rt,Client,User]  triangle1[Client,User,Clinic,c]  1
    zV[c,rt,Client,User]  triangle1[Client,User,Location,c]  1
    zV[c,rt,Client,User]  triangle1[Client,User,Therapist,c]  1
    zV[c,rt,Client,User]  triangle1[Client,User,Instructor,c]  1
    zV[c,rt,Client,User]  triangle2[Client,CertificateTemplate,User,c]  1
    zV[c,rt,Client,User]  triangle2[Client,Course,User,c]  1
    zV[c,rt,Client,User]  triangle2[Client,Role,User,c]  1
    zV[r,lb,Client,User]  choose1[Client,User]  1
    zV[r,lb,Client,User]  axisVdifLB[r,Client,User]  42
    zV[r,lb,Client,User]  DistAxisLB1[c,Client,User]  -11
    zV[r,lb,Client,User]  triangle1[Client,CertificateTemplate,User,r]  1
    zV[r,lb,Client,User]  triangle1[Client,Course,User,r]  1
    zV[r,lb,Client,User]  triangle1[Client,Role,User,r]  1
    zV[r,lb,Client,User]  triangle2[Client,User,CourseSession,r]  1
    zV[r,lb,Client,User]  triangle2[Client,User,Clinic,r]  1
    zV[r,lb,Client,User]  triangle2[Client,User,Location,r]  1
    zV[r,lb,Client,User]  triangle2[Client,User,Therapist,r]  1
    zV[r,lb,Client,User]  triangle2[Client,User,Instructor,r]  1
    zV[c,lb,Client,User]  DistSumLB[Client,User]  3
    zV[c,lb,Client,User]  compDistAxis1[c,Client,User]  2
    zV[c,lb,Client,User]  choose1[Client,User]  1
    zV[c,lb,Client,User]  axisVdifLB[c,Client,User]  42
    zV[c,lb,Client,User]  DistAxisLB1[r,Client,User]  -8
    zV[c,lb,Client,User]  triangle1[Client,CertificateTemplate,User,c]  1
    zV[c,lb,Client,User]  triangle1[Client,Course,User,c]  1
    zV[c,lb,Client,User]  triangle1[Client,Role,User,c]  1
    zV[c,lb,Client,User]  triangle2[Client,User,CourseSession,c]  1
    zV[c,lb,Client,User]  triangle2[Client,User,Clinic,c]  1
    zV[c,lb,Client,User]  triangle2[Client,User,Location,c]  1
    zV[c,lb,Client,User]  triangle2[Client,User,Therapist,c]  1
    zV[c,lb,Client,User]  triangle2[Client,User,Instructor,c]  1
    zV[r,rt,Client,CourseSession]  choose1[Client,CourseSession]  1
    zV[r,rt,Client,CourseSession]  axisVdifRT[r,Client,CourseSession]  42
    zV[r,rt,Client,CourseSession]  DistAxisLB1[c,Client,CourseSession]  -12.5
    zV[r,rt,Client,CourseSession]  triangle1[Client,CourseSession,Clinic,r]  1
    zV[r,rt,Client,CourseSession]  triangle1[Client,CourseSession,Location,r]  1
    zV[r,rt,Client,CourseSession]  triangle1[Client,CourseSession,Therapist,r]  1
    zV[r,rt,Client,CourseSession]  triangle1[Client,CourseSession,Instructor,r]  1
    zV[r,rt,Client,CourseSession]  triangle2[Client,CertificateTemplate,CourseSession,r]  1
    zV[r,rt,Client,CourseSession]  triangle2[Client,Course,CourseSession,r]  1
    zV[r,rt,Client,CourseSession]  triangle2[Client,Role,CourseSession,r]  1
    zV[r,rt,Client,CourseSession]  triangle2[Client,User,CourseSession,r]  1
    zV[c,rt,Client,CourseSession]  DistSumLB[Client,CourseSession]  3.5
    zV[c,rt,Client,CourseSession]  compDistAxis2[c,Client,CourseSession]  8
    zV[c,rt,Client,CourseSession]  choose1[Client,CourseSession]  1
    zV[c,rt,Client,CourseSession]  axisVdifRT[c,Client,CourseSession]  42
    zV[c,rt,Client,CourseSession]  DistAxisLB1[r,Client,CourseSession]  -9
    zV[c,rt,Client,CourseSession]  triangle1[Client,CourseSession,Clinic,c]  1
    zV[c,rt,Client,CourseSession]  triangle1[Client,CourseSession,Location,c]  1
    zV[c,rt,Client,CourseSession]  triangle1[Client,CourseSession,Therapist,c]  1
    zV[c,rt,Client,CourseSession]  triangle1[Client,CourseSession,Instructor,c]  1
    zV[c,rt,Client,CourseSession]  triangle2[Client,CertificateTemplate,CourseSession,c]  1
    zV[c,rt,Client,CourseSession]  triangle2[Client,Course,CourseSession,c]  1
    zV[c,rt,Client,CourseSession]  triangle2[Client,Role,CourseSession,c]  1
    zV[c,rt,Client,CourseSession]  triangle2[Client,User,CourseSession,c]  1
    zV[r,lb,Client,CourseSession]  choose1[Client,CourseSession]  1
    zV[r,lb,Client,CourseSession]  axisVdifLB[r,Client,CourseSession]  42
    zV[r,lb,Client,CourseSession]  DistAxisLB1[c,Client,CourseSession]  -12.5
    zV[r,lb,Client,CourseSession]  triangle1[Client,CertificateTemplate,CourseSession,r]  1
    zV[r,lb,Client,CourseSession]  triangle1[Client,Course,CourseSession,r]  1
    zV[r,lb,Client,CourseSession]  triangle1[Client,Role,CourseSession,r]  1
    zV[r,lb,Client,CourseSession]  triangle1[Client,User,CourseSession,r]  1
    zV[r,lb,Client,CourseSession]  triangle2[Client,CourseSession,Clinic,r]  1
    zV[r,lb,Client,CourseSession]  triangle2[Client,CourseSession,Location,r]  1
    zV[r,lb,Client,CourseSession]  triangle2[Client,CourseSession,Therapist,r]  1
    zV[r,lb,Client,CourseSession]  triangle2[Client,CourseSession,Instructor,r]  1
    zV[c,lb,Client,CourseSession]  DistSumLB[Client,CourseSession]  3.5
    zV[c,lb,Client,CourseSession]  compDistAxis1[c,Client,CourseSession]  8
    zV[c,lb,Client,CourseSession]  choose1[Client,CourseSession]  1
    zV[c,lb,Client,CourseSession]  axisVdifLB[c,Client,CourseSession]  42
    zV[c,lb,Client,CourseSession]  DistAxisLB1[r,Client,CourseSession]  -9
    zV[c,lb,Client,CourseSession]  triangle1[Client,CertificateTemplate,CourseSession,c]  1
    zV[c,lb,Client,CourseSession]  triangle1[Client,Course,CourseSession,c]  1
    zV[c,lb,Client,CourseSession]  triangle1[Client,Role,CourseSession,c]  1
    zV[c,lb,Client,CourseSession]  triangle1[Client,User,CourseSession,c]  1
    zV[c,lb,Client,CourseSession]  triangle2[Client,CourseSession,Clinic,c]  1
    zV[c,lb,Client,CourseSession]  triangle2[Client,CourseSession,Location,c]  1
    zV[c,lb,Client,CourseSession]  triangle2[Client,CourseSession,Therapist,c]  1
    zV[c,lb,Client,CourseSession]  triangle2[Client,CourseSession,Instructor,c]  1
    zV[r,rt,Client,Clinic]  choose1[Client,Clinic]  1
    zV[r,rt,Client,Clinic]  axisVdifRT[r,Client,Clinic]  42
    zV[r,rt,Client,Clinic]  triangle1[Client,Clinic,Location,r]  1
    zV[r,rt,Client,Clinic]  triangle1[Client,Clinic,Therapist,r]  1
    zV[r,rt,Client,Clinic]  triangle1[Client,Clinic,Instructor,r]  1
    zV[r,rt,Client,Clinic]  triangle2[Client,CertificateTemplate,Clinic,r]  1
    zV[r,rt,Client,Clinic]  triangle2[Client,Course,Clinic,r]  1
    zV[r,rt,Client,Clinic]  triangle2[Client,Role,Clinic,r]  1
    zV[r,rt,Client,Clinic]  triangle2[Client,User,Clinic,r]  1
    zV[r,rt,Client,Clinic]  triangle2[Client,CourseSession,Clinic,r]  1
    zV[c,rt,Client,Clinic]  choose1[Client,Clinic]  1
    zV[c,rt,Client,Clinic]  axisVdifRT[c,Client,Clinic]  42
    zV[c,rt,Client,Clinic]  triangle1[Client,Clinic,Location,c]  1
    zV[c,rt,Client,Clinic]  triangle1[Client,Clinic,Therapist,c]  1
    zV[c,rt,Client,Clinic]  triangle1[Client,Clinic,Instructor,c]  1
    zV[c,rt,Client,Clinic]  triangle2[Client,CertificateTemplate,Clinic,c]  1
    zV[c,rt,Client,Clinic]  triangle2[Client,Course,Clinic,c]  1
    zV[c,rt,Client,Clinic]  triangle2[Client,Role,Clinic,c]  1
    zV[c,rt,Client,Clinic]  triangle2[Client,User,Clinic,c]  1
    zV[c,rt,Client,Clinic]  triangle2[Client,CourseSession,Clinic,c]  1
    zV[r,lb,Client,Clinic]  choose1[Client,Clinic]  1
    zV[r,lb,Client,Clinic]  axisVdifLB[r,Client,Clinic]  42
    zV[r,lb,Client,Clinic]  triangle1[Client,CertificateTemplate,Clinic,r]  1
    zV[r,lb,Client,Clinic]  triangle1[Client,Course,Clinic,r]  1
    zV[r,lb,Client,Clinic]  triangle1[Client,Role,Clinic,r]  1
    zV[r,lb,Client,Clinic]  triangle1[Client,User,Clinic,r]  1
    zV[r,lb,Client,Clinic]  triangle1[Client,CourseSession,Clinic,r]  1
    zV[r,lb,Client,Clinic]  triangle2[Client,Clinic,Location,r]  1
    zV[r,lb,Client,Clinic]  triangle2[Client,Clinic,Therapist,r]  1
    zV[r,lb,Client,Clinic]  triangle2[Client,Clinic,Instructor,r]  1
    zV[c,lb,Client,Clinic]  choose1[Client,Clinic]  1
    zV[c,lb,Client,Clinic]  axisVdifLB[c,Client,Clinic]  42
    zV[c,lb,Client,Clinic]  triangle1[Client,CertificateTemplate,Clinic,c]  1
    zV[c,lb,Client,Clinic]  triangle1[Client,Course,Clinic,c]  1
    zV[c,lb,Client,Clinic]  triangle1[Client,Role,Clinic,c]  1
    zV[c,lb,Client,Clinic]  triangle1[Client,User,Clinic,c]  1
    zV[c,lb,Client,Clinic]  triangle1[Client,CourseSession,Clinic,c]  1
    zV[c,lb,Client,Clinic]  triangle2[Client,Clinic,Location,c]  1
    zV[c,lb,Client,Clinic]  triangle2[Client,Clinic,Therapist,c]  1
    zV[c,lb,Client,Clinic]  triangle2[Client,Clinic,Instructor,c]  1
    zV[r,rt,Client,Location]  choose1[Client,Location]  1
    zV[r,rt,Client,Location]  axisVdifRT[r,Client,Location]  42
    zV[r,rt,Client,Location]  DistAxisLB1[c,Client,Location]  -11
    zV[r,rt,Client,Location]  triangle1[Client,Location,Therapist,r]  1
    zV[r,rt,Client,Location]  triangle1[Client,Location,Instructor,r]  1
    zV[r,rt,Client,Location]  triangle2[Client,CertificateTemplate,Location,r]  1
    zV[r,rt,Client,Location]  triangle2[Client,Course,Location,r]  1
    zV[r,rt,Client,Location]  triangle2[Client,Role,Location,r]  1
    zV[r,rt,Client,Location]  triangle2[Client,User,Location,r]  1
    zV[r,rt,Client,Location]  triangle2[Client,CourseSession,Location,r]  1
    zV[r,rt,Client,Location]  triangle2[Client,Clinic,Location,r]  1
    zV[c,rt,Client,Location]  DistSumLB[Client,Location]  2
    zV[c,rt,Client,Location]  compDistAxis2[c,Client,Location]  2
    zV[c,rt,Client,Location]  choose1[Client,Location]  1
    zV[c,rt,Client,Location]  axisVdifRT[c,Client,Location]  42
    zV[c,rt,Client,Location]  DistAxisLB1[r,Client,Location]  -9
    zV[c,rt,Client,Location]  triangle1[Client,Location,Therapist,c]  1
    zV[c,rt,Client,Location]  triangle1[Client,Location,Instructor,c]  1
    zV[c,rt,Client,Location]  triangle2[Client,CertificateTemplate,Location,c]  1
    zV[c,rt,Client,Location]  triangle2[Client,Course,Location,c]  1
    zV[c,rt,Client,Location]  triangle2[Client,Role,Location,c]  1
    zV[c,rt,Client,Location]  triangle2[Client,User,Location,c]  1
    zV[c,rt,Client,Location]  triangle2[Client,CourseSession,Location,c]  1
    zV[c,rt,Client,Location]  triangle2[Client,Clinic,Location,c]  1
    zV[r,lb,Client,Location]  choose1[Client,Location]  1
    zV[r,lb,Client,Location]  axisVdifLB[r,Client,Location]  42
    zV[r,lb,Client,Location]  DistAxisLB1[c,Client,Location]  -11
    zV[r,lb,Client,Location]  triangle1[Client,CertificateTemplate,Location,r]  1
    zV[r,lb,Client,Location]  triangle1[Client,Course,Location,r]  1
    zV[r,lb,Client,Location]  triangle1[Client,Role,Location,r]  1
    zV[r,lb,Client,Location]  triangle1[Client,User,Location,r]  1
    zV[r,lb,Client,Location]  triangle1[Client,CourseSession,Location,r]  1
    zV[r,lb,Client,Location]  triangle1[Client,Clinic,Location,r]  1
    zV[r,lb,Client,Location]  triangle2[Client,Location,Therapist,r]  1
    zV[r,lb,Client,Location]  triangle2[Client,Location,Instructor,r]  1
    zV[c,lb,Client,Location]  DistSumLB[Client,Location]  2
    zV[c,lb,Client,Location]  compDistAxis1[c,Client,Location]  2
    zV[c,lb,Client,Location]  choose1[Client,Location]  1
    zV[c,lb,Client,Location]  axisVdifLB[c,Client,Location]  42
    zV[c,lb,Client,Location]  DistAxisLB1[r,Client,Location]  -9
    zV[c,lb,Client,Location]  triangle1[Client,CertificateTemplate,Location,c]  1
    zV[c,lb,Client,Location]  triangle1[Client,Course,Location,c]  1
    zV[c,lb,Client,Location]  triangle1[Client,Role,Location,c]  1
    zV[c,lb,Client,Location]  triangle1[Client,User,Location,c]  1
    zV[c,lb,Client,Location]  triangle1[Client,CourseSession,Location,c]  1
    zV[c,lb,Client,Location]  triangle1[Client,Clinic,Location,c]  1
    zV[c,lb,Client,Location]  triangle2[Client,Location,Therapist,c]  1
    zV[c,lb,Client,Location]  triangle2[Client,Location,Instructor,c]  1
    zV[r,rt,Client,Therapist]  choose1[Client,Therapist]  1
    zV[r,rt,Client,Therapist]  axisVdifRT[r,Client,Therapist]  42
    zV[r,rt,Client,Therapist]  triangle1[Client,Therapist,Instructor,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,CertificateTemplate,Therapist,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,Course,Therapist,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,Role,Therapist,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,User,Therapist,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,CourseSession,Therapist,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,Clinic,Therapist,r]  1
    zV[r,rt,Client,Therapist]  triangle2[Client,Location,Therapist,r]  1
    zV[c,rt,Client,Therapist]  choose1[Client,Therapist]  1
    zV[c,rt,Client,Therapist]  axisVdifRT[c,Client,Therapist]  42
    zV[c,rt,Client,Therapist]  triangle1[Client,Therapist,Instructor,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,CertificateTemplate,Therapist,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,Course,Therapist,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,Role,Therapist,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,User,Therapist,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,CourseSession,Therapist,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,Clinic,Therapist,c]  1
    zV[c,rt,Client,Therapist]  triangle2[Client,Location,Therapist,c]  1
    zV[r,lb,Client,Therapist]  choose1[Client,Therapist]  1
    zV[r,lb,Client,Therapist]  axisVdifLB[r,Client,Therapist]  42
    zV[r,lb,Client,Therapist]  triangle1[Client,CertificateTemplate,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle1[Client,Course,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle1[Client,Role,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle1[Client,User,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle1[Client,CourseSession,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle1[Client,Clinic,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle1[Client,Location,Therapist,r]  1
    zV[r,lb,Client,Therapist]  triangle2[Client,Therapist,Instructor,r]  1
    zV[c,lb,Client,Therapist]  choose1[Client,Therapist]  1
    zV[c,lb,Client,Therapist]  axisVdifLB[c,Client,Therapist]  42
    zV[c,lb,Client,Therapist]  triangle1[Client,CertificateTemplate,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle1[Client,Course,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle1[Client,Role,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle1[Client,User,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle1[Client,CourseSession,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle1[Client,Clinic,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle1[Client,Location,Therapist,c]  1
    zV[c,lb,Client,Therapist]  triangle2[Client,Therapist,Instructor,c]  1
    zV[r,rt,Client,Instructor]  choose1[Client,Instructor]  1
    zV[r,rt,Client,Instructor]  axisVdifRT[r,Client,Instructor]  42
    zV[r,rt,Client,Instructor]  DistAxisLB1[c,Client,Instructor]  -11.5
    zV[r,rt,Client,Instructor]  triangle2[Client,CertificateTemplate,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,Course,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,Role,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,User,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,CourseSession,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,Clinic,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,Location,Instructor,r]  1
    zV[r,rt,Client,Instructor]  triangle2[Client,Therapist,Instructor,r]  1
    zV[c,rt,Client,Instructor]  DistSumLB[Client,Instructor]  2
    zV[c,rt,Client,Instructor]  compDistAxis2[c,Client,Instructor]  4
    zV[c,rt,Client,Instructor]  choose1[Client,Instructor]  1
    zV[c,rt,Client,Instructor]  axisVdifRT[c,Client,Instructor]  42
    zV[c,rt,Client,Instructor]  DistAxisLB1[r,Client,Instructor]  -9.5
    zV[c,rt,Client,Instructor]  triangle2[Client,CertificateTemplate,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,Course,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,Role,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,User,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,CourseSession,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,Clinic,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,Location,Instructor,c]  1
    zV[c,rt,Client,Instructor]  triangle2[Client,Therapist,Instructor,c]  1
    zV[r,lb,Client,Instructor]  choose1[Client,Instructor]  1
    zV[r,lb,Client,Instructor]  axisVdifLB[r,Client,Instructor]  42
    zV[r,lb,Client,Instructor]  DistAxisLB1[c,Client,Instructor]  -11.5
    zV[r,lb,Client,Instructor]  triangle1[Client,CertificateTemplate,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,Course,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,Role,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,User,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,CourseSession,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,Clinic,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,Location,Instructor,r]  1
    zV[r,lb,Client,Instructor]  triangle1[Client,Therapist,Instructor,r]  1
    zV[c,lb,Client,Instructor]  DistSumLB[Client,Instructor]  2
    zV[c,lb,Client,Instructor]  compDistAxis1[c,Client,Instructor]  4
    zV[c,lb,Client,Instructor]  choose1[Client,Instructor]  1
    zV[c,lb,Client,Instructor]  axisVdifLB[c,Client,Instructor]  42
    zV[c,lb,Client,Instructor]  DistAxisLB1[r,Client,Instructor]  -9.5
    zV[c,lb,Client,Instructor]  triangle1[Client,CertificateTemplate,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,Course,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,Role,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,User,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,CourseSession,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,Clinic,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,Location,Instructor,c]  1
    zV[c,lb,Client,Instructor]  triangle1[Client,Therapist,Instructor,c]  1
    zV[r,rt,CertificateTemplate,Course]  choose1[CertificateTemplate,Course]  1
    zV[r,rt,CertificateTemplate,Course]  axisVdifRT[r,CertificateTemplate,Course]  42
    zV[r,rt,CertificateTemplate,Course]  triangle1[Client,CertificateTemplate,Course,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Role,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,User,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,CourseSession,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Clinic,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Location,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Instructor,r]  1
    zV[c,rt,CertificateTemplate,Course]  choose1[CertificateTemplate,Course]  1
    zV[c,rt,CertificateTemplate,Course]  axisVdifRT[c,CertificateTemplate,Course]  42
    zV[c,rt,CertificateTemplate,Course]  triangle1[Client,CertificateTemplate,Course,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Role,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,User,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,CourseSession,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Clinic,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Location,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Course]  triangle1[CertificateTemplate,Course,Instructor,c]  1
    zV[r,lb,CertificateTemplate,Course]  choose1[CertificateTemplate,Course]  1
    zV[r,lb,CertificateTemplate,Course]  axisVdifLB[r,CertificateTemplate,Course]  42
    zV[r,lb,CertificateTemplate,Course]  triangle2[Client,CertificateTemplate,Course,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Role,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,User,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Location,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Instructor,r]  1
    zV[c,lb,CertificateTemplate,Course]  choose1[CertificateTemplate,Course]  1
    zV[c,lb,CertificateTemplate,Course]  axisVdifLB[c,CertificateTemplate,Course]  42
    zV[c,lb,CertificateTemplate,Course]  triangle2[Client,CertificateTemplate,Course,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Role,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,User,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Location,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Course]  triangle2[CertificateTemplate,Course,Instructor,c]  1
    zV[r,rt,CertificateTemplate,Role]  choose1[CertificateTemplate,Role]  1
    zV[r,rt,CertificateTemplate,Role]  axisVdifRT[r,CertificateTemplate,Role]  42
    zV[r,rt,CertificateTemplate,Role]  triangle1[Client,CertificateTemplate,Role,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,User,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,CourseSession,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Clinic,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Location,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Role]  triangle2[CertificateTemplate,Course,Role,r]  1
    zV[c,rt,CertificateTemplate,Role]  choose1[CertificateTemplate,Role]  1
    zV[c,rt,CertificateTemplate,Role]  axisVdifRT[c,CertificateTemplate,Role]  42
    zV[c,rt,CertificateTemplate,Role]  triangle1[Client,CertificateTemplate,Role,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,User,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,CourseSession,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Clinic,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Location,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle1[CertificateTemplate,Role,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Role]  triangle2[CertificateTemplate,Course,Role,c]  1
    zV[r,lb,CertificateTemplate,Role]  choose1[CertificateTemplate,Role]  1
    zV[r,lb,CertificateTemplate,Role]  axisVdifLB[r,CertificateTemplate,Role]  42
    zV[r,lb,CertificateTemplate,Role]  triangle1[CertificateTemplate,Course,Role,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[Client,CertificateTemplate,Role,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,User,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Location,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Instructor,r]  1
    zV[c,lb,CertificateTemplate,Role]  choose1[CertificateTemplate,Role]  1
    zV[c,lb,CertificateTemplate,Role]  axisVdifLB[c,CertificateTemplate,Role]  42
    zV[c,lb,CertificateTemplate,Role]  triangle1[CertificateTemplate,Course,Role,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[Client,CertificateTemplate,Role,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,User,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Location,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Role]  triangle2[CertificateTemplate,Role,Instructor,c]  1
    zV[r,rt,CertificateTemplate,User]  choose1[CertificateTemplate,User]  1
    zV[r,rt,CertificateTemplate,User]  axisVdifRT[r,CertificateTemplate,User]  42
    zV[r,rt,CertificateTemplate,User]  triangle1[Client,CertificateTemplate,User,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,CourseSession,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Clinic,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Location,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Therapist,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Instructor,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle2[CertificateTemplate,Course,User,r]  1
    zV[r,rt,CertificateTemplate,User]  triangle2[CertificateTemplate,Role,User,r]  1
    zV[c,rt,CertificateTemplate,User]  choose1[CertificateTemplate,User]  1
    zV[c,rt,CertificateTemplate,User]  axisVdifRT[c,CertificateTemplate,User]  42
    zV[c,rt,CertificateTemplate,User]  triangle1[Client,CertificateTemplate,User,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,CourseSession,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Clinic,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Location,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Therapist,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle1[CertificateTemplate,User,Instructor,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle2[CertificateTemplate,Course,User,c]  1
    zV[c,rt,CertificateTemplate,User]  triangle2[CertificateTemplate,Role,User,c]  1
    zV[r,lb,CertificateTemplate,User]  choose1[CertificateTemplate,User]  1
    zV[r,lb,CertificateTemplate,User]  axisVdifLB[r,CertificateTemplate,User]  42
    zV[r,lb,CertificateTemplate,User]  triangle1[CertificateTemplate,Course,User,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle1[CertificateTemplate,Role,User,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle2[Client,CertificateTemplate,User,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Clinic,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Location,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Therapist,r]  1
    zV[r,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Instructor,r]  1
    zV[c,lb,CertificateTemplate,User]  choose1[CertificateTemplate,User]  1
    zV[c,lb,CertificateTemplate,User]  axisVdifLB[c,CertificateTemplate,User]  42
    zV[c,lb,CertificateTemplate,User]  triangle1[CertificateTemplate,Course,User,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle1[CertificateTemplate,Role,User,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle2[Client,CertificateTemplate,User,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Clinic,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Location,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Therapist,c]  1
    zV[c,lb,CertificateTemplate,User]  triangle2[CertificateTemplate,User,Instructor,c]  1
    zV[r,rt,CertificateTemplate,CourseSession]  choose1[CertificateTemplate,CourseSession]  1
    zV[r,rt,CertificateTemplate,CourseSession]  axisVdifRT[r,CertificateTemplate,CourseSession]  42
    zV[r,rt,CertificateTemplate,CourseSession]  DistAxisLB1[c,CertificateTemplate,CourseSession]  -13
    zV[r,rt,CertificateTemplate,CourseSession]  triangle1[Client,CertificateTemplate,CourseSession,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Clinic,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Location,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Therapist,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Instructor,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,Course,CourseSession,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,Role,CourseSession,r]  1
    zV[r,rt,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,User,CourseSession,r]  1
    zV[c,rt,CertificateTemplate,CourseSession]  DistSumLB[CertificateTemplate,CourseSession]  5
    zV[c,rt,CertificateTemplate,CourseSession]  compDistAxis2[c,CertificateTemplate,CourseSession]  10
    zV[c,rt,CertificateTemplate,CourseSession]  choose1[CertificateTemplate,CourseSession]  1
    zV[c,rt,CertificateTemplate,CourseSession]  axisVdifRT[c,CertificateTemplate,CourseSession]  42
    zV[c,rt,CertificateTemplate,CourseSession]  DistAxisLB1[r,CertificateTemplate,CourseSession]  -8
    zV[c,rt,CertificateTemplate,CourseSession]  triangle1[Client,CertificateTemplate,CourseSession,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Clinic,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Location,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Therapist,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,CourseSession,Instructor,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,Course,CourseSession,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,Role,CourseSession,c]  1
    zV[c,rt,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,User,CourseSession,c]  1
    zV[r,lb,CertificateTemplate,CourseSession]  choose1[CertificateTemplate,CourseSession]  1
    zV[r,lb,CertificateTemplate,CourseSession]  axisVdifLB[r,CertificateTemplate,CourseSession]  42
    zV[r,lb,CertificateTemplate,CourseSession]  DistAxisLB1[c,CertificateTemplate,CourseSession]  -13
    zV[r,lb,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,Course,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,Role,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,User,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle2[Client,CertificateTemplate,CourseSession,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Clinic,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Location,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Therapist,r]  1
    zV[r,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Instructor,r]  1
    zV[c,lb,CertificateTemplate,CourseSession]  DistSumLB[CertificateTemplate,CourseSession]  5
    zV[c,lb,CertificateTemplate,CourseSession]  compDistAxis1[c,CertificateTemplate,CourseSession]  10
    zV[c,lb,CertificateTemplate,CourseSession]  choose1[CertificateTemplate,CourseSession]  1
    zV[c,lb,CertificateTemplate,CourseSession]  axisVdifLB[c,CertificateTemplate,CourseSession]  42
    zV[c,lb,CertificateTemplate,CourseSession]  DistAxisLB1[r,CertificateTemplate,CourseSession]  -8
    zV[c,lb,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,Course,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,Role,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle1[CertificateTemplate,User,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle2[Client,CertificateTemplate,CourseSession,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Clinic,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Location,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Therapist,c]  1
    zV[c,lb,CertificateTemplate,CourseSession]  triangle2[CertificateTemplate,CourseSession,Instructor,c]  1
    zV[r,rt,CertificateTemplate,Clinic]  choose1[CertificateTemplate,Clinic]  1
    zV[r,rt,CertificateTemplate,Clinic]  axisVdifRT[r,CertificateTemplate,Clinic]  42
    zV[r,rt,CertificateTemplate,Clinic]  triangle1[Client,CertificateTemplate,Clinic,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Clinic,Location,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Clinic,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Clinic,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Course,Clinic,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Role,Clinic,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,User,Clinic,r]  1
    zV[r,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,CourseSession,Clinic,r]  1
    zV[c,rt,CertificateTemplate,Clinic]  choose1[CertificateTemplate,Clinic]  1
    zV[c,rt,CertificateTemplate,Clinic]  axisVdifRT[c,CertificateTemplate,Clinic]  42
    zV[c,rt,CertificateTemplate,Clinic]  triangle1[Client,CertificateTemplate,Clinic,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Clinic,Location,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Clinic,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Clinic,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Course,Clinic,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Role,Clinic,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,User,Clinic,c]  1
    zV[c,rt,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,CourseSession,Clinic,c]  1
    zV[r,lb,CertificateTemplate,Clinic]  choose1[CertificateTemplate,Clinic]  1
    zV[r,lb,CertificateTemplate,Clinic]  axisVdifLB[r,CertificateTemplate,Clinic]  42
    zV[r,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Course,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Role,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,User,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,CourseSession,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle2[Client,CertificateTemplate,Clinic,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Clinic,Location,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Clinic,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Clinic,Instructor,r]  1
    zV[c,lb,CertificateTemplate,Clinic]  choose1[CertificateTemplate,Clinic]  1
    zV[c,lb,CertificateTemplate,Clinic]  axisVdifLB[c,CertificateTemplate,Clinic]  42
    zV[c,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Course,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,Role,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,User,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle1[CertificateTemplate,CourseSession,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle2[Client,CertificateTemplate,Clinic,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Clinic,Location,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Clinic,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Clinic]  triangle2[CertificateTemplate,Clinic,Instructor,c]  1
    zV[r,rt,CertificateTemplate,Location]  choose1[CertificateTemplate,Location]  1
    zV[r,rt,CertificateTemplate,Location]  axisVdifRT[r,CertificateTemplate,Location]  42
    zV[r,rt,CertificateTemplate,Location]  triangle1[Client,CertificateTemplate,Location,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle1[CertificateTemplate,Location,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle1[CertificateTemplate,Location,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,Course,Location,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,Role,Location,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,User,Location,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,CourseSession,Location,r]  1
    zV[r,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,Clinic,Location,r]  1
    zV[c,rt,CertificateTemplate,Location]  choose1[CertificateTemplate,Location]  1
    zV[c,rt,CertificateTemplate,Location]  axisVdifRT[c,CertificateTemplate,Location]  42
    zV[c,rt,CertificateTemplate,Location]  triangle1[Client,CertificateTemplate,Location,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle1[CertificateTemplate,Location,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle1[CertificateTemplate,Location,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,Course,Location,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,Role,Location,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,User,Location,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,CourseSession,Location,c]  1
    zV[c,rt,CertificateTemplate,Location]  triangle2[CertificateTemplate,Clinic,Location,c]  1
    zV[r,lb,CertificateTemplate,Location]  choose1[CertificateTemplate,Location]  1
    zV[r,lb,CertificateTemplate,Location]  axisVdifLB[r,CertificateTemplate,Location]  42
    zV[r,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,Course,Location,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,Role,Location,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,User,Location,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,CourseSession,Location,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,Clinic,Location,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle2[Client,CertificateTemplate,Location,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle2[CertificateTemplate,Location,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Location]  triangle2[CertificateTemplate,Location,Instructor,r]  1
    zV[c,lb,CertificateTemplate,Location]  choose1[CertificateTemplate,Location]  1
    zV[c,lb,CertificateTemplate,Location]  axisVdifLB[c,CertificateTemplate,Location]  42
    zV[c,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,Course,Location,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,Role,Location,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,User,Location,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,CourseSession,Location,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle1[CertificateTemplate,Clinic,Location,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle2[Client,CertificateTemplate,Location,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle2[CertificateTemplate,Location,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Location]  triangle2[CertificateTemplate,Location,Instructor,c]  1
    zV[r,rt,CertificateTemplate,Therapist]  choose1[CertificateTemplate,Therapist]  1
    zV[r,rt,CertificateTemplate,Therapist]  axisVdifRT[r,CertificateTemplate,Therapist]  42
    zV[r,rt,CertificateTemplate,Therapist]  triangle1[Client,CertificateTemplate,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Therapist,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Course,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Role,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,User,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,CourseSession,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Clinic,Therapist,r]  1
    zV[r,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Location,Therapist,r]  1
    zV[c,rt,CertificateTemplate,Therapist]  choose1[CertificateTemplate,Therapist]  1
    zV[c,rt,CertificateTemplate,Therapist]  axisVdifRT[c,CertificateTemplate,Therapist]  42
    zV[c,rt,CertificateTemplate,Therapist]  triangle1[Client,CertificateTemplate,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Therapist,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Course,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Role,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,User,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,CourseSession,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Clinic,Therapist,c]  1
    zV[c,rt,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Location,Therapist,c]  1
    zV[r,lb,CertificateTemplate,Therapist]  choose1[CertificateTemplate,Therapist]  1
    zV[r,lb,CertificateTemplate,Therapist]  axisVdifLB[r,CertificateTemplate,Therapist]  42
    zV[r,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Course,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Role,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,User,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,CourseSession,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Clinic,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Location,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle2[Client,CertificateTemplate,Therapist,r]  1
    zV[r,lb,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Therapist,Instructor,r]  1
    zV[c,lb,CertificateTemplate,Therapist]  choose1[CertificateTemplate,Therapist]  1
    zV[c,lb,CertificateTemplate,Therapist]  axisVdifLB[c,CertificateTemplate,Therapist]  42
    zV[c,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Course,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Role,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,User,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,CourseSession,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Clinic,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle1[CertificateTemplate,Location,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle2[Client,CertificateTemplate,Therapist,c]  1
    zV[c,lb,CertificateTemplate,Therapist]  triangle2[CertificateTemplate,Therapist,Instructor,c]  1
    zV[r,rt,CertificateTemplate,Instructor]  choose1[CertificateTemplate,Instructor]  1
    zV[r,rt,CertificateTemplate,Instructor]  axisVdifRT[r,CertificateTemplate,Instructor]  42
    zV[r,rt,CertificateTemplate,Instructor]  triangle1[Client,CertificateTemplate,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Course,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Role,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,User,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,CourseSession,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Clinic,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Location,Instructor,r]  1
    zV[r,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Therapist,Instructor,r]  1
    zV[c,rt,CertificateTemplate,Instructor]  choose1[CertificateTemplate,Instructor]  1
    zV[c,rt,CertificateTemplate,Instructor]  axisVdifRT[c,CertificateTemplate,Instructor]  42
    zV[c,rt,CertificateTemplate,Instructor]  triangle1[Client,CertificateTemplate,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Course,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Role,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,User,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,CourseSession,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Clinic,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Location,Instructor,c]  1
    zV[c,rt,CertificateTemplate,Instructor]  triangle2[CertificateTemplate,Therapist,Instructor,c]  1
    zV[r,lb,CertificateTemplate,Instructor]  choose1[CertificateTemplate,Instructor]  1
    zV[r,lb,CertificateTemplate,Instructor]  axisVdifLB[r,CertificateTemplate,Instructor]  42
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Course,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Role,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,User,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,CourseSession,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Clinic,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Location,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Therapist,Instructor,r]  1
    zV[r,lb,CertificateTemplate,Instructor]  triangle2[Client,CertificateTemplate,Instructor,r]  1
    zV[c,lb,CertificateTemplate,Instructor]  choose1[CertificateTemplate,Instructor]  1
    zV[c,lb,CertificateTemplate,Instructor]  axisVdifLB[c,CertificateTemplate,Instructor]  42
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Course,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Role,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,User,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,CourseSession,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Clinic,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Location,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle1[CertificateTemplate,Therapist,Instructor,c]  1
    zV[c,lb,CertificateTemplate,Instructor]  triangle2[Client,CertificateTemplate,Instructor,c]  1
    zV[r,rt,Course,Role]  choose1[Course,Role]  1
    zV[r,rt,Course,Role]  axisVdifRT[r,Course,Role]  42
    zV[r,rt,Course,Role]  triangle1[Client,Course,Role,r]  1
    zV[r,rt,Course,Role]  triangle1[CertificateTemplate,Course,Role,r]  1
    zV[r,rt,Course,Role]  triangle1[Course,Role,User,r]  1
    zV[r,rt,Course,Role]  triangle1[Course,Role,CourseSession,r]  1
    zV[r,rt,Course,Role]  triangle1[Course,Role,Clinic,r]  1
    zV[r,rt,Course,Role]  triangle1[Course,Role,Location,r]  1
    zV[r,rt,Course,Role]  triangle1[Course,Role,Therapist,r]  1
    zV[r,rt,Course,Role]  triangle1[Course,Role,Instructor,r]  1
    zV[c,rt,Course,Role]  choose1[Course,Role]  1
    zV[c,rt,Course,Role]  axisVdifRT[c,Course,Role]  42
    zV[c,rt,Course,Role]  triangle1[Client,Course,Role,c]  1
    zV[c,rt,Course,Role]  triangle1[CertificateTemplate,Course,Role,c]  1
    zV[c,rt,Course,Role]  triangle1[Course,Role,User,c]  1
    zV[c,rt,Course,Role]  triangle1[Course,Role,CourseSession,c]  1
    zV[c,rt,Course,Role]  triangle1[Course,Role,Clinic,c]  1
    zV[c,rt,Course,Role]  triangle1[Course,Role,Location,c]  1
    zV[c,rt,Course,Role]  triangle1[Course,Role,Therapist,c]  1
    zV[c,rt,Course,Role]  triangle1[Course,Role,Instructor,c]  1
    zV[r,lb,Course,Role]  choose1[Course,Role]  1
    zV[r,lb,Course,Role]  axisVdifLB[r,Course,Role]  42
    zV[r,lb,Course,Role]  triangle2[Client,Course,Role,r]  1
    zV[r,lb,Course,Role]  triangle2[CertificateTemplate,Course,Role,r]  1
    zV[r,lb,Course,Role]  triangle2[Course,Role,User,r]  1
    zV[r,lb,Course,Role]  triangle2[Course,Role,CourseSession,r]  1
    zV[r,lb,Course,Role]  triangle2[Course,Role,Clinic,r]  1
    zV[r,lb,Course,Role]  triangle2[Course,Role,Location,r]  1
    zV[r,lb,Course,Role]  triangle2[Course,Role,Therapist,r]  1
    zV[r,lb,Course,Role]  triangle2[Course,Role,Instructor,r]  1
    zV[c,lb,Course,Role]  choose1[Course,Role]  1
    zV[c,lb,Course,Role]  axisVdifLB[c,Course,Role]  42
    zV[c,lb,Course,Role]  triangle2[Client,Course,Role,c]  1
    zV[c,lb,Course,Role]  triangle2[CertificateTemplate,Course,Role,c]  1
    zV[c,lb,Course,Role]  triangle2[Course,Role,User,c]  1
    zV[c,lb,Course,Role]  triangle2[Course,Role,CourseSession,c]  1
    zV[c,lb,Course,Role]  triangle2[Course,Role,Clinic,c]  1
    zV[c,lb,Course,Role]  triangle2[Course,Role,Location,c]  1
    zV[c,lb,Course,Role]  triangle2[Course,Role,Therapist,c]  1
    zV[c,lb,Course,Role]  triangle2[Course,Role,Instructor,c]  1
    zV[r,rt,Course,User]  choose1[Course,User]  1
    zV[r,rt,Course,User]  axisVdifRT[r,Course,User]  42
    zV[r,rt,Course,User]  triangle1[Client,Course,User,r]  1
    zV[r,rt,Course,User]  triangle1[CertificateTemplate,Course,User,r]  1
    zV[r,rt,Course,User]  triangle1[Course,User,CourseSession,r]  1
    zV[r,rt,Course,User]  triangle1[Course,User,Clinic,r]  1
    zV[r,rt,Course,User]  triangle1[Course,User,Location,r]  1
    zV[r,rt,Course,User]  triangle1[Course,User,Therapist,r]  1
    zV[r,rt,Course,User]  triangle1[Course,User,Instructor,r]  1
    zV[r,rt,Course,User]  triangle2[Course,Role,User,r]  1
    zV[c,rt,Course,User]  choose1[Course,User]  1
    zV[c,rt,Course,User]  axisVdifRT[c,Course,User]  42
    zV[c,rt,Course,User]  triangle1[Client,Course,User,c]  1
    zV[c,rt,Course,User]  triangle1[CertificateTemplate,Course,User,c]  1
    zV[c,rt,Course,User]  triangle1[Course,User,CourseSession,c]  1
    zV[c,rt,Course,User]  triangle1[Course,User,Clinic,c]  1
    zV[c,rt,Course,User]  triangle1[Course,User,Location,c]  1
    zV[c,rt,Course,User]  triangle1[Course,User,Therapist,c]  1
    zV[c,rt,Course,User]  triangle1[Course,User,Instructor,c]  1
    zV[c,rt,Course,User]  triangle2[Course,Role,User,c]  1
    zV[r,lb,Course,User]  choose1[Course,User]  1
    zV[r,lb,Course,User]  axisVdifLB[r,Course,User]  42
    zV[r,lb,Course,User]  triangle1[Course,Role,User,r]  1
    zV[r,lb,Course,User]  triangle2[Client,Course,User,r]  1
    zV[r,lb,Course,User]  triangle2[CertificateTemplate,Course,User,r]  1
    zV[r,lb,Course,User]  triangle2[Course,User,CourseSession,r]  1
    zV[r,lb,Course,User]  triangle2[Course,User,Clinic,r]  1
    zV[r,lb,Course,User]  triangle2[Course,User,Location,r]  1
    zV[r,lb,Course,User]  triangle2[Course,User,Therapist,r]  1
    zV[r,lb,Course,User]  triangle2[Course,User,Instructor,r]  1
    zV[c,lb,Course,User]  choose1[Course,User]  1
    zV[c,lb,Course,User]  axisVdifLB[c,Course,User]  42
    zV[c,lb,Course,User]  triangle1[Course,Role,User,c]  1
    zV[c,lb,Course,User]  triangle2[Client,Course,User,c]  1
    zV[c,lb,Course,User]  triangle2[CertificateTemplate,Course,User,c]  1
    zV[c,lb,Course,User]  triangle2[Course,User,CourseSession,c]  1
    zV[c,lb,Course,User]  triangle2[Course,User,Clinic,c]  1
    zV[c,lb,Course,User]  triangle2[Course,User,Location,c]  1
    zV[c,lb,Course,User]  triangle2[Course,User,Therapist,c]  1
    zV[c,lb,Course,User]  triangle2[Course,User,Instructor,c]  1
    zV[r,rt,Course,CourseSession]  choose1[Course,CourseSession]  1
    zV[r,rt,Course,CourseSession]  axisVdifRT[r,Course,CourseSession]  42
    zV[r,rt,Course,CourseSession]  DistAxisLB1[c,Course,CourseSession]  -12
    zV[r,rt,Course,CourseSession]  triangle1[Client,Course,CourseSession,r]  1
    zV[r,rt,Course,CourseSession]  triangle1[CertificateTemplate,Course,CourseSession,r]  1
    zV[r,rt,Course,CourseSession]  triangle1[Course,CourseSession,Clinic,r]  1
    zV[r,rt,Course,CourseSession]  triangle1[Course,CourseSession,Location,r]  1
    zV[r,rt,Course,CourseSession]  triangle1[Course,CourseSession,Therapist,r]  1
    zV[r,rt,Course,CourseSession]  triangle1[Course,CourseSession,Instructor,r]  1
    zV[r,rt,Course,CourseSession]  triangle2[Course,Role,CourseSession,r]  1
    zV[r,rt,Course,CourseSession]  triangle2[Course,User,CourseSession,r]  1
    zV[c,rt,Course,CourseSession]  DistSumLB[Course,CourseSession]  4.5
    zV[c,rt,Course,CourseSession]  compDistAxis2[c,Course,CourseSession]  6
    zV[c,rt,Course,CourseSession]  choose1[Course,CourseSession]  1
    zV[c,rt,Course,CourseSession]  axisVdifRT[c,Course,CourseSession]  42
    zV[c,rt,Course,CourseSession]  DistAxisLB1[r,Course,CourseSession]  -7.5
    zV[c,rt,Course,CourseSession]  triangle1[Client,Course,CourseSession,c]  1
    zV[c,rt,Course,CourseSession]  triangle1[CertificateTemplate,Course,CourseSession,c]  1
    zV[c,rt,Course,CourseSession]  triangle1[Course,CourseSession,Clinic,c]  1
    zV[c,rt,Course,CourseSession]  triangle1[Course,CourseSession,Location,c]  1
    zV[c,rt,Course,CourseSession]  triangle1[Course,CourseSession,Therapist,c]  1
    zV[c,rt,Course,CourseSession]  triangle1[Course,CourseSession,Instructor,c]  1
    zV[c,rt,Course,CourseSession]  triangle2[Course,Role,CourseSession,c]  1
    zV[c,rt,Course,CourseSession]  triangle2[Course,User,CourseSession,c]  1
    zV[r,lb,Course,CourseSession]  choose1[Course,CourseSession]  1
    zV[r,lb,Course,CourseSession]  axisVdifLB[r,Course,CourseSession]  42
    zV[r,lb,Course,CourseSession]  DistAxisLB1[c,Course,CourseSession]  -12
    zV[r,lb,Course,CourseSession]  triangle1[Course,Role,CourseSession,r]  1
    zV[r,lb,Course,CourseSession]  triangle1[Course,User,CourseSession,r]  1
    zV[r,lb,Course,CourseSession]  triangle2[Client,Course,CourseSession,r]  1
    zV[r,lb,Course,CourseSession]  triangle2[CertificateTemplate,Course,CourseSession,r]  1
    zV[r,lb,Course,CourseSession]  triangle2[Course,CourseSession,Clinic,r]  1
    zV[r,lb,Course,CourseSession]  triangle2[Course,CourseSession,Location,r]  1
    zV[r,lb,Course,CourseSession]  triangle2[Course,CourseSession,Therapist,r]  1
    zV[r,lb,Course,CourseSession]  triangle2[Course,CourseSession,Instructor,r]  1
    zV[c,lb,Course,CourseSession]  DistSumLB[Course,CourseSession]  4.5
    zV[c,lb,Course,CourseSession]  compDistAxis1[c,Course,CourseSession]  6
    zV[c,lb,Course,CourseSession]  choose1[Course,CourseSession]  1
    zV[c,lb,Course,CourseSession]  axisVdifLB[c,Course,CourseSession]  42
    zV[c,lb,Course,CourseSession]  DistAxisLB1[r,Course,CourseSession]  -7.5
    zV[c,lb,Course,CourseSession]  triangle1[Course,Role,CourseSession,c]  1
    zV[c,lb,Course,CourseSession]  triangle1[Course,User,CourseSession,c]  1
    zV[c,lb,Course,CourseSession]  triangle2[Client,Course,CourseSession,c]  1
    zV[c,lb,Course,CourseSession]  triangle2[CertificateTemplate,Course,CourseSession,c]  1
    zV[c,lb,Course,CourseSession]  triangle2[Course,CourseSession,Clinic,c]  1
    zV[c,lb,Course,CourseSession]  triangle2[Course,CourseSession,Location,c]  1
    zV[c,lb,Course,CourseSession]  triangle2[Course,CourseSession,Therapist,c]  1
    zV[c,lb,Course,CourseSession]  triangle2[Course,CourseSession,Instructor,c]  1
    zV[r,rt,Course,Clinic]  choose1[Course,Clinic]  1
    zV[r,rt,Course,Clinic]  axisVdifRT[r,Course,Clinic]  42
    zV[r,rt,Course,Clinic]  triangle1[Client,Course,Clinic,r]  1
    zV[r,rt,Course,Clinic]  triangle1[CertificateTemplate,Course,Clinic,r]  1
    zV[r,rt,Course,Clinic]  triangle1[Course,Clinic,Location,r]  1
    zV[r,rt,Course,Clinic]  triangle1[Course,Clinic,Therapist,r]  1
    zV[r,rt,Course,Clinic]  triangle1[Course,Clinic,Instructor,r]  1
    zV[r,rt,Course,Clinic]  triangle2[Course,Role,Clinic,r]  1
    zV[r,rt,Course,Clinic]  triangle2[Course,User,Clinic,r]  1
    zV[r,rt,Course,Clinic]  triangle2[Course,CourseSession,Clinic,r]  1
    zV[c,rt,Course,Clinic]  choose1[Course,Clinic]  1
    zV[c,rt,Course,Clinic]  axisVdifRT[c,Course,Clinic]  42
    zV[c,rt,Course,Clinic]  triangle1[Client,Course,Clinic,c]  1
    zV[c,rt,Course,Clinic]  triangle1[CertificateTemplate,Course,Clinic,c]  1
    zV[c,rt,Course,Clinic]  triangle1[Course,Clinic,Location,c]  1
    zV[c,rt,Course,Clinic]  triangle1[Course,Clinic,Therapist,c]  1
    zV[c,rt,Course,Clinic]  triangle1[Course,Clinic,Instructor,c]  1
    zV[c,rt,Course,Clinic]  triangle2[Course,Role,Clinic,c]  1
    zV[c,rt,Course,Clinic]  triangle2[Course,User,Clinic,c]  1
    zV[c,rt,Course,Clinic]  triangle2[Course,CourseSession,Clinic,c]  1
    zV[r,lb,Course,Clinic]  choose1[Course,Clinic]  1
    zV[r,lb,Course,Clinic]  axisVdifLB[r,Course,Clinic]  42
    zV[r,lb,Course,Clinic]  triangle1[Course,Role,Clinic,r]  1
    zV[r,lb,Course,Clinic]  triangle1[Course,User,Clinic,r]  1
    zV[r,lb,Course,Clinic]  triangle1[Course,CourseSession,Clinic,r]  1
    zV[r,lb,Course,Clinic]  triangle2[Client,Course,Clinic,r]  1
    zV[r,lb,Course,Clinic]  triangle2[CertificateTemplate,Course,Clinic,r]  1
    zV[r,lb,Course,Clinic]  triangle2[Course,Clinic,Location,r]  1
    zV[r,lb,Course,Clinic]  triangle2[Course,Clinic,Therapist,r]  1
    zV[r,lb,Course,Clinic]  triangle2[Course,Clinic,Instructor,r]  1
    zV[c,lb,Course,Clinic]  choose1[Course,Clinic]  1
    zV[c,lb,Course,Clinic]  axisVdifLB[c,Course,Clinic]  42
    zV[c,lb,Course,Clinic]  triangle1[Course,Role,Clinic,c]  1
    zV[c,lb,Course,Clinic]  triangle1[Course,User,Clinic,c]  1
    zV[c,lb,Course,Clinic]  triangle1[Course,CourseSession,Clinic,c]  1
    zV[c,lb,Course,Clinic]  triangle2[Client,Course,Clinic,c]  1
    zV[c,lb,Course,Clinic]  triangle2[CertificateTemplate,Course,Clinic,c]  1
    zV[c,lb,Course,Clinic]  triangle2[Course,Clinic,Location,c]  1
    zV[c,lb,Course,Clinic]  triangle2[Course,Clinic,Therapist,c]  1
    zV[c,lb,Course,Clinic]  triangle2[Course,Clinic,Instructor,c]  1
    zV[r,rt,Course,Location]  choose1[Course,Location]  1
    zV[r,rt,Course,Location]  axisVdifRT[r,Course,Location]  42
    zV[r,rt,Course,Location]  triangle1[Client,Course,Location,r]  1
    zV[r,rt,Course,Location]  triangle1[CertificateTemplate,Course,Location,r]  1
    zV[r,rt,Course,Location]  triangle1[Course,Location,Therapist,r]  1
    zV[r,rt,Course,Location]  triangle1[Course,Location,Instructor,r]  1
    zV[r,rt,Course,Location]  triangle2[Course,Role,Location,r]  1
    zV[r,rt,Course,Location]  triangle2[Course,User,Location,r]  1
    zV[r,rt,Course,Location]  triangle2[Course,CourseSession,Location,r]  1
    zV[r,rt,Course,Location]  triangle2[Course,Clinic,Location,r]  1
    zV[c,rt,Course,Location]  choose1[Course,Location]  1
    zV[c,rt,Course,Location]  axisVdifRT[c,Course,Location]  42
    zV[c,rt,Course,Location]  triangle1[Client,Course,Location,c]  1
    zV[c,rt,Course,Location]  triangle1[CertificateTemplate,Course,Location,c]  1
    zV[c,rt,Course,Location]  triangle1[Course,Location,Therapist,c]  1
    zV[c,rt,Course,Location]  triangle1[Course,Location,Instructor,c]  1
    zV[c,rt,Course,Location]  triangle2[Course,Role,Location,c]  1
    zV[c,rt,Course,Location]  triangle2[Course,User,Location,c]  1
    zV[c,rt,Course,Location]  triangle2[Course,CourseSession,Location,c]  1
    zV[c,rt,Course,Location]  triangle2[Course,Clinic,Location,c]  1
    zV[r,lb,Course,Location]  choose1[Course,Location]  1
    zV[r,lb,Course,Location]  axisVdifLB[r,Course,Location]  42
    zV[r,lb,Course,Location]  triangle1[Course,Role,Location,r]  1
    zV[r,lb,Course,Location]  triangle1[Course,User,Location,r]  1
    zV[r,lb,Course,Location]  triangle1[Course,CourseSession,Location,r]  1
    zV[r,lb,Course,Location]  triangle1[Course,Clinic,Location,r]  1
    zV[r,lb,Course,Location]  triangle2[Client,Course,Location,r]  1
    zV[r,lb,Course,Location]  triangle2[CertificateTemplate,Course,Location,r]  1
    zV[r,lb,Course,Location]  triangle2[Course,Location,Therapist,r]  1
    zV[r,lb,Course,Location]  triangle2[Course,Location,Instructor,r]  1
    zV[c,lb,Course,Location]  choose1[Course,Location]  1
    zV[c,lb,Course,Location]  axisVdifLB[c,Course,Location]  42
    zV[c,lb,Course,Location]  triangle1[Course,Role,Location,c]  1
    zV[c,lb,Course,Location]  triangle1[Course,User,Location,c]  1
    zV[c,lb,Course,Location]  triangle1[Course,CourseSession,Location,c]  1
    zV[c,lb,Course,Location]  triangle1[Course,Clinic,Location,c]  1
    zV[c,lb,Course,Location]  triangle2[Client,Course,Location,c]  1
    zV[c,lb,Course,Location]  triangle2[CertificateTemplate,Course,Location,c]  1
    zV[c,lb,Course,Location]  triangle2[Course,Location,Therapist,c]  1
    zV[c,lb,Course,Location]  triangle2[Course,Location,Instructor,c]  1
    zV[r,rt,Course,Therapist]  choose1[Course,Therapist]  1
    zV[r,rt,Course,Therapist]  axisVdifRT[r,Course,Therapist]  42
    zV[r,rt,Course,Therapist]  triangle1[Client,Course,Therapist,r]  1
    zV[r,rt,Course,Therapist]  triangle1[CertificateTemplate,Course,Therapist,r]  1
    zV[r,rt,Course,Therapist]  triangle1[Course,Therapist,Instructor,r]  1
    zV[r,rt,Course,Therapist]  triangle2[Course,Role,Therapist,r]  1
    zV[r,rt,Course,Therapist]  triangle2[Course,User,Therapist,r]  1
    zV[r,rt,Course,Therapist]  triangle2[Course,CourseSession,Therapist,r]  1
    zV[r,rt,Course,Therapist]  triangle2[Course,Clinic,Therapist,r]  1
    zV[r,rt,Course,Therapist]  triangle2[Course,Location,Therapist,r]  1
    zV[c,rt,Course,Therapist]  choose1[Course,Therapist]  1
    zV[c,rt,Course,Therapist]  axisVdifRT[c,Course,Therapist]  42
    zV[c,rt,Course,Therapist]  triangle1[Client,Course,Therapist,c]  1
    zV[c,rt,Course,Therapist]  triangle1[CertificateTemplate,Course,Therapist,c]  1
    zV[c,rt,Course,Therapist]  triangle1[Course,Therapist,Instructor,c]  1
    zV[c,rt,Course,Therapist]  triangle2[Course,Role,Therapist,c]  1
    zV[c,rt,Course,Therapist]  triangle2[Course,User,Therapist,c]  1
    zV[c,rt,Course,Therapist]  triangle2[Course,CourseSession,Therapist,c]  1
    zV[c,rt,Course,Therapist]  triangle2[Course,Clinic,Therapist,c]  1
    zV[c,rt,Course,Therapist]  triangle2[Course,Location,Therapist,c]  1
    zV[r,lb,Course,Therapist]  choose1[Course,Therapist]  1
    zV[r,lb,Course,Therapist]  axisVdifLB[r,Course,Therapist]  42
    zV[r,lb,Course,Therapist]  triangle1[Course,Role,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle1[Course,User,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle1[Course,CourseSession,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle1[Course,Clinic,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle1[Course,Location,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle2[Client,Course,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle2[CertificateTemplate,Course,Therapist,r]  1
    zV[r,lb,Course,Therapist]  triangle2[Course,Therapist,Instructor,r]  1
    zV[c,lb,Course,Therapist]  choose1[Course,Therapist]  1
    zV[c,lb,Course,Therapist]  axisVdifLB[c,Course,Therapist]  42
    zV[c,lb,Course,Therapist]  triangle1[Course,Role,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle1[Course,User,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle1[Course,CourseSession,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle1[Course,Clinic,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle1[Course,Location,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle2[Client,Course,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle2[CertificateTemplate,Course,Therapist,c]  1
    zV[c,lb,Course,Therapist]  triangle2[Course,Therapist,Instructor,c]  1
    zV[r,rt,Course,Instructor]  choose1[Course,Instructor]  1
    zV[r,rt,Course,Instructor]  axisVdifRT[r,Course,Instructor]  42
    zV[r,rt,Course,Instructor]  triangle1[Client,Course,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle1[CertificateTemplate,Course,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle2[Course,Role,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle2[Course,User,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle2[Course,CourseSession,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle2[Course,Clinic,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle2[Course,Location,Instructor,r]  1
    zV[r,rt,Course,Instructor]  triangle2[Course,Therapist,Instructor,r]  1
    zV[c,rt,Course,Instructor]  choose1[Course,Instructor]  1
    zV[c,rt,Course,Instructor]  axisVdifRT[c,Course,Instructor]  42
    zV[c,rt,Course,Instructor]  triangle1[Client,Course,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle1[CertificateTemplate,Course,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle2[Course,Role,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle2[Course,User,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle2[Course,CourseSession,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle2[Course,Clinic,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle2[Course,Location,Instructor,c]  1
    zV[c,rt,Course,Instructor]  triangle2[Course,Therapist,Instructor,c]  1
    zV[r,lb,Course,Instructor]  choose1[Course,Instructor]  1
    zV[r,lb,Course,Instructor]  axisVdifLB[r,Course,Instructor]  42
    zV[r,lb,Course,Instructor]  triangle1[Course,Role,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle1[Course,User,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle1[Course,CourseSession,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle1[Course,Clinic,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle1[Course,Location,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle1[Course,Therapist,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle2[Client,Course,Instructor,r]  1
    zV[r,lb,Course,Instructor]  triangle2[CertificateTemplate,Course,Instructor,r]  1
    zV[c,lb,Course,Instructor]  choose1[Course,Instructor]  1
    zV[c,lb,Course,Instructor]  axisVdifLB[c,Course,Instructor]  42
    zV[c,lb,Course,Instructor]  triangle1[Course,Role,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle1[Course,User,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle1[Course,CourseSession,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle1[Course,Clinic,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle1[Course,Location,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle1[Course,Therapist,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle2[Client,Course,Instructor,c]  1
    zV[c,lb,Course,Instructor]  triangle2[CertificateTemplate,Course,Instructor,c]  1
    zV[r,rt,Role,User]  choose1[Role,User]  1
    zV[r,rt,Role,User]  axisVdifRT[r,Role,User]  42
    zV[r,rt,Role,User]  DistAxisLB1[c,Role,User]  -10.5
    zV[r,rt,Role,User]  triangle1[Client,Role,User,r]  1
    zV[r,rt,Role,User]  triangle1[CertificateTemplate,Role,User,r]  1
    zV[r,rt,Role,User]  triangle1[Course,Role,User,r]  1
    zV[r,rt,Role,User]  triangle1[Role,User,CourseSession,r]  1
    zV[r,rt,Role,User]  triangle1[Role,User,Clinic,r]  1
    zV[r,rt,Role,User]  triangle1[Role,User,Location,r]  1
    zV[r,rt,Role,User]  triangle1[Role,User,Therapist,r]  1
    zV[r,rt,Role,User]  triangle1[Role,User,Instructor,r]  1
    zV[c,rt,Role,User]  DistSumLB[Role,User]  4
    zV[c,rt,Role,User]  choose1[Role,User]  1
    zV[c,rt,Role,User]  axisVdifRT[c,Role,User]  42
    zV[c,rt,Role,User]  DistAxisLB1[r,Role,User]  -6.5
    zV[c,rt,Role,User]  triangle1[Client,Role,User,c]  1
    zV[c,rt,Role,User]  triangle1[CertificateTemplate,Role,User,c]  1
    zV[c,rt,Role,User]  triangle1[Course,Role,User,c]  1
    zV[c,rt,Role,User]  triangle1[Role,User,CourseSession,c]  1
    zV[c,rt,Role,User]  triangle1[Role,User,Clinic,c]  1
    zV[c,rt,Role,User]  triangle1[Role,User,Location,c]  1
    zV[c,rt,Role,User]  triangle1[Role,User,Therapist,c]  1
    zV[c,rt,Role,User]  triangle1[Role,User,Instructor,c]  1
    zV[r,lb,Role,User]  choose1[Role,User]  1
    zV[r,lb,Role,User]  axisVdifLB[r,Role,User]  42
    zV[r,lb,Role,User]  DistAxisLB1[c,Role,User]  -10.5
    zV[r,lb,Role,User]  triangle2[Client,Role,User,r]  1
    zV[r,lb,Role,User]  triangle2[CertificateTemplate,Role,User,r]  1
    zV[r,lb,Role,User]  triangle2[Course,Role,User,r]  1
    zV[r,lb,Role,User]  triangle2[Role,User,CourseSession,r]  1
    zV[r,lb,Role,User]  triangle2[Role,User,Clinic,r]  1
    zV[r,lb,Role,User]  triangle2[Role,User,Location,r]  1
    zV[r,lb,Role,User]  triangle2[Role,User,Therapist,r]  1
    zV[r,lb,Role,User]  triangle2[Role,User,Instructor,r]  1
    zV[c,lb,Role,User]  DistSumLB[Role,User]  4
    zV[c,lb,Role,User]  choose1[Role,User]  1
    zV[c,lb,Role,User]  axisVdifLB[c,Role,User]  42
    zV[c,lb,Role,User]  DistAxisLB1[r,Role,User]  -6.5
    zV[c,lb,Role,User]  triangle2[Client,Role,User,c]  1
    zV[c,lb,Role,User]  triangle2[CertificateTemplate,Role,User,c]  1
    zV[c,lb,Role,User]  triangle2[Course,Role,User,c]  1
    zV[c,lb,Role,User]  triangle2[Role,User,CourseSession,c]  1
    zV[c,lb,Role,User]  triangle2[Role,User,Clinic,c]  1
    zV[c,lb,Role,User]  triangle2[Role,User,Location,c]  1
    zV[c,lb,Role,User]  triangle2[Role,User,Therapist,c]  1
    zV[c,lb,Role,User]  triangle2[Role,User,Instructor,c]  1
    zV[r,rt,Role,CourseSession]  choose1[Role,CourseSession]  1
    zV[r,rt,Role,CourseSession]  axisVdifRT[r,Role,CourseSession]  42
    zV[r,rt,Role,CourseSession]  triangle1[Client,Role,CourseSession,r]  1
    zV[r,rt,Role,CourseSession]  triangle1[CertificateTemplate,Role,CourseSession,r]  1
    zV[r,rt,Role,CourseSession]  triangle1[Course,Role,CourseSession,r]  1
    zV[r,rt,Role,CourseSession]  triangle1[Role,CourseSession,Clinic,r]  1
    zV[r,rt,Role,CourseSession]  triangle1[Role,CourseSession,Location,r]  1
    zV[r,rt,Role,CourseSession]  triangle1[Role,CourseSession,Therapist,r]  1
    zV[r,rt,Role,CourseSession]  triangle1[Role,CourseSession,Instructor,r]  1
    zV[r,rt,Role,CourseSession]  triangle2[Role,User,CourseSession,r]  1
    zV[c,rt,Role,CourseSession]  choose1[Role,CourseSession]  1
    zV[c,rt,Role,CourseSession]  axisVdifRT[c,Role,CourseSession]  42
    zV[c,rt,Role,CourseSession]  triangle1[Client,Role,CourseSession,c]  1
    zV[c,rt,Role,CourseSession]  triangle1[CertificateTemplate,Role,CourseSession,c]  1
    zV[c,rt,Role,CourseSession]  triangle1[Course,Role,CourseSession,c]  1
    zV[c,rt,Role,CourseSession]  triangle1[Role,CourseSession,Clinic,c]  1
    zV[c,rt,Role,CourseSession]  triangle1[Role,CourseSession,Location,c]  1
    zV[c,rt,Role,CourseSession]  triangle1[Role,CourseSession,Therapist,c]  1
    zV[c,rt,Role,CourseSession]  triangle1[Role,CourseSession,Instructor,c]  1
    zV[c,rt,Role,CourseSession]  triangle2[Role,User,CourseSession,c]  1
    zV[r,lb,Role,CourseSession]  choose1[Role,CourseSession]  1
    zV[r,lb,Role,CourseSession]  axisVdifLB[r,Role,CourseSession]  42
    zV[r,lb,Role,CourseSession]  triangle1[Role,User,CourseSession,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[Client,Role,CourseSession,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[CertificateTemplate,Role,CourseSession,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[Course,Role,CourseSession,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[Role,CourseSession,Clinic,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[Role,CourseSession,Location,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[Role,CourseSession,Therapist,r]  1
    zV[r,lb,Role,CourseSession]  triangle2[Role,CourseSession,Instructor,r]  1
    zV[c,lb,Role,CourseSession]  choose1[Role,CourseSession]  1
    zV[c,lb,Role,CourseSession]  axisVdifLB[c,Role,CourseSession]  42
    zV[c,lb,Role,CourseSession]  triangle1[Role,User,CourseSession,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[Client,Role,CourseSession,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[CertificateTemplate,Role,CourseSession,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[Course,Role,CourseSession,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[Role,CourseSession,Clinic,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[Role,CourseSession,Location,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[Role,CourseSession,Therapist,c]  1
    zV[c,lb,Role,CourseSession]  triangle2[Role,CourseSession,Instructor,c]  1
    zV[r,rt,Role,Clinic]  choose1[Role,Clinic]  1
    zV[r,rt,Role,Clinic]  axisVdifRT[r,Role,Clinic]  42
    zV[r,rt,Role,Clinic]  triangle1[Client,Role,Clinic,r]  1
    zV[r,rt,Role,Clinic]  triangle1[CertificateTemplate,Role,Clinic,r]  1
    zV[r,rt,Role,Clinic]  triangle1[Course,Role,Clinic,r]  1
    zV[r,rt,Role,Clinic]  triangle1[Role,Clinic,Location,r]  1
    zV[r,rt,Role,Clinic]  triangle1[Role,Clinic,Therapist,r]  1
    zV[r,rt,Role,Clinic]  triangle1[Role,Clinic,Instructor,r]  1
    zV[r,rt,Role,Clinic]  triangle2[Role,User,Clinic,r]  1
    zV[r,rt,Role,Clinic]  triangle2[Role,CourseSession,Clinic,r]  1
    zV[c,rt,Role,Clinic]  choose1[Role,Clinic]  1
    zV[c,rt,Role,Clinic]  axisVdifRT[c,Role,Clinic]  42
    zV[c,rt,Role,Clinic]  triangle1[Client,Role,Clinic,c]  1
    zV[c,rt,Role,Clinic]  triangle1[CertificateTemplate,Role,Clinic,c]  1
    zV[c,rt,Role,Clinic]  triangle1[Course,Role,Clinic,c]  1
    zV[c,rt,Role,Clinic]  triangle1[Role,Clinic,Location,c]  1
    zV[c,rt,Role,Clinic]  triangle1[Role,Clinic,Therapist,c]  1
    zV[c,rt,Role,Clinic]  triangle1[Role,Clinic,Instructor,c]  1
    zV[c,rt,Role,Clinic]  triangle2[Role,User,Clinic,c]  1
    zV[c,rt,Role,Clinic]  triangle2[Role,CourseSession,Clinic,c]  1
    zV[r,lb,Role,Clinic]  choose1[Role,Clinic]  1
    zV[r,lb,Role,Clinic]  axisVdifLB[r,Role,Clinic]  42
    zV[r,lb,Role,Clinic]  triangle1[Role,User,Clinic,r]  1
    zV[r,lb,Role,Clinic]  triangle1[Role,CourseSession,Clinic,r]  1
    zV[r,lb,Role,Clinic]  triangle2[Client,Role,Clinic,r]  1
    zV[r,lb,Role,Clinic]  triangle2[CertificateTemplate,Role,Clinic,r]  1
    zV[r,lb,Role,Clinic]  triangle2[Course,Role,Clinic,r]  1
    zV[r,lb,Role,Clinic]  triangle2[Role,Clinic,Location,r]  1
    zV[r,lb,Role,Clinic]  triangle2[Role,Clinic,Therapist,r]  1
    zV[r,lb,Role,Clinic]  triangle2[Role,Clinic,Instructor,r]  1
    zV[c,lb,Role,Clinic]  choose1[Role,Clinic]  1
    zV[c,lb,Role,Clinic]  axisVdifLB[c,Role,Clinic]  42
    zV[c,lb,Role,Clinic]  triangle1[Role,User,Clinic,c]  1
    zV[c,lb,Role,Clinic]  triangle1[Role,CourseSession,Clinic,c]  1
    zV[c,lb,Role,Clinic]  triangle2[Client,Role,Clinic,c]  1
    zV[c,lb,Role,Clinic]  triangle2[CertificateTemplate,Role,Clinic,c]  1
    zV[c,lb,Role,Clinic]  triangle2[Course,Role,Clinic,c]  1
    zV[c,lb,Role,Clinic]  triangle2[Role,Clinic,Location,c]  1
    zV[c,lb,Role,Clinic]  triangle2[Role,Clinic,Therapist,c]  1
    zV[c,lb,Role,Clinic]  triangle2[Role,Clinic,Instructor,c]  1
    zV[r,rt,Role,Location]  choose1[Role,Location]  1
    zV[r,rt,Role,Location]  axisVdifRT[r,Role,Location]  42
    zV[r,rt,Role,Location]  triangle1[Client,Role,Location,r]  1
    zV[r,rt,Role,Location]  triangle1[CertificateTemplate,Role,Location,r]  1
    zV[r,rt,Role,Location]  triangle1[Course,Role,Location,r]  1
    zV[r,rt,Role,Location]  triangle1[Role,Location,Therapist,r]  1
    zV[r,rt,Role,Location]  triangle1[Role,Location,Instructor,r]  1
    zV[r,rt,Role,Location]  triangle2[Role,User,Location,r]  1
    zV[r,rt,Role,Location]  triangle2[Role,CourseSession,Location,r]  1
    zV[r,rt,Role,Location]  triangle2[Role,Clinic,Location,r]  1
    zV[c,rt,Role,Location]  choose1[Role,Location]  1
    zV[c,rt,Role,Location]  axisVdifRT[c,Role,Location]  42
    zV[c,rt,Role,Location]  triangle1[Client,Role,Location,c]  1
    zV[c,rt,Role,Location]  triangle1[CertificateTemplate,Role,Location,c]  1
    zV[c,rt,Role,Location]  triangle1[Course,Role,Location,c]  1
    zV[c,rt,Role,Location]  triangle1[Role,Location,Therapist,c]  1
    zV[c,rt,Role,Location]  triangle1[Role,Location,Instructor,c]  1
    zV[c,rt,Role,Location]  triangle2[Role,User,Location,c]  1
    zV[c,rt,Role,Location]  triangle2[Role,CourseSession,Location,c]  1
    zV[c,rt,Role,Location]  triangle2[Role,Clinic,Location,c]  1
    zV[r,lb,Role,Location]  choose1[Role,Location]  1
    zV[r,lb,Role,Location]  axisVdifLB[r,Role,Location]  42
    zV[r,lb,Role,Location]  triangle1[Role,User,Location,r]  1
    zV[r,lb,Role,Location]  triangle1[Role,CourseSession,Location,r]  1
    zV[r,lb,Role,Location]  triangle1[Role,Clinic,Location,r]  1
    zV[r,lb,Role,Location]  triangle2[Client,Role,Location,r]  1
    zV[r,lb,Role,Location]  triangle2[CertificateTemplate,Role,Location,r]  1
    zV[r,lb,Role,Location]  triangle2[Course,Role,Location,r]  1
    zV[r,lb,Role,Location]  triangle2[Role,Location,Therapist,r]  1
    zV[r,lb,Role,Location]  triangle2[Role,Location,Instructor,r]  1
    zV[c,lb,Role,Location]  choose1[Role,Location]  1
    zV[c,lb,Role,Location]  axisVdifLB[c,Role,Location]  42
    zV[c,lb,Role,Location]  triangle1[Role,User,Location,c]  1
    zV[c,lb,Role,Location]  triangle1[Role,CourseSession,Location,c]  1
    zV[c,lb,Role,Location]  triangle1[Role,Clinic,Location,c]  1
    zV[c,lb,Role,Location]  triangle2[Client,Role,Location,c]  1
    zV[c,lb,Role,Location]  triangle2[CertificateTemplate,Role,Location,c]  1
    zV[c,lb,Role,Location]  triangle2[Course,Role,Location,c]  1
    zV[c,lb,Role,Location]  triangle2[Role,Location,Therapist,c]  1
    zV[c,lb,Role,Location]  triangle2[Role,Location,Instructor,c]  1
    zV[r,rt,Role,Therapist]  choose1[Role,Therapist]  1
    zV[r,rt,Role,Therapist]  axisVdifRT[r,Role,Therapist]  42
    zV[r,rt,Role,Therapist]  triangle1[Client,Role,Therapist,r]  1
    zV[r,rt,Role,Therapist]  triangle1[CertificateTemplate,Role,Therapist,r]  1
    zV[r,rt,Role,Therapist]  triangle1[Course,Role,Therapist,r]  1
    zV[r,rt,Role,Therapist]  triangle1[Role,Therapist,Instructor,r]  1
    zV[r,rt,Role,Therapist]  triangle2[Role,User,Therapist,r]  1
    zV[r,rt,Role,Therapist]  triangle2[Role,CourseSession,Therapist,r]  1
    zV[r,rt,Role,Therapist]  triangle2[Role,Clinic,Therapist,r]  1
    zV[r,rt,Role,Therapist]  triangle2[Role,Location,Therapist,r]  1
    zV[c,rt,Role,Therapist]  choose1[Role,Therapist]  1
    zV[c,rt,Role,Therapist]  axisVdifRT[c,Role,Therapist]  42
    zV[c,rt,Role,Therapist]  triangle1[Client,Role,Therapist,c]  1
    zV[c,rt,Role,Therapist]  triangle1[CertificateTemplate,Role,Therapist,c]  1
    zV[c,rt,Role,Therapist]  triangle1[Course,Role,Therapist,c]  1
    zV[c,rt,Role,Therapist]  triangle1[Role,Therapist,Instructor,c]  1
    zV[c,rt,Role,Therapist]  triangle2[Role,User,Therapist,c]  1
    zV[c,rt,Role,Therapist]  triangle2[Role,CourseSession,Therapist,c]  1
    zV[c,rt,Role,Therapist]  triangle2[Role,Clinic,Therapist,c]  1
    zV[c,rt,Role,Therapist]  triangle2[Role,Location,Therapist,c]  1
    zV[r,lb,Role,Therapist]  choose1[Role,Therapist]  1
    zV[r,lb,Role,Therapist]  axisVdifLB[r,Role,Therapist]  42
    zV[r,lb,Role,Therapist]  triangle1[Role,User,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle1[Role,CourseSession,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle1[Role,Clinic,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle1[Role,Location,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle2[Client,Role,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle2[CertificateTemplate,Role,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle2[Course,Role,Therapist,r]  1
    zV[r,lb,Role,Therapist]  triangle2[Role,Therapist,Instructor,r]  1
    zV[c,lb,Role,Therapist]  choose1[Role,Therapist]  1
    zV[c,lb,Role,Therapist]  axisVdifLB[c,Role,Therapist]  42
    zV[c,lb,Role,Therapist]  triangle1[Role,User,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle1[Role,CourseSession,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle1[Role,Clinic,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle1[Role,Location,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle2[Client,Role,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle2[CertificateTemplate,Role,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle2[Course,Role,Therapist,c]  1
    zV[c,lb,Role,Therapist]  triangle2[Role,Therapist,Instructor,c]  1
    zV[r,rt,Role,Instructor]  choose1[Role,Instructor]  1
    zV[r,rt,Role,Instructor]  axisVdifRT[r,Role,Instructor]  42
    zV[r,rt,Role,Instructor]  triangle1[Client,Role,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle1[CertificateTemplate,Role,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle1[Course,Role,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle2[Role,User,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle2[Role,CourseSession,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle2[Role,Clinic,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle2[Role,Location,Instructor,r]  1
    zV[r,rt,Role,Instructor]  triangle2[Role,Therapist,Instructor,r]  1
    zV[c,rt,Role,Instructor]  choose1[Role,Instructor]  1
    zV[c,rt,Role,Instructor]  axisVdifRT[c,Role,Instructor]  42
    zV[c,rt,Role,Instructor]  triangle1[Client,Role,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle1[CertificateTemplate,Role,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle1[Course,Role,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle2[Role,User,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle2[Role,CourseSession,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle2[Role,Clinic,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle2[Role,Location,Instructor,c]  1
    zV[c,rt,Role,Instructor]  triangle2[Role,Therapist,Instructor,c]  1
    zV[r,lb,Role,Instructor]  choose1[Role,Instructor]  1
    zV[r,lb,Role,Instructor]  axisVdifLB[r,Role,Instructor]  42
    zV[r,lb,Role,Instructor]  triangle1[Role,User,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle1[Role,CourseSession,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle1[Role,Clinic,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle1[Role,Location,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle1[Role,Therapist,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle2[Client,Role,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle2[CertificateTemplate,Role,Instructor,r]  1
    zV[r,lb,Role,Instructor]  triangle2[Course,Role,Instructor,r]  1
    zV[c,lb,Role,Instructor]  choose1[Role,Instructor]  1
    zV[c,lb,Role,Instructor]  axisVdifLB[c,Role,Instructor]  42
    zV[c,lb,Role,Instructor]  triangle1[Role,User,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle1[Role,CourseSession,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle1[Role,Clinic,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle1[Role,Location,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle1[Role,Therapist,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle2[Client,Role,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle2[CertificateTemplate,Role,Instructor,c]  1
    zV[c,lb,Role,Instructor]  triangle2[Course,Role,Instructor,c]  1
    zV[r,rt,User,CourseSession]  choose1[User,CourseSession]  1
    zV[r,rt,User,CourseSession]  axisVdifRT[r,User,CourseSession]  42
    zV[r,rt,User,CourseSession]  triangle1[Client,User,CourseSession,r]  1
    zV[r,rt,User,CourseSession]  triangle1[CertificateTemplate,User,CourseSession,r]  1
    zV[r,rt,User,CourseSession]  triangle1[Course,User,CourseSession,r]  1
    zV[r,rt,User,CourseSession]  triangle1[Role,User,CourseSession,r]  1
    zV[r,rt,User,CourseSession]  triangle1[User,CourseSession,Clinic,r]  1
    zV[r,rt,User,CourseSession]  triangle1[User,CourseSession,Location,r]  1
    zV[r,rt,User,CourseSession]  triangle1[User,CourseSession,Therapist,r]  1
    zV[r,rt,User,CourseSession]  triangle1[User,CourseSession,Instructor,r]  1
    zV[c,rt,User,CourseSession]  choose1[User,CourseSession]  1
    zV[c,rt,User,CourseSession]  axisVdifRT[c,User,CourseSession]  42
    zV[c,rt,User,CourseSession]  triangle1[Client,User,CourseSession,c]  1
    zV[c,rt,User,CourseSession]  triangle1[CertificateTemplate,User,CourseSession,c]  1
    zV[c,rt,User,CourseSession]  triangle1[Course,User,CourseSession,c]  1
    zV[c,rt,User,CourseSession]  triangle1[Role,User,CourseSession,c]  1
    zV[c,rt,User,CourseSession]  triangle1[User,CourseSession,Clinic,c]  1
    zV[c,rt,User,CourseSession]  triangle1[User,CourseSession,Location,c]  1
    zV[c,rt,User,CourseSession]  triangle1[User,CourseSession,Therapist,c]  1
    zV[c,rt,User,CourseSession]  triangle1[User,CourseSession,Instructor,c]  1
    zV[r,lb,User,CourseSession]  choose1[User,CourseSession]  1
    zV[r,lb,User,CourseSession]  axisVdifLB[r,User,CourseSession]  42
    zV[r,lb,User,CourseSession]  triangle2[Client,User,CourseSession,r]  1
    zV[r,lb,User,CourseSession]  triangle2[CertificateTemplate,User,CourseSession,r]  1
    zV[r,lb,User,CourseSession]  triangle2[Course,User,CourseSession,r]  1
    zV[r,lb,User,CourseSession]  triangle2[Role,User,CourseSession,r]  1
    zV[r,lb,User,CourseSession]  triangle2[User,CourseSession,Clinic,r]  1
    zV[r,lb,User,CourseSession]  triangle2[User,CourseSession,Location,r]  1
    zV[r,lb,User,CourseSession]  triangle2[User,CourseSession,Therapist,r]  1
    zV[r,lb,User,CourseSession]  triangle2[User,CourseSession,Instructor,r]  1
    zV[c,lb,User,CourseSession]  choose1[User,CourseSession]  1
    zV[c,lb,User,CourseSession]  axisVdifLB[c,User,CourseSession]  42
    zV[c,lb,User,CourseSession]  triangle2[Client,User,CourseSession,c]  1
    zV[c,lb,User,CourseSession]  triangle2[CertificateTemplate,User,CourseSession,c]  1
    zV[c,lb,User,CourseSession]  triangle2[Course,User,CourseSession,c]  1
    zV[c,lb,User,CourseSession]  triangle2[Role,User,CourseSession,c]  1
    zV[c,lb,User,CourseSession]  triangle2[User,CourseSession,Clinic,c]  1
    zV[c,lb,User,CourseSession]  triangle2[User,CourseSession,Location,c]  1
    zV[c,lb,User,CourseSession]  triangle2[User,CourseSession,Therapist,c]  1
    zV[c,lb,User,CourseSession]  triangle2[User,CourseSession,Instructor,c]  1
    zV[r,rt,User,Clinic]  choose1[User,Clinic]  1
    zV[r,rt,User,Clinic]  axisVdifRT[r,User,Clinic]  42
    zV[r,rt,User,Clinic]  triangle1[Client,User,Clinic,r]  1
    zV[r,rt,User,Clinic]  triangle1[CertificateTemplate,User,Clinic,r]  1
    zV[r,rt,User,Clinic]  triangle1[Course,User,Clinic,r]  1
    zV[r,rt,User,Clinic]  triangle1[Role,User,Clinic,r]  1
    zV[r,rt,User,Clinic]  triangle1[User,Clinic,Location,r]  1
    zV[r,rt,User,Clinic]  triangle1[User,Clinic,Therapist,r]  1
    zV[r,rt,User,Clinic]  triangle1[User,Clinic,Instructor,r]  1
    zV[r,rt,User,Clinic]  triangle2[User,CourseSession,Clinic,r]  1
    zV[c,rt,User,Clinic]  choose1[User,Clinic]  1
    zV[c,rt,User,Clinic]  axisVdifRT[c,User,Clinic]  42
    zV[c,rt,User,Clinic]  triangle1[Client,User,Clinic,c]  1
    zV[c,rt,User,Clinic]  triangle1[CertificateTemplate,User,Clinic,c]  1
    zV[c,rt,User,Clinic]  triangle1[Course,User,Clinic,c]  1
    zV[c,rt,User,Clinic]  triangle1[Role,User,Clinic,c]  1
    zV[c,rt,User,Clinic]  triangle1[User,Clinic,Location,c]  1
    zV[c,rt,User,Clinic]  triangle1[User,Clinic,Therapist,c]  1
    zV[c,rt,User,Clinic]  triangle1[User,Clinic,Instructor,c]  1
    zV[c,rt,User,Clinic]  triangle2[User,CourseSession,Clinic,c]  1
    zV[r,lb,User,Clinic]  choose1[User,Clinic]  1
    zV[r,lb,User,Clinic]  axisVdifLB[r,User,Clinic]  42
    zV[r,lb,User,Clinic]  triangle1[User,CourseSession,Clinic,r]  1
    zV[r,lb,User,Clinic]  triangle2[Client,User,Clinic,r]  1
    zV[r,lb,User,Clinic]  triangle2[CertificateTemplate,User,Clinic,r]  1
    zV[r,lb,User,Clinic]  triangle2[Course,User,Clinic,r]  1
    zV[r,lb,User,Clinic]  triangle2[Role,User,Clinic,r]  1
    zV[r,lb,User,Clinic]  triangle2[User,Clinic,Location,r]  1
    zV[r,lb,User,Clinic]  triangle2[User,Clinic,Therapist,r]  1
    zV[r,lb,User,Clinic]  triangle2[User,Clinic,Instructor,r]  1
    zV[c,lb,User,Clinic]  choose1[User,Clinic]  1
    zV[c,lb,User,Clinic]  axisVdifLB[c,User,Clinic]  42
    zV[c,lb,User,Clinic]  triangle1[User,CourseSession,Clinic,c]  1
    zV[c,lb,User,Clinic]  triangle2[Client,User,Clinic,c]  1
    zV[c,lb,User,Clinic]  triangle2[CertificateTemplate,User,Clinic,c]  1
    zV[c,lb,User,Clinic]  triangle2[Course,User,Clinic,c]  1
    zV[c,lb,User,Clinic]  triangle2[Role,User,Clinic,c]  1
    zV[c,lb,User,Clinic]  triangle2[User,Clinic,Location,c]  1
    zV[c,lb,User,Clinic]  triangle2[User,Clinic,Therapist,c]  1
    zV[c,lb,User,Clinic]  triangle2[User,Clinic,Instructor,c]  1
    zV[r,rt,User,Location]  choose1[User,Location]  1
    zV[r,rt,User,Location]  axisVdifRT[r,User,Location]  42
    zV[r,rt,User,Location]  triangle1[Client,User,Location,r]  1
    zV[r,rt,User,Location]  triangle1[CertificateTemplate,User,Location,r]  1
    zV[r,rt,User,Location]  triangle1[Course,User,Location,r]  1
    zV[r,rt,User,Location]  triangle1[Role,User,Location,r]  1
    zV[r,rt,User,Location]  triangle1[User,Location,Therapist,r]  1
    zV[r,rt,User,Location]  triangle1[User,Location,Instructor,r]  1
    zV[r,rt,User,Location]  triangle2[User,CourseSession,Location,r]  1
    zV[r,rt,User,Location]  triangle2[User,Clinic,Location,r]  1
    zV[c,rt,User,Location]  choose1[User,Location]  1
    zV[c,rt,User,Location]  axisVdifRT[c,User,Location]  42
    zV[c,rt,User,Location]  triangle1[Client,User,Location,c]  1
    zV[c,rt,User,Location]  triangle1[CertificateTemplate,User,Location,c]  1
    zV[c,rt,User,Location]  triangle1[Course,User,Location,c]  1
    zV[c,rt,User,Location]  triangle1[Role,User,Location,c]  1
    zV[c,rt,User,Location]  triangle1[User,Location,Therapist,c]  1
    zV[c,rt,User,Location]  triangle1[User,Location,Instructor,c]  1
    zV[c,rt,User,Location]  triangle2[User,CourseSession,Location,c]  1
    zV[c,rt,User,Location]  triangle2[User,Clinic,Location,c]  1
    zV[r,lb,User,Location]  choose1[User,Location]  1
    zV[r,lb,User,Location]  axisVdifLB[r,User,Location]  42
    zV[r,lb,User,Location]  triangle1[User,CourseSession,Location,r]  1
    zV[r,lb,User,Location]  triangle1[User,Clinic,Location,r]  1
    zV[r,lb,User,Location]  triangle2[Client,User,Location,r]  1
    zV[r,lb,User,Location]  triangle2[CertificateTemplate,User,Location,r]  1
    zV[r,lb,User,Location]  triangle2[Course,User,Location,r]  1
    zV[r,lb,User,Location]  triangle2[Role,User,Location,r]  1
    zV[r,lb,User,Location]  triangle2[User,Location,Therapist,r]  1
    zV[r,lb,User,Location]  triangle2[User,Location,Instructor,r]  1
    zV[c,lb,User,Location]  choose1[User,Location]  1
    zV[c,lb,User,Location]  axisVdifLB[c,User,Location]  42
    zV[c,lb,User,Location]  triangle1[User,CourseSession,Location,c]  1
    zV[c,lb,User,Location]  triangle1[User,Clinic,Location,c]  1
    zV[c,lb,User,Location]  triangle2[Client,User,Location,c]  1
    zV[c,lb,User,Location]  triangle2[CertificateTemplate,User,Location,c]  1
    zV[c,lb,User,Location]  triangle2[Course,User,Location,c]  1
    zV[c,lb,User,Location]  triangle2[Role,User,Location,c]  1
    zV[c,lb,User,Location]  triangle2[User,Location,Therapist,c]  1
    zV[c,lb,User,Location]  triangle2[User,Location,Instructor,c]  1
    zV[r,rt,User,Therapist]  choose1[User,Therapist]  1
    zV[r,rt,User,Therapist]  axisVdifRT[r,User,Therapist]  42
    zV[r,rt,User,Therapist]  DistAxisLB1[c,User,Therapist]  -11
    zV[r,rt,User,Therapist]  triangle1[Client,User,Therapist,r]  1
    zV[r,rt,User,Therapist]  triangle1[CertificateTemplate,User,Therapist,r]  1
    zV[r,rt,User,Therapist]  triangle1[Course,User,Therapist,r]  1
    zV[r,rt,User,Therapist]  triangle1[Role,User,Therapist,r]  1
    zV[r,rt,User,Therapist]  triangle1[User,Therapist,Instructor,r]  1
    zV[r,rt,User,Therapist]  triangle2[User,CourseSession,Therapist,r]  1
    zV[r,rt,User,Therapist]  triangle2[User,Clinic,Therapist,r]  1
    zV[r,rt,User,Therapist]  triangle2[User,Location,Therapist,r]  1
    zV[c,rt,User,Therapist]  DistSumLB[User,Therapist]  2.5
    zV[c,rt,User,Therapist]  compDistAxis2[c,User,Therapist]  2
    zV[c,rt,User,Therapist]  choose1[User,Therapist]  1
    zV[c,rt,User,Therapist]  axisVdifRT[c,User,Therapist]  42
    zV[c,rt,User,Therapist]  DistAxisLB1[r,User,Therapist]  -8.5
    zV[c,rt,User,Therapist]  triangle1[Client,User,Therapist,c]  1
    zV[c,rt,User,Therapist]  triangle1[CertificateTemplate,User,Therapist,c]  1
    zV[c,rt,User,Therapist]  triangle1[Course,User,Therapist,c]  1
    zV[c,rt,User,Therapist]  triangle1[Role,User,Therapist,c]  1
    zV[c,rt,User,Therapist]  triangle1[User,Therapist,Instructor,c]  1
    zV[c,rt,User,Therapist]  triangle2[User,CourseSession,Therapist,c]  1
    zV[c,rt,User,Therapist]  triangle2[User,Clinic,Therapist,c]  1
    zV[c,rt,User,Therapist]  triangle2[User,Location,Therapist,c]  1
    zV[r,lb,User,Therapist]  choose1[User,Therapist]  1
    zV[r,lb,User,Therapist]  axisVdifLB[r,User,Therapist]  42
    zV[r,lb,User,Therapist]  DistAxisLB1[c,User,Therapist]  -11
    zV[r,lb,User,Therapist]  triangle1[User,CourseSession,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle1[User,Clinic,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle1[User,Location,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle2[Client,User,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle2[CertificateTemplate,User,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle2[Course,User,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle2[Role,User,Therapist,r]  1
    zV[r,lb,User,Therapist]  triangle2[User,Therapist,Instructor,r]  1
    zV[c,lb,User,Therapist]  DistSumLB[User,Therapist]  2.5
    zV[c,lb,User,Therapist]  compDistAxis1[c,User,Therapist]  2
    zV[c,lb,User,Therapist]  choose1[User,Therapist]  1
    zV[c,lb,User,Therapist]  axisVdifLB[c,User,Therapist]  42
    zV[c,lb,User,Therapist]  DistAxisLB1[r,User,Therapist]  -8.5
    zV[c,lb,User,Therapist]  triangle1[User,CourseSession,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle1[User,Clinic,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle1[User,Location,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle2[Client,User,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle2[CertificateTemplate,User,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle2[Course,User,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle2[Role,User,Therapist,c]  1
    zV[c,lb,User,Therapist]  triangle2[User,Therapist,Instructor,c]  1
    zV[r,rt,User,Instructor]  choose1[User,Instructor]  1
    zV[r,rt,User,Instructor]  axisVdifRT[r,User,Instructor]  42
    zV[r,rt,User,Instructor]  DistAxisLB1[c,User,Instructor]  -11.5
    zV[r,rt,User,Instructor]  triangle1[Client,User,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle1[CertificateTemplate,User,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle1[Course,User,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle1[Role,User,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle2[User,CourseSession,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle2[User,Clinic,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle2[User,Location,Instructor,r]  1
    zV[r,rt,User,Instructor]  triangle2[User,Therapist,Instructor,r]  1
    zV[c,rt,User,Instructor]  DistSumLB[User,Instructor]  3
    zV[c,rt,User,Instructor]  compDistAxis2[c,User,Instructor]  4
    zV[c,rt,User,Instructor]  choose1[User,Instructor]  1
    zV[c,rt,User,Instructor]  axisVdifRT[c,User,Instructor]  42
    zV[c,rt,User,Instructor]  DistAxisLB1[r,User,Instructor]  -8.5
    zV[c,rt,User,Instructor]  triangle1[Client,User,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle1[CertificateTemplate,User,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle1[Course,User,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle1[Role,User,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle2[User,CourseSession,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle2[User,Clinic,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle2[User,Location,Instructor,c]  1
    zV[c,rt,User,Instructor]  triangle2[User,Therapist,Instructor,c]  1
    zV[r,lb,User,Instructor]  choose1[User,Instructor]  1
    zV[r,lb,User,Instructor]  axisVdifLB[r,User,Instructor]  42
    zV[r,lb,User,Instructor]  DistAxisLB1[c,User,Instructor]  -11.5
    zV[r,lb,User,Instructor]  triangle1[User,CourseSession,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle1[User,Clinic,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle1[User,Location,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle1[User,Therapist,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle2[Client,User,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle2[CertificateTemplate,User,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle2[Course,User,Instructor,r]  1
    zV[r,lb,User,Instructor]  triangle2[Role,User,Instructor,r]  1
    zV[c,lb,User,Instructor]  DistSumLB[User,Instructor]  3
    zV[c,lb,User,Instructor]  compDistAxis1[c,User,Instructor]  4
    zV[c,lb,User,Instructor]  choose1[User,Instructor]  1
    zV[c,lb,User,Instructor]  axisVdifLB[c,User,Instructor]  42
    zV[c,lb,User,Instructor]  DistAxisLB1[r,User,Instructor]  -8.5
    zV[c,lb,User,Instructor]  triangle1[User,CourseSession,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle1[User,Clinic,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle1[User,Location,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle1[User,Therapist,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle2[Client,User,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle2[CertificateTemplate,User,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle2[Course,User,Instructor,c]  1
    zV[c,lb,User,Instructor]  triangle2[Role,User,Instructor,c]  1
    zV[r,rt,CourseSession,Clinic]  choose1[CourseSession,Clinic]  1
    zV[r,rt,CourseSession,Clinic]  axisVdifRT[r,CourseSession,Clinic]  42
    zV[r,rt,CourseSession,Clinic]  triangle1[Client,CourseSession,Clinic,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[CertificateTemplate,CourseSession,Clinic,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[Course,CourseSession,Clinic,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[Role,CourseSession,Clinic,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[User,CourseSession,Clinic,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[CourseSession,Clinic,Location,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[CourseSession,Clinic,Therapist,r]  1
    zV[r,rt,CourseSession,Clinic]  triangle1[CourseSession,Clinic,Instructor,r]  1
    zV[c,rt,CourseSession,Clinic]  choose1[CourseSession,Clinic]  1
    zV[c,rt,CourseSession,Clinic]  axisVdifRT[c,CourseSession,Clinic]  42
    zV[c,rt,CourseSession,Clinic]  triangle1[Client,CourseSession,Clinic,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[CertificateTemplate,CourseSession,Clinic,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[Course,CourseSession,Clinic,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[Role,CourseSession,Clinic,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[User,CourseSession,Clinic,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[CourseSession,Clinic,Location,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[CourseSession,Clinic,Therapist,c]  1
    zV[c,rt,CourseSession,Clinic]  triangle1[CourseSession,Clinic,Instructor,c]  1
    zV[r,lb,CourseSession,Clinic]  choose1[CourseSession,Clinic]  1
    zV[r,lb,CourseSession,Clinic]  axisVdifLB[r,CourseSession,Clinic]  42
    zV[r,lb,CourseSession,Clinic]  triangle2[Client,CourseSession,Clinic,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[CertificateTemplate,CourseSession,Clinic,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[Course,CourseSession,Clinic,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[Role,CourseSession,Clinic,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[User,CourseSession,Clinic,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[CourseSession,Clinic,Location,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[CourseSession,Clinic,Therapist,r]  1
    zV[r,lb,CourseSession,Clinic]  triangle2[CourseSession,Clinic,Instructor,r]  1
    zV[c,lb,CourseSession,Clinic]  choose1[CourseSession,Clinic]  1
    zV[c,lb,CourseSession,Clinic]  axisVdifLB[c,CourseSession,Clinic]  42
    zV[c,lb,CourseSession,Clinic]  triangle2[Client,CourseSession,Clinic,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[CertificateTemplate,CourseSession,Clinic,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[Course,CourseSession,Clinic,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[Role,CourseSession,Clinic,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[User,CourseSession,Clinic,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[CourseSession,Clinic,Location,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[CourseSession,Clinic,Therapist,c]  1
    zV[c,lb,CourseSession,Clinic]  triangle2[CourseSession,Clinic,Instructor,c]  1
    zV[r,rt,CourseSession,Location]  choose1[CourseSession,Location]  1
    zV[r,rt,CourseSession,Location]  axisVdifRT[r,CourseSession,Location]  42
    zV[r,rt,CourseSession,Location]  DistAxisLB1[c,Location,CourseSession]  -12.5
    zV[r,rt,CourseSession,Location]  triangle1[Client,CourseSession,Location,r]  1
    zV[r,rt,CourseSession,Location]  triangle1[CertificateTemplate,CourseSession,Location,r]  1
    zV[r,rt,CourseSession,Location]  triangle1[Course,CourseSession,Location,r]  1
    zV[r,rt,CourseSession,Location]  triangle1[Role,CourseSession,Location,r]  1
    zV[r,rt,CourseSession,Location]  triangle1[User,CourseSession,Location,r]  1
    zV[r,rt,CourseSession,Location]  triangle1[CourseSession,Location,Therapist,r]  1
    zV[r,rt,CourseSession,Location]  triangle1[CourseSession,Location,Instructor,r]  1
    zV[r,rt,CourseSession,Location]  triangle2[CourseSession,Clinic,Location,r]  1
    zV[c,rt,CourseSession,Location]  DistSumLB[Location,CourseSession]  3.5
    zV[c,rt,CourseSession,Location]  compDistAxis1[c,Location,CourseSession]  8
    zV[c,rt,CourseSession,Location]  choose1[CourseSession,Location]  1
    zV[c,rt,CourseSession,Location]  axisVdifRT[c,CourseSession,Location]  42
    zV[c,rt,CourseSession,Location]  DistAxisLB1[r,Location,CourseSession]  -9
    zV[c,rt,CourseSession,Location]  triangle1[Client,CourseSession,Location,c]  1
    zV[c,rt,CourseSession,Location]  triangle1[CertificateTemplate,CourseSession,Location,c]  1
    zV[c,rt,CourseSession,Location]  triangle1[Course,CourseSession,Location,c]  1
    zV[c,rt,CourseSession,Location]  triangle1[Role,CourseSession,Location,c]  1
    zV[c,rt,CourseSession,Location]  triangle1[User,CourseSession,Location,c]  1
    zV[c,rt,CourseSession,Location]  triangle1[CourseSession,Location,Therapist,c]  1
    zV[c,rt,CourseSession,Location]  triangle1[CourseSession,Location,Instructor,c]  1
    zV[c,rt,CourseSession,Location]  triangle2[CourseSession,Clinic,Location,c]  1
    zV[r,lb,CourseSession,Location]  choose1[CourseSession,Location]  1
    zV[r,lb,CourseSession,Location]  axisVdifLB[r,CourseSession,Location]  42
    zV[r,lb,CourseSession,Location]  DistAxisLB1[c,Location,CourseSession]  -12.5
    zV[r,lb,CourseSession,Location]  triangle1[CourseSession,Clinic,Location,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[Client,CourseSession,Location,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[CertificateTemplate,CourseSession,Location,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[Course,CourseSession,Location,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[Role,CourseSession,Location,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[User,CourseSession,Location,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[CourseSession,Location,Therapist,r]  1
    zV[r,lb,CourseSession,Location]  triangle2[CourseSession,Location,Instructor,r]  1
    zV[c,lb,CourseSession,Location]  DistSumLB[Location,CourseSession]  3.5
    zV[c,lb,CourseSession,Location]  compDistAxis2[c,Location,CourseSession]  8
    zV[c,lb,CourseSession,Location]  choose1[CourseSession,Location]  1
    zV[c,lb,CourseSession,Location]  axisVdifLB[c,CourseSession,Location]  42
    zV[c,lb,CourseSession,Location]  DistAxisLB1[r,Location,CourseSession]  -9
    zV[c,lb,CourseSession,Location]  triangle1[CourseSession,Clinic,Location,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[Client,CourseSession,Location,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[CertificateTemplate,CourseSession,Location,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[Course,CourseSession,Location,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[Role,CourseSession,Location,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[User,CourseSession,Location,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[CourseSession,Location,Therapist,c]  1
    zV[c,lb,CourseSession,Location]  triangle2[CourseSession,Location,Instructor,c]  1
    zV[r,rt,CourseSession,Therapist]  choose1[CourseSession,Therapist]  1
    zV[r,rt,CourseSession,Therapist]  axisVdifRT[r,CourseSession,Therapist]  42
    zV[r,rt,CourseSession,Therapist]  DistAxisLB1[c,Therapist,CourseSession]  -12.5
    zV[r,rt,CourseSession,Therapist]  triangle1[Client,CourseSession,Therapist,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle1[CertificateTemplate,CourseSession,Therapist,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle1[Course,CourseSession,Therapist,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle1[Role,CourseSession,Therapist,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle1[User,CourseSession,Therapist,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle1[CourseSession,Therapist,Instructor,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle2[CourseSession,Clinic,Therapist,r]  1
    zV[r,rt,CourseSession,Therapist]  triangle2[CourseSession,Location,Therapist,r]  1
    zV[c,rt,CourseSession,Therapist]  DistSumLB[Therapist,CourseSession]  3
    zV[c,rt,CourseSession,Therapist]  compDistAxis1[c,Therapist,CourseSession]  8
    zV[c,rt,CourseSession,Therapist]  choose1[CourseSession,Therapist]  1
    zV[c,rt,CourseSession,Therapist]  axisVdifRT[c,CourseSession,Therapist]  42
    zV[c,rt,CourseSession,Therapist]  DistAxisLB1[r,Therapist,CourseSession]  -9.5
    zV[c,rt,CourseSession,Therapist]  triangle1[Client,CourseSession,Therapist,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle1[CertificateTemplate,CourseSession,Therapist,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle1[Course,CourseSession,Therapist,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle1[Role,CourseSession,Therapist,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle1[User,CourseSession,Therapist,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle1[CourseSession,Therapist,Instructor,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle2[CourseSession,Clinic,Therapist,c]  1
    zV[c,rt,CourseSession,Therapist]  triangle2[CourseSession,Location,Therapist,c]  1
    zV[r,lb,CourseSession,Therapist]  choose1[CourseSession,Therapist]  1
    zV[r,lb,CourseSession,Therapist]  axisVdifLB[r,CourseSession,Therapist]  42
    zV[r,lb,CourseSession,Therapist]  DistAxisLB1[c,Therapist,CourseSession]  -12.5
    zV[r,lb,CourseSession,Therapist]  triangle1[CourseSession,Clinic,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle1[CourseSession,Location,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle2[Client,CourseSession,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle2[CertificateTemplate,CourseSession,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle2[Course,CourseSession,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle2[Role,CourseSession,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle2[User,CourseSession,Therapist,r]  1
    zV[r,lb,CourseSession,Therapist]  triangle2[CourseSession,Therapist,Instructor,r]  1
    zV[c,lb,CourseSession,Therapist]  DistSumLB[Therapist,CourseSession]  3
    zV[c,lb,CourseSession,Therapist]  compDistAxis2[c,Therapist,CourseSession]  8
    zV[c,lb,CourseSession,Therapist]  choose1[CourseSession,Therapist]  1
    zV[c,lb,CourseSession,Therapist]  axisVdifLB[c,CourseSession,Therapist]  42
    zV[c,lb,CourseSession,Therapist]  DistAxisLB1[r,Therapist,CourseSession]  -9.5
    zV[c,lb,CourseSession,Therapist]  triangle1[CourseSession,Clinic,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle1[CourseSession,Location,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle2[Client,CourseSession,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle2[CertificateTemplate,CourseSession,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle2[Course,CourseSession,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle2[Role,CourseSession,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle2[User,CourseSession,Therapist,c]  1
    zV[c,lb,CourseSession,Therapist]  triangle2[CourseSession,Therapist,Instructor,c]  1
    zV[r,rt,CourseSession,Instructor]  choose1[CourseSession,Instructor]  1
    zV[r,rt,CourseSession,Instructor]  axisVdifRT[r,CourseSession,Instructor]  42
    zV[r,rt,CourseSession,Instructor]  DistAxisLB1[c,CourseSession,Instructor]  -13
    zV[r,rt,CourseSession,Instructor]  triangle1[Client,CourseSession,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle1[CertificateTemplate,CourseSession,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle1[Course,CourseSession,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle1[Role,CourseSession,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle1[User,CourseSession,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle2[CourseSession,Clinic,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle2[CourseSession,Location,Instructor,r]  1
    zV[r,rt,CourseSession,Instructor]  triangle2[CourseSession,Therapist,Instructor,r]  1
    zV[c,rt,CourseSession,Instructor]  DistSumLB[CourseSession,Instructor]  3.5
    zV[c,rt,CourseSession,Instructor]  compDistAxis2[c,CourseSession,Instructor]  10
    zV[c,rt,CourseSession,Instructor]  choose1[CourseSession,Instructor]  1
    zV[c,rt,CourseSession,Instructor]  axisVdifRT[c,CourseSession,Instructor]  42
    zV[c,rt,CourseSession,Instructor]  DistAxisLB1[r,CourseSession,Instructor]  -9.5
    zV[c,rt,CourseSession,Instructor]  triangle1[Client,CourseSession,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle1[CertificateTemplate,CourseSession,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle1[Course,CourseSession,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle1[Role,CourseSession,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle1[User,CourseSession,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle2[CourseSession,Clinic,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle2[CourseSession,Location,Instructor,c]  1
    zV[c,rt,CourseSession,Instructor]  triangle2[CourseSession,Therapist,Instructor,c]  1
    zV[r,lb,CourseSession,Instructor]  choose1[CourseSession,Instructor]  1
    zV[r,lb,CourseSession,Instructor]  axisVdifLB[r,CourseSession,Instructor]  42
    zV[r,lb,CourseSession,Instructor]  DistAxisLB1[c,CourseSession,Instructor]  -13
    zV[r,lb,CourseSession,Instructor]  triangle1[CourseSession,Clinic,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle1[CourseSession,Location,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle1[CourseSession,Therapist,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle2[Client,CourseSession,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle2[CertificateTemplate,CourseSession,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle2[Course,CourseSession,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle2[Role,CourseSession,Instructor,r]  1
    zV[r,lb,CourseSession,Instructor]  triangle2[User,CourseSession,Instructor,r]  1
    zV[c,lb,CourseSession,Instructor]  DistSumLB[CourseSession,Instructor]  3.5
    zV[c,lb,CourseSession,Instructor]  compDistAxis1[c,CourseSession,Instructor]  10
    zV[c,lb,CourseSession,Instructor]  choose1[CourseSession,Instructor]  1
    zV[c,lb,CourseSession,Instructor]  axisVdifLB[c,CourseSession,Instructor]  42
    zV[c,lb,CourseSession,Instructor]  DistAxisLB1[r,CourseSession,Instructor]  -9.5
    zV[c,lb,CourseSession,Instructor]  triangle1[CourseSession,Clinic,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle1[CourseSession,Location,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle1[CourseSession,Therapist,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle2[Client,CourseSession,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle2[CertificateTemplate,CourseSession,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle2[Course,CourseSession,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle2[Role,CourseSession,Instructor,c]  1
    zV[c,lb,CourseSession,Instructor]  triangle2[User,CourseSession,Instructor,c]  1
    zV[r,rt,Clinic,Location]  choose1[Clinic,Location]  1
    zV[r,rt,Clinic,Location]  axisVdifRT[r,Clinic,Location]  42
    zV[r,rt,Clinic,Location]  DistAxisLB1[c,Clinic,Location]  -11
    zV[r,rt,Clinic,Location]  triangle1[Client,Clinic,Location,r]  1
    zV[r,rt,Clinic,Location]  triangle1[CertificateTemplate,Clinic,Location,r]  1
    zV[r,rt,Clinic,Location]  triangle1[Course,Clinic,Location,r]  1
    zV[r,rt,Clinic,Location]  triangle1[Role,Clinic,Location,r]  1
    zV[r,rt,Clinic,Location]  triangle1[User,Clinic,Location,r]  1
    zV[r,rt,Clinic,Location]  triangle1[CourseSession,Clinic,Location,r]  1
    zV[r,rt,Clinic,Location]  triangle1[Clinic,Location,Therapist,r]  1
    zV[r,rt,Clinic,Location]  triangle1[Clinic,Location,Instructor,r]  1
    zV[c,rt,Clinic,Location]  DistSumLB[Clinic,Location]  2.5
    zV[c,rt,Clinic,Location]  compDistAxis2[c,Clinic,Location]  2
    zV[c,rt,Clinic,Location]  choose1[Clinic,Location]  1
    zV[c,rt,Clinic,Location]  axisVdifRT[c,Clinic,Location]  42
    zV[c,rt,Clinic,Location]  DistAxisLB1[r,Clinic,Location]  -8.5
    zV[c,rt,Clinic,Location]  triangle1[Client,Clinic,Location,c]  1
    zV[c,rt,Clinic,Location]  triangle1[CertificateTemplate,Clinic,Location,c]  1
    zV[c,rt,Clinic,Location]  triangle1[Course,Clinic,Location,c]  1
    zV[c,rt,Clinic,Location]  triangle1[Role,Clinic,Location,c]  1
    zV[c,rt,Clinic,Location]  triangle1[User,Clinic,Location,c]  1
    zV[c,rt,Clinic,Location]  triangle1[CourseSession,Clinic,Location,c]  1
    zV[c,rt,Clinic,Location]  triangle1[Clinic,Location,Therapist,c]  1
    zV[c,rt,Clinic,Location]  triangle1[Clinic,Location,Instructor,c]  1
    zV[r,lb,Clinic,Location]  choose1[Clinic,Location]  1
    zV[r,lb,Clinic,Location]  axisVdifLB[r,Clinic,Location]  42
    zV[r,lb,Clinic,Location]  DistAxisLB1[c,Clinic,Location]  -11
    zV[r,lb,Clinic,Location]  triangle2[Client,Clinic,Location,r]  1
    zV[r,lb,Clinic,Location]  triangle2[CertificateTemplate,Clinic,Location,r]  1
    zV[r,lb,Clinic,Location]  triangle2[Course,Clinic,Location,r]  1
    zV[r,lb,Clinic,Location]  triangle2[Role,Clinic,Location,r]  1
    zV[r,lb,Clinic,Location]  triangle2[User,Clinic,Location,r]  1
    zV[r,lb,Clinic,Location]  triangle2[CourseSession,Clinic,Location,r]  1
    zV[r,lb,Clinic,Location]  triangle2[Clinic,Location,Therapist,r]  1
    zV[r,lb,Clinic,Location]  triangle2[Clinic,Location,Instructor,r]  1
    zV[c,lb,Clinic,Location]  DistSumLB[Clinic,Location]  2.5
    zV[c,lb,Clinic,Location]  compDistAxis1[c,Clinic,Location]  2
    zV[c,lb,Clinic,Location]  choose1[Clinic,Location]  1
    zV[c,lb,Clinic,Location]  axisVdifLB[c,Clinic,Location]  42
    zV[c,lb,Clinic,Location]  DistAxisLB1[r,Clinic,Location]  -8.5
    zV[c,lb,Clinic,Location]  triangle2[Client,Clinic,Location,c]  1
    zV[c,lb,Clinic,Location]  triangle2[CertificateTemplate,Clinic,Location,c]  1
    zV[c,lb,Clinic,Location]  triangle2[Course,Clinic,Location,c]  1
    zV[c,lb,Clinic,Location]  triangle2[Role,Clinic,Location,c]  1
    zV[c,lb,Clinic,Location]  triangle2[User,Clinic,Location,c]  1
    zV[c,lb,Clinic,Location]  triangle2[CourseSession,Clinic,Location,c]  1
    zV[c,lb,Clinic,Location]  triangle2[Clinic,Location,Therapist,c]  1
    zV[c,lb,Clinic,Location]  triangle2[Clinic,Location,Instructor,c]  1
    zV[r,rt,Clinic,Therapist]  choose1[Clinic,Therapist]  1
    zV[r,rt,Clinic,Therapist]  axisVdifRT[r,Clinic,Therapist]  42
    zV[r,rt,Clinic,Therapist]  DistAxisLB1[c,Clinic,Therapist]  -11
    zV[r,rt,Clinic,Therapist]  triangle1[Client,Clinic,Therapist,r]  1
    zV[r,rt,Clinic,Therapist]  triangle1[CertificateTemplate,Clinic,Therapist,r]  1
    zV[r,rt,Clinic,Therapist]  triangle1[Course,Clinic,Therapist,r]  1
    zV[r,rt,Clinic,Therapist]  triangle1[Role,Clinic,Therapist,r]  1
    zV[r,rt,Clinic,Therapist]  triangle1[User,Clinic,Therapist,r]  1
    zV[r,rt,Clinic,Therapist]  triangle1[CourseSession,Clinic,Therapist,r]  1
    zV[r,rt,Clinic,Therapist]  triangle1[Clinic,Therapist,Instructor,r]  1
    zV[r,rt,Clinic,Therapist]  triangle2[Clinic,Location,Therapist,r]  1
    zV[c,rt,Clinic,Therapist]  DistSumLB[Clinic,Therapist]  2
    zV[c,rt,Clinic,Therapist]  compDistAxis2[c,Clinic,Therapist]  2
    zV[c,rt,Clinic,Therapist]  choose1[Clinic,Therapist]  1
    zV[c,rt,Clinic,Therapist]  axisVdifRT[c,Clinic,Therapist]  42
    zV[c,rt,Clinic,Therapist]  DistAxisLB1[r,Clinic,Therapist]  -9
    zV[c,rt,Clinic,Therapist]  triangle1[Client,Clinic,Therapist,c]  1
    zV[c,rt,Clinic,Therapist]  triangle1[CertificateTemplate,Clinic,Therapist,c]  1
    zV[c,rt,Clinic,Therapist]  triangle1[Course,Clinic,Therapist,c]  1
    zV[c,rt,Clinic,Therapist]  triangle1[Role,Clinic,Therapist,c]  1
    zV[c,rt,Clinic,Therapist]  triangle1[User,Clinic,Therapist,c]  1
    zV[c,rt,Clinic,Therapist]  triangle1[CourseSession,Clinic,Therapist,c]  1
    zV[c,rt,Clinic,Therapist]  triangle1[Clinic,Therapist,Instructor,c]  1
    zV[c,rt,Clinic,Therapist]  triangle2[Clinic,Location,Therapist,c]  1
    zV[r,lb,Clinic,Therapist]  choose1[Clinic,Therapist]  1
    zV[r,lb,Clinic,Therapist]  axisVdifLB[r,Clinic,Therapist]  42
    zV[r,lb,Clinic,Therapist]  DistAxisLB1[c,Clinic,Therapist]  -11
    zV[r,lb,Clinic,Therapist]  triangle1[Clinic,Location,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[Client,Clinic,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[CertificateTemplate,Clinic,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[Course,Clinic,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[Role,Clinic,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[User,Clinic,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[CourseSession,Clinic,Therapist,r]  1
    zV[r,lb,Clinic,Therapist]  triangle2[Clinic,Therapist,Instructor,r]  1
    zV[c,lb,Clinic,Therapist]  DistSumLB[Clinic,Therapist]  2
    zV[c,lb,Clinic,Therapist]  compDistAxis1[c,Clinic,Therapist]  2
    zV[c,lb,Clinic,Therapist]  choose1[Clinic,Therapist]  1
    zV[c,lb,Clinic,Therapist]  axisVdifLB[c,Clinic,Therapist]  42
    zV[c,lb,Clinic,Therapist]  DistAxisLB1[r,Clinic,Therapist]  -9
    zV[c,lb,Clinic,Therapist]  triangle1[Clinic,Location,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[Client,Clinic,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[CertificateTemplate,Clinic,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[Course,Clinic,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[Role,Clinic,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[User,Clinic,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[CourseSession,Clinic,Therapist,c]  1
    zV[c,lb,Clinic,Therapist]  triangle2[Clinic,Therapist,Instructor,c]  1
    zV[r,rt,Clinic,Instructor]  choose1[Clinic,Instructor]  1
    zV[r,rt,Clinic,Instructor]  axisVdifRT[r,Clinic,Instructor]  42
    zV[r,rt,Clinic,Instructor]  triangle1[Client,Clinic,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle1[CertificateTemplate,Clinic,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle1[Course,Clinic,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle1[Role,Clinic,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle1[User,Clinic,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle1[CourseSession,Clinic,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle2[Clinic,Location,Instructor,r]  1
    zV[r,rt,Clinic,Instructor]  triangle2[Clinic,Therapist,Instructor,r]  1
    zV[c,rt,Clinic,Instructor]  choose1[Clinic,Instructor]  1
    zV[c,rt,Clinic,Instructor]  axisVdifRT[c,Clinic,Instructor]  42
    zV[c,rt,Clinic,Instructor]  triangle1[Client,Clinic,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle1[CertificateTemplate,Clinic,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle1[Course,Clinic,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle1[Role,Clinic,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle1[User,Clinic,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle1[CourseSession,Clinic,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle2[Clinic,Location,Instructor,c]  1
    zV[c,rt,Clinic,Instructor]  triangle2[Clinic,Therapist,Instructor,c]  1
    zV[r,lb,Clinic,Instructor]  choose1[Clinic,Instructor]  1
    zV[r,lb,Clinic,Instructor]  axisVdifLB[r,Clinic,Instructor]  42
    zV[r,lb,Clinic,Instructor]  triangle1[Clinic,Location,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle1[Clinic,Therapist,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle2[Client,Clinic,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle2[CertificateTemplate,Clinic,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle2[Course,Clinic,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle2[Role,Clinic,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle2[User,Clinic,Instructor,r]  1
    zV[r,lb,Clinic,Instructor]  triangle2[CourseSession,Clinic,Instructor,r]  1
    zV[c,lb,Clinic,Instructor]  choose1[Clinic,Instructor]  1
    zV[c,lb,Clinic,Instructor]  axisVdifLB[c,Clinic,Instructor]  42
    zV[c,lb,Clinic,Instructor]  triangle1[Clinic,Location,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle1[Clinic,Therapist,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle2[Client,Clinic,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle2[CertificateTemplate,Clinic,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle2[Course,Clinic,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle2[Role,Clinic,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle2[User,Clinic,Instructor,c]  1
    zV[c,lb,Clinic,Instructor]  triangle2[CourseSession,Clinic,Instructor,c]  1
    zV[r,rt,Location,Therapist]  choose1[Location,Therapist]  1
    zV[r,rt,Location,Therapist]  axisVdifRT[r,Location,Therapist]  42
    zV[r,rt,Location,Therapist]  DistAxisLB1[c,Location,Therapist]  -11
    zV[r,rt,Location,Therapist]  triangle1[Client,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[CertificateTemplate,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[Course,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[Role,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[User,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[CourseSession,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[Clinic,Location,Therapist,r]  1
    zV[r,rt,Location,Therapist]  triangle1[Location,Therapist,Instructor,r]  1
    zV[c,rt,Location,Therapist]  DistSumLB[Location,Therapist]  1.5
    zV[c,rt,Location,Therapist]  compDistAxis2[c,Location,Therapist]  2
    zV[c,rt,Location,Therapist]  choose1[Location,Therapist]  1
    zV[c,rt,Location,Therapist]  axisVdifRT[c,Location,Therapist]  42
    zV[c,rt,Location,Therapist]  DistAxisLB1[r,Location,Therapist]  -9.5
    zV[c,rt,Location,Therapist]  triangle1[Client,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[CertificateTemplate,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[Course,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[Role,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[User,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[CourseSession,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[Clinic,Location,Therapist,c]  1
    zV[c,rt,Location,Therapist]  triangle1[Location,Therapist,Instructor,c]  1
    zV[r,lb,Location,Therapist]  choose1[Location,Therapist]  1
    zV[r,lb,Location,Therapist]  axisVdifLB[r,Location,Therapist]  42
    zV[r,lb,Location,Therapist]  DistAxisLB1[c,Location,Therapist]  -11
    zV[r,lb,Location,Therapist]  triangle2[Client,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[CertificateTemplate,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[Course,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[Role,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[User,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[CourseSession,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[Clinic,Location,Therapist,r]  1
    zV[r,lb,Location,Therapist]  triangle2[Location,Therapist,Instructor,r]  1
    zV[c,lb,Location,Therapist]  DistSumLB[Location,Therapist]  1.5
    zV[c,lb,Location,Therapist]  compDistAxis1[c,Location,Therapist]  2
    zV[c,lb,Location,Therapist]  choose1[Location,Therapist]  1
    zV[c,lb,Location,Therapist]  axisVdifLB[c,Location,Therapist]  42
    zV[c,lb,Location,Therapist]  DistAxisLB1[r,Location,Therapist]  -9.5
    zV[c,lb,Location,Therapist]  triangle2[Client,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[CertificateTemplate,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[Course,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[Role,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[User,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[CourseSession,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[Clinic,Location,Therapist,c]  1
    zV[c,lb,Location,Therapist]  triangle2[Location,Therapist,Instructor,c]  1
    zV[r,rt,Location,Instructor]  choose1[Location,Instructor]  1
    zV[r,rt,Location,Instructor]  axisVdifRT[r,Location,Instructor]  42
    zV[r,rt,Location,Instructor]  DistAxisLB1[c,Instructor,Location]  -11.5
    zV[r,rt,Location,Instructor]  triangle1[Client,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle1[CertificateTemplate,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle1[Course,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle1[Role,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle1[User,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle1[CourseSession,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle1[Clinic,Location,Instructor,r]  1
    zV[r,rt,Location,Instructor]  triangle2[Location,Therapist,Instructor,r]  1
    zV[c,rt,Location,Instructor]  DistSumLB[Instructor,Location]  2
    zV[c,rt,Location,Instructor]  compDistAxis1[c,Instructor,Location]  4
    zV[c,rt,Location,Instructor]  choose1[Location,Instructor]  1
    zV[c,rt,Location,Instructor]  axisVdifRT[c,Location,Instructor]  42
    zV[c,rt,Location,Instructor]  DistAxisLB1[r,Instructor,Location]  -9.5
    zV[c,rt,Location,Instructor]  triangle1[Client,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle1[CertificateTemplate,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle1[Course,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle1[Role,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle1[User,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle1[CourseSession,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle1[Clinic,Location,Instructor,c]  1
    zV[c,rt,Location,Instructor]  triangle2[Location,Therapist,Instructor,c]  1
    zV[r,lb,Location,Instructor]  choose1[Location,Instructor]  1
    zV[r,lb,Location,Instructor]  axisVdifLB[r,Location,Instructor]  42
    zV[r,lb,Location,Instructor]  DistAxisLB1[c,Instructor,Location]  -11.5
    zV[r,lb,Location,Instructor]  triangle1[Location,Therapist,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[Client,Location,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[CertificateTemplate,Location,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[Course,Location,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[Role,Location,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[User,Location,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[CourseSession,Location,Instructor,r]  1
    zV[r,lb,Location,Instructor]  triangle2[Clinic,Location,Instructor,r]  1
    zV[c,lb,Location,Instructor]  DistSumLB[Instructor,Location]  2
    zV[c,lb,Location,Instructor]  compDistAxis2[c,Instructor,Location]  4
    zV[c,lb,Location,Instructor]  choose1[Location,Instructor]  1
    zV[c,lb,Location,Instructor]  axisVdifLB[c,Location,Instructor]  42
    zV[c,lb,Location,Instructor]  DistAxisLB1[r,Instructor,Location]  -9.5
    zV[c,lb,Location,Instructor]  triangle1[Location,Therapist,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[Client,Location,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[CertificateTemplate,Location,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[Course,Location,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[Role,Location,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[User,Location,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[CourseSession,Location,Instructor,c]  1
    zV[c,lb,Location,Instructor]  triangle2[Clinic,Location,Instructor,c]  1
    zV[r,rt,Therapist,Instructor]  choose1[Therapist,Instructor]  1
    zV[r,rt,Therapist,Instructor]  axisVdifRT[r,Therapist,Instructor]  42
    zV[r,rt,Therapist,Instructor]  triangle1[Client,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[CertificateTemplate,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[Course,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[Role,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[User,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[CourseSession,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[Clinic,Therapist,Instructor,r]  1
    zV[r,rt,Therapist,Instructor]  triangle1[Location,Therapist,Instructor,r]  1
    zV[c,rt,Therapist,Instructor]  choose1[Therapist,Instructor]  1
    zV[c,rt,Therapist,Instructor]  axisVdifRT[c,Therapist,Instructor]  42
    zV[c,rt,Therapist,Instructor]  triangle1[Client,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[CertificateTemplate,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[Course,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[Role,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[User,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[CourseSession,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[Clinic,Therapist,Instructor,c]  1
    zV[c,rt,Therapist,Instructor]  triangle1[Location,Therapist,Instructor,c]  1
    zV[r,lb,Therapist,Instructor]  choose1[Therapist,Instructor]  1
    zV[r,lb,Therapist,Instructor]  axisVdifLB[r,Therapist,Instructor]  42
    zV[r,lb,Therapist,Instructor]  triangle2[Client,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[CertificateTemplate,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[Course,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[Role,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[User,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[CourseSession,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[Clinic,Therapist,Instructor,r]  1
    zV[r,lb,Therapist,Instructor]  triangle2[Location,Therapist,Instructor,r]  1
    zV[c,lb,Therapist,Instructor]  choose1[Therapist,Instructor]  1
    zV[c,lb,Therapist,Instructor]  axisVdifLB[c,Therapist,Instructor]  42
    zV[c,lb,Therapist,Instructor]  triangle2[Client,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[CertificateTemplate,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[Course,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[Role,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[User,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[CourseSession,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[Clinic,Therapist,Instructor,c]  1
    zV[c,lb,Therapist,Instructor]  triangle2[Location,Therapist,Instructor,c]  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      OBJ       -343
    RHS1      choose1[Client,CertificateTemplate]  1
    RHS1      choose1[Client,Course]  1
    RHS1      choose1[Client,Role]  1
    RHS1      choose1[Client,User]  1
    RHS1      choose1[Client,CourseSession]  1
    RHS1      choose1[Client,Clinic]  1
    RHS1      choose1[Client,Location]  1
    RHS1      choose1[Client,Therapist]  1
    RHS1      choose1[Client,Instructor]  1
    RHS1      choose1[CertificateTemplate,Course]  1
    RHS1      choose1[CertificateTemplate,Role]  1
    RHS1      choose1[CertificateTemplate,User]  1
    RHS1      choose1[CertificateTemplate,CourseSession]  1
    RHS1      choose1[CertificateTemplate,Clinic]  1
    RHS1      choose1[CertificateTemplate,Location]  1
    RHS1      choose1[CertificateTemplate,Therapist]  1
    RHS1      choose1[CertificateTemplate,Instructor]  1
    RHS1      choose1[Course,Role]  1
    RHS1      choose1[Course,User]  1
    RHS1      choose1[Course,CourseSession]  1
    RHS1      choose1[Course,Clinic]  1
    RHS1      choose1[Course,Location]  1
    RHS1      choose1[Course,Therapist]  1
    RHS1      choose1[Course,Instructor]  1
    RHS1      choose1[Role,User]  1
    RHS1      choose1[Role,CourseSession]  1
    RHS1      choose1[Role,Clinic]  1
    RHS1      choose1[Role,Location]  1
    RHS1      choose1[Role,Therapist]  1
    RHS1      choose1[Role,Instructor]  1
    RHS1      choose1[User,CourseSession]  1
    RHS1      choose1[User,Clinic]  1
    RHS1      choose1[User,Location]  1
    RHS1      choose1[User,Therapist]  1
    RHS1      choose1[User,Instructor]  1
    RHS1      choose1[CourseSession,Clinic]  1
    RHS1      choose1[CourseSession,Location]  1
    RHS1      choose1[CourseSession,Therapist]  1
    RHS1      choose1[CourseSession,Instructor]  1
    RHS1      choose1[Clinic,Location]  1
    RHS1      choose1[Clinic,Therapist]  1
    RHS1      choose1[Clinic,Instructor]  1
    RHS1      choose1[Location,Therapist]  1
    RHS1      choose1[Location,Instructor]  1
    RHS1      choose1[Therapist,Instructor]  1
    RHS1      centerDistAxis2[r,Client]  35
    RHS1      centerDistAxis2[r,CertificateTemplate]  37
    RHS1      centerDistAxis2[r,Course]  38
    RHS1      centerDistAxis2[r,Role]  38
    RHS1      centerDistAxis2[r,User]  37
    RHS1      centerDistAxis2[r,CourseSession]  35
    RHS1      centerDistAxis2[r,Clinic]  36
    RHS1      centerDistAxis2[r,Location]  35
    RHS1      centerDistAxis2[r,Therapist]  34
    RHS1      centerDistAxis2[r,Instructor]  34
    RHS1      centerDistAxis2[c,Client]  33
    RHS1      centerDistAxis2[c,CertificateTemplate]  32
    RHS1      centerDistAxis2[c,Course]  34
    RHS1      centerDistAxis2[c,Role]  34
    RHS1      centerDistAxis2[c,User]  33
    RHS1      centerDistAxis2[c,CourseSession]  30
    RHS1      centerDistAxis2[c,Clinic]  33
    RHS1      centerDistAxis2[c,Location]  33
    RHS1      centerDistAxis2[c,Therapist]  33
    RHS1      centerDistAxis2[c,Instructor]  32
    RHS1      axisVdifLB[r,Client,CertificateTemplate]  33
    RHS1      axisVdifLB[r,Client,Course]  33
    RHS1      axisVdifLB[r,Client,Role]  33
    RHS1      axisVdifLB[r,Client,User]  33
    RHS1      axisVdifLB[r,Client,CourseSession]  33
    RHS1      axisVdifLB[r,Client,Clinic]  33
    RHS1      axisVdifLB[r,Client,Location]  33
    RHS1      axisVdifLB[r,Client,Therapist]  33
    RHS1      axisVdifLB[r,Client,Instructor]  33
    RHS1      axisVdifLB[r,CertificateTemplate,Course]  35
    RHS1      axisVdifLB[r,CertificateTemplate,Role]  35
    RHS1      axisVdifLB[r,CertificateTemplate,User]  35
    RHS1      axisVdifLB[r,CertificateTemplate,CourseSession]  35
    RHS1      axisVdifLB[r,CertificateTemplate,Clinic]  35
    RHS1      axisVdifLB[r,CertificateTemplate,Location]  35
    RHS1      axisVdifLB[r,CertificateTemplate,Therapist]  35
    RHS1      axisVdifLB[r,CertificateTemplate,Instructor]  35
    RHS1      axisVdifLB[r,Course,Role]  36
    RHS1      axisVdifLB[r,Course,User]  36
    RHS1      axisVdifLB[r,Course,CourseSession]  36
    RHS1      axisVdifLB[r,Course,Clinic]  36
    RHS1      axisVdifLB[r,Course,Location]  36
    RHS1      axisVdifLB[r,Course,Therapist]  36
    RHS1      axisVdifLB[r,Course,Instructor]  36
    RHS1      axisVdifLB[r,Role,User]  36
    RHS1      axisVdifLB[r,Role,CourseSession]  36
    RHS1      axisVdifLB[r,Role,Clinic]  36
    RHS1      axisVdifLB[r,Role,Location]  36
    RHS1      axisVdifLB[r,Role,Therapist]  36
    RHS1      axisVdifLB[r,Role,Instructor]  36
    RHS1      axisVdifLB[r,User,CourseSession]  35
    RHS1      axisVdifLB[r,User,Clinic]  35
    RHS1      axisVdifLB[r,User,Location]  35
    RHS1      axisVdifLB[r,User,Therapist]  35
    RHS1      axisVdifLB[r,User,Instructor]  35
    RHS1      axisVdifLB[r,CourseSession,Clinic]  33
    RHS1      axisVdifLB[r,CourseSession,Location]  33
    RHS1      axisVdifLB[r,CourseSession,Therapist]  33
    RHS1      axisVdifLB[r,CourseSession,Instructor]  33
    RHS1      axisVdifLB[r,Clinic,Location]  34
    RHS1      axisVdifLB[r,Clinic,Therapist]  34
    RHS1      axisVdifLB[r,Clinic,Instructor]  34
    RHS1      axisVdifLB[r,Location,Therapist]  33
    RHS1      axisVdifLB[r,Location,Instructor]  33
    RHS1      axisVdifLB[r,Therapist,Instructor]  32
    RHS1      axisVdifLB[c,Client,CertificateTemplate]  31
    RHS1      axisVdifLB[c,Client,Course]  31
    RHS1      axisVdifLB[c,Client,Role]  31
    RHS1      axisVdifLB[c,Client,User]  31
    RHS1      axisVdifLB[c,Client,CourseSession]  31
    RHS1      axisVdifLB[c,Client,Clinic]  31
    RHS1      axisVdifLB[c,Client,Location]  31
    RHS1      axisVdifLB[c,Client,Therapist]  31
    RHS1      axisVdifLB[c,Client,Instructor]  31
    RHS1      axisVdifLB[c,CertificateTemplate,Course]  30
    RHS1      axisVdifLB[c,CertificateTemplate,Role]  30
    RHS1      axisVdifLB[c,CertificateTemplate,User]  30
    RHS1      axisVdifLB[c,CertificateTemplate,CourseSession]  30
    RHS1      axisVdifLB[c,CertificateTemplate,Clinic]  30
    RHS1      axisVdifLB[c,CertificateTemplate,Location]  30
    RHS1      axisVdifLB[c,CertificateTemplate,Therapist]  30
    RHS1      axisVdifLB[c,CertificateTemplate,Instructor]  30
    RHS1      axisVdifLB[c,Course,Role]  32
    RHS1      axisVdifLB[c,Course,User]  32
    RHS1      axisVdifLB[c,Course,CourseSession]  32
    RHS1      axisVdifLB[c,Course,Clinic]  32
    RHS1      axisVdifLB[c,Course,Location]  32
    RHS1      axisVdifLB[c,Course,Therapist]  32
    RHS1      axisVdifLB[c,Course,Instructor]  32
    RHS1      axisVdifLB[c,Role,User]  32
    RHS1      axisVdifLB[c,Role,CourseSession]  32
    RHS1      axisVdifLB[c,Role,Clinic]  32
    RHS1      axisVdifLB[c,Role,Location]  32
    RHS1      axisVdifLB[c,Role,Therapist]  32
    RHS1      axisVdifLB[c,Role,Instructor]  32
    RHS1      axisVdifLB[c,User,CourseSession]  31
    RHS1      axisVdifLB[c,User,Clinic]  31
    RHS1      axisVdifLB[c,User,Location]  31
    RHS1      axisVdifLB[c,User,Therapist]  31
    RHS1      axisVdifLB[c,User,Instructor]  31
    RHS1      axisVdifLB[c,CourseSession,Clinic]  28
    RHS1      axisVdifLB[c,CourseSession,Location]  28
    RHS1      axisVdifLB[c,CourseSession,Therapist]  28
    RHS1      axisVdifLB[c,CourseSession,Instructor]  28
    RHS1      axisVdifLB[c,Clinic,Location]  31
    RHS1      axisVdifLB[c,Clinic,Therapist]  31
    RHS1      axisVdifLB[c,Clinic,Instructor]  31
    RHS1      axisVdifLB[c,Location,Therapist]  31
    RHS1      axisVdifLB[c,Location,Instructor]  31
    RHS1      axisVdifLB[c,Therapist,Instructor]  31
    RHS1      axisVdifRT[r,Client,CertificateTemplate]  35
    RHS1      axisVdifRT[r,Client,Course]  36
    RHS1      axisVdifRT[r,Client,Role]  36
    RHS1      axisVdifRT[r,Client,User]  35
    RHS1      axisVdifRT[r,Client,CourseSession]  33
    RHS1      axisVdifRT[r,Client,Clinic]  34
    RHS1      axisVdifRT[r,Client,Location]  33
    RHS1      axisVdifRT[r,Client,Therapist]  32
    RHS1      axisVdifRT[r,Client,Instructor]  32
    RHS1      axisVdifRT[r,CertificateTemplate,Course]  36
    RHS1      axisVdifRT[r,CertificateTemplate,Role]  36
    RHS1      axisVdifRT[r,CertificateTemplate,User]  35
    RHS1      axisVdifRT[r,CertificateTemplate,CourseSession]  33
    RHS1      axisVdifRT[r,CertificateTemplate,Clinic]  34
    RHS1      axisVdifRT[r,CertificateTemplate,Location]  33
    RHS1      axisVdifRT[r,CertificateTemplate,Therapist]  32
    RHS1      axisVdifRT[r,CertificateTemplate,Instructor]  32
    RHS1      axisVdifRT[r,Course,Role]  36
    RHS1      axisVdifRT[r,Course,User]  35
    RHS1      axisVdifRT[r,Course,CourseSession]  33
    RHS1      axisVdifRT[r,Course,Clinic]  34
    RHS1      axisVdifRT[r,Course,Location]  33
    RHS1      axisVdifRT[r,Course,Therapist]  32
    RHS1      axisVdifRT[r,Course,Instructor]  32
    RHS1      axisVdifRT[r,Role,User]  35
    RHS1      axisVdifRT[r,Role,CourseSession]  33
    RHS1      axisVdifRT[r,Role,Clinic]  34
    RHS1      axisVdifRT[r,Role,Location]  33
    RHS1      axisVdifRT[r,Role,Therapist]  32
    RHS1      axisVdifRT[r,Role,Instructor]  32
    RHS1      axisVdifRT[r,User,CourseSession]  33
    RHS1      axisVdifRT[r,User,Clinic]  34
    RHS1      axisVdifRT[r,User,Location]  33
    RHS1      axisVdifRT[r,User,Therapist]  32
    RHS1      axisVdifRT[r,User,Instructor]  32
    RHS1      axisVdifRT[r,CourseSession,Clinic]  34
    RHS1      axisVdifRT[r,CourseSession,Location]  33
    RHS1      axisVdifRT[r,CourseSession,Therapist]  32
    RHS1      axisVdifRT[r,CourseSession,Instructor]  32
    RHS1      axisVdifRT[r,Clinic,Location]  33
    RHS1      axisVdifRT[r,Clinic,Therapist]  32
    RHS1      axisVdifRT[r,Clinic,Instructor]  32
    RHS1      axisVdifRT[r,Location,Therapist]  32
    RHS1      axisVdifRT[r,Location,Instructor]  32
    RHS1      axisVdifRT[r,Therapist,Instructor]  32
    RHS1      axisVdifRT[c,Client,CertificateTemplate]  30
    RHS1      axisVdifRT[c,Client,Course]  32
    RHS1      axisVdifRT[c,Client,Role]  32
    RHS1      axisVdifRT[c,Client,User]  31
    RHS1      axisVdifRT[c,Client,CourseSession]  28
    RHS1      axisVdifRT[c,Client,Clinic]  31
    RHS1      axisVdifRT[c,Client,Location]  31
    RHS1      axisVdifRT[c,Client,Therapist]  31
    RHS1      axisVdifRT[c,Client,Instructor]  30
    RHS1      axisVdifRT[c,CertificateTemplate,Course]  32
    RHS1      axisVdifRT[c,CertificateTemplate,Role]  32
    RHS1      axisVdifRT[c,CertificateTemplate,User]  31
    RHS1      axisVdifRT[c,CertificateTemplate,CourseSession]  28
    RHS1      axisVdifRT[c,CertificateTemplate,Clinic]  31
    RHS1      axisVdifRT[c,CertificateTemplate,Location]  31
    RHS1      axisVdifRT[c,CertificateTemplate,Therapist]  31
    RHS1      axisVdifRT[c,CertificateTemplate,Instructor]  30
    RHS1      axisVdifRT[c,Course,Role]  32
    RHS1      axisVdifRT[c,Course,User]  31
    RHS1      axisVdifRT[c,Course,CourseSession]  28
    RHS1      axisVdifRT[c,Course,Clinic]  31
    RHS1      axisVdifRT[c,Course,Location]  31
    RHS1      axisVdifRT[c,Course,Therapist]  31
    RHS1      axisVdifRT[c,Course,Instructor]  30
    RHS1      axisVdifRT[c,Role,User]  31
    RHS1      axisVdifRT[c,Role,CourseSession]  28
    RHS1      axisVdifRT[c,Role,Clinic]  31
    RHS1      axisVdifRT[c,Role,Location]  31
    RHS1      axisVdifRT[c,Role,Therapist]  31
    RHS1      axisVdifRT[c,Role,Instructor]  30
    RHS1      axisVdifRT[c,User,CourseSession]  28
    RHS1      axisVdifRT[c,User,Clinic]  31
    RHS1      axisVdifRT[c,User,Location]  31
    RHS1      axisVdifRT[c,User,Therapist]  31
    RHS1      axisVdifRT[c,User,Instructor]  30
    RHS1      axisVdifRT[c,CourseSession,Clinic]  31
    RHS1      axisVdifRT[c,CourseSession,Location]  31
    RHS1      axisVdifRT[c,CourseSession,Therapist]  31
    RHS1      axisVdifRT[c,CourseSession,Instructor]  30
    RHS1      axisVdifRT[c,Clinic,Location]  31
    RHS1      axisVdifRT[c,Clinic,Therapist]  31
    RHS1      axisVdifRT[c,Clinic,Instructor]  30
    RHS1      axisVdifRT[c,Location,Therapist]  31
    RHS1      axisVdifRT[c,Location,Instructor]  30
    RHS1      axisVdifRT[c,Therapist,Instructor]  30
    RHS1      compDistAxis1[r,Client,CertificateTemplate]  -1
    RHS1      compDistAxis1[r,Client,Instructor]  0.5
    RHS1      compDistAxis1[r,Client,User]  -1
    RHS1      compDistAxis1[r,CertificateTemplate,CourseSession]  1
    RHS1      compDistAxis1[r,Course,CourseSession]  1.5
    RHS1      compDistAxis1[r,CourseSession,Instructor]  0.5
    RHS1      compDistAxis1[r,Instructor,Location]  -0.5
    RHS1      compDistAxis1[r,Clinic,Location]  0.5
    RHS1      compDistAxis1[r,Clinic,Therapist]  1
    RHS1      compDistAxis1[r,Location,Therapist]  0.5
    RHS1      compDistAxis1[r,Therapist,CourseSession]  -0.5
    RHS1      compDistAxis1[r,Role,User]  0.5
    RHS1      compDistAxis1[r,User,Instructor]  1.5
    RHS1      compDistAxis1[r,User,Therapist]  1.5
    RHS1      compDistAxis1[c,Client,CertificateTemplate]  0.5
    RHS1      compDistAxis1[c,Client,CourseSession]  1.5
    RHS1      compDistAxis1[c,Client,Instructor]  0.5
    RHS1      compDistAxis1[c,CertificateTemplate,CourseSession]  1
    RHS1      compDistAxis1[c,Course,CourseSession]  2
    RHS1      compDistAxis1[c,CourseSession,Instructor]  -1
    RHS1      compDistAxis1[c,Instructor,Location]  -0.5
    RHS1      compDistAxis1[c,Location,CourseSession]  1.5
    RHS1      compDistAxis1[c,Therapist,CourseSession]  1.5
    RHS1      compDistAxis1[c,Role,User]  0.5
    RHS1      compDistAxis1[c,User,Instructor]  0.5
    RHS1      compDistAxis2[r,Client,CertificateTemplate]  1
    RHS1      compDistAxis2[r,Client,Instructor]  -0.5
    RHS1      compDistAxis2[r,Client,User]  1
    RHS1      compDistAxis2[r,CertificateTemplate,CourseSession]  -1
    RHS1      compDistAxis2[r,Course,CourseSession]  -1.5
    RHS1      compDistAxis2[r,CourseSession,Instructor]  -0.5
    RHS1      compDistAxis2[r,Instructor,Location]  0.5
    RHS1      compDistAxis2[r,Clinic,Location]  -0.5
    RHS1      compDistAxis2[r,Clinic,Therapist]  -1
    RHS1      compDistAxis2[r,Location,Therapist]  -0.5
    RHS1      compDistAxis2[r,Therapist,CourseSession]  0.5
    RHS1      compDistAxis2[r,Role,User]  -0.5
    RHS1      compDistAxis2[r,User,Instructor]  -1.5
    RHS1      compDistAxis2[r,User,Therapist]  -1.5
    RHS1      compDistAxis2[c,Client,CertificateTemplate]  -0.5
    RHS1      compDistAxis2[c,Client,CourseSession]  -1.5
    RHS1      compDistAxis2[c,Client,Instructor]  -0.5
    RHS1      compDistAxis2[c,CertificateTemplate,CourseSession]  -1
    RHS1      compDistAxis2[c,Course,CourseSession]  -2
    RHS1      compDistAxis2[c,CourseSession,Instructor]  1
    RHS1      compDistAxis2[c,Instructor,Location]  0.5
    RHS1      compDistAxis2[c,Location,CourseSession]  -1.5
    RHS1      compDistAxis2[c,Therapist,CourseSession]  -1.5
    RHS1      compDistAxis2[c,Role,User]  -0.5
    RHS1      compDistAxis2[c,User,Instructor]  -0.5
    RHS1      DistSumLB[Client,CertificateTemplate]  -8
    RHS1      DistSumLB[Client,CourseSession]  -9
    RHS1      DistSumLB[Client,Instructor]  -9.5
    RHS1      DistSumLB[Client,Location]  -9
    RHS1      DistSumLB[Client,User]  -8
    RHS1      DistSumLB[CertificateTemplate,CourseSession]  -8
    RHS1      DistSumLB[Course,CourseSession]  -7.5
    RHS1      DistSumLB[CourseSession,Instructor]  -9.5
    RHS1      DistSumLB[Instructor,Location]  -9.5
    RHS1      DistSumLB[Clinic,Location]  -8.5
    RHS1      DistSumLB[Clinic,Therapist]  -9
    RHS1      DistSumLB[Location,Therapist]  -9.5
    RHS1      DistSumLB[Location,CourseSession]  -9
    RHS1      DistSumLB[Therapist,CourseSession]  -9.5
    RHS1      DistSumLB[Role,User]  -6.5
    RHS1      DistSumLB[User,Instructor]  -8.5
    RHS1      DistSumLB[User,Therapist]  -8.5
    RHS1      CenterDistSumLB  313
    RHS1      DistAxisLB1[r,Client,CertificateTemplate]  -8
    RHS1      DistAxisLB1[r,Client,CourseSession]  -9
    RHS1      DistAxisLB1[r,Client,Instructor]  -9.5
    RHS1      DistAxisLB1[r,Client,Location]  -9
    RHS1      DistAxisLB1[r,Client,User]  -8
    RHS1      DistAxisLB1[r,CertificateTemplate,CourseSession]  -8
    RHS1      DistAxisLB1[r,Course,CourseSession]  -7.5
    RHS1      DistAxisLB1[r,CourseSession,Instructor]  -9.5
    RHS1      DistAxisLB1[r,Instructor,Location]  -9.5
    RHS1      DistAxisLB1[r,Clinic,Location]  -8.5
    RHS1      DistAxisLB1[r,Clinic,Therapist]  -9
    RHS1      DistAxisLB1[r,Location,Therapist]  -9.5
    RHS1      DistAxisLB1[r,Location,CourseSession]  -9
    RHS1      DistAxisLB1[r,Therapist,CourseSession]  -9.5
    RHS1      DistAxisLB1[r,Role,User]  -6.5
    RHS1      DistAxisLB1[r,User,Instructor]  -8.5
    RHS1      DistAxisLB1[r,User,Therapist]  -8.5
    RHS1      DistAxisLB1[c,Client,CertificateTemplate]  -11.5
    RHS1      DistAxisLB1[c,Client,CourseSession]  -12.5
    RHS1      DistAxisLB1[c,Client,Instructor]  -11.5
    RHS1      DistAxisLB1[c,Client,Location]  -11
    RHS1      DistAxisLB1[c,Client,User]  -11
    RHS1      DistAxisLB1[c,CertificateTemplate,CourseSession]  -13
    RHS1      DistAxisLB1[c,Course,CourseSession]  -12
    RHS1      DistAxisLB1[c,CourseSession,Instructor]  -13
    RHS1      DistAxisLB1[c,Instructor,Location]  -11.5
    RHS1      DistAxisLB1[c,Clinic,Location]  -11
    RHS1      DistAxisLB1[c,Clinic,Therapist]  -11
    RHS1      DistAxisLB1[c,Location,Therapist]  -11
    RHS1      DistAxisLB1[c,Location,CourseSession]  -12.5
    RHS1      DistAxisLB1[c,Therapist,CourseSession]  -12.5
    RHS1      DistAxisLB1[c,Role,User]  -10.5
    RHS1      DistAxisLB1[c,User,Instructor]  -11.5
    RHS1      DistAxisLB1[c,User,Therapist]  -11
    RHS1      triangle1[Client,CertificateTemplate,Course,r]  2
    RHS1      triangle1[Client,CertificateTemplate,Course,c]  2
    RHS1      triangle1[Client,CertificateTemplate,Role,r]  2
    RHS1      triangle1[Client,CertificateTemplate,Role,c]  2
    RHS1      triangle1[Client,CertificateTemplate,User,r]  2
    RHS1      triangle1[Client,CertificateTemplate,User,c]  2
    RHS1      triangle1[Client,CertificateTemplate,CourseSession,r]  2
    RHS1      triangle1[Client,CertificateTemplate,CourseSession,c]  2
    RHS1      triangle1[Client,CertificateTemplate,Clinic,r]  2
    RHS1      triangle1[Client,CertificateTemplate,Clinic,c]  2
    RHS1      triangle1[Client,CertificateTemplate,Location,r]  2
    RHS1      triangle1[Client,CertificateTemplate,Location,c]  2
    RHS1      triangle1[Client,CertificateTemplate,Therapist,r]  2
    RHS1      triangle1[Client,CertificateTemplate,Therapist,c]  2
    RHS1      triangle1[Client,CertificateTemplate,Instructor,r]  2
    RHS1      triangle1[Client,CertificateTemplate,Instructor,c]  2
    RHS1      triangle1[Client,Course,Role,r]  2
    RHS1      triangle1[Client,Course,Role,c]  2
    RHS1      triangle1[Client,Course,User,r]  2
    RHS1      triangle1[Client,Course,User,c]  2
    RHS1      triangle1[Client,Course,CourseSession,r]  2
    RHS1      triangle1[Client,Course,CourseSession,c]  2
    RHS1      triangle1[Client,Course,Clinic,r]  2
    RHS1      triangle1[Client,Course,Clinic,c]  2
    RHS1      triangle1[Client,Course,Location,r]  2
    RHS1      triangle1[Client,Course,Location,c]  2
    RHS1      triangle1[Client,Course,Therapist,r]  2
    RHS1      triangle1[Client,Course,Therapist,c]  2
    RHS1      triangle1[Client,Course,Instructor,r]  2
    RHS1      triangle1[Client,Course,Instructor,c]  2
    RHS1      triangle1[Client,Role,User,r]  2
    RHS1      triangle1[Client,Role,User,c]  2
    RHS1      triangle1[Client,Role,CourseSession,r]  2
    RHS1      triangle1[Client,Role,CourseSession,c]  2
    RHS1      triangle1[Client,Role,Clinic,r]  2
    RHS1      triangle1[Client,Role,Clinic,c]  2
    RHS1      triangle1[Client,Role,Location,r]  2
    RHS1      triangle1[Client,Role,Location,c]  2
    RHS1      triangle1[Client,Role,Therapist,r]  2
    RHS1      triangle1[Client,Role,Therapist,c]  2
    RHS1      triangle1[Client,Role,Instructor,r]  2
    RHS1      triangle1[Client,Role,Instructor,c]  2
    RHS1      triangle1[Client,User,CourseSession,r]  2
    RHS1      triangle1[Client,User,CourseSession,c]  2
    RHS1      triangle1[Client,User,Clinic,r]  2
    RHS1      triangle1[Client,User,Clinic,c]  2
    RHS1      triangle1[Client,User,Location,r]  2
    RHS1      triangle1[Client,User,Location,c]  2
    RHS1      triangle1[Client,User,Therapist,r]  2
    RHS1      triangle1[Client,User,Therapist,c]  2
    RHS1      triangle1[Client,User,Instructor,r]  2
    RHS1      triangle1[Client,User,Instructor,c]  2
    RHS1      triangle1[Client,CourseSession,Clinic,r]  2
    RHS1      triangle1[Client,CourseSession,Clinic,c]  2
    RHS1      triangle1[Client,CourseSession,Location,r]  2
    RHS1      triangle1[Client,CourseSession,Location,c]  2
    RHS1      triangle1[Client,CourseSession,Therapist,r]  2
    RHS1      triangle1[Client,CourseSession,Therapist,c]  2
    RHS1      triangle1[Client,CourseSession,Instructor,r]  2
    RHS1      triangle1[Client,CourseSession,Instructor,c]  2
    RHS1      triangle1[Client,Clinic,Location,r]  2
    RHS1      triangle1[Client,Clinic,Location,c]  2
    RHS1      triangle1[Client,Clinic,Therapist,r]  2
    RHS1      triangle1[Client,Clinic,Therapist,c]  2
    RHS1      triangle1[Client,Clinic,Instructor,r]  2
    RHS1      triangle1[Client,Clinic,Instructor,c]  2
    RHS1      triangle1[Client,Location,Therapist,r]  2
    RHS1      triangle1[Client,Location,Therapist,c]  2
    RHS1      triangle1[Client,Location,Instructor,r]  2
    RHS1      triangle1[Client,Location,Instructor,c]  2
    RHS1      triangle1[Client,Therapist,Instructor,r]  2
    RHS1      triangle1[Client,Therapist,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,Course,Role,r]  2
    RHS1      triangle1[CertificateTemplate,Course,Role,c]  2
    RHS1      triangle1[CertificateTemplate,Course,User,r]  2
    RHS1      triangle1[CertificateTemplate,Course,User,c]  2
    RHS1      triangle1[CertificateTemplate,Course,CourseSession,r]  2
    RHS1      triangle1[CertificateTemplate,Course,CourseSession,c]  2
    RHS1      triangle1[CertificateTemplate,Course,Clinic,r]  2
    RHS1      triangle1[CertificateTemplate,Course,Clinic,c]  2
    RHS1      triangle1[CertificateTemplate,Course,Location,r]  2
    RHS1      triangle1[CertificateTemplate,Course,Location,c]  2
    RHS1      triangle1[CertificateTemplate,Course,Therapist,r]  2
    RHS1      triangle1[CertificateTemplate,Course,Therapist,c]  2
    RHS1      triangle1[CertificateTemplate,Course,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,Course,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,Role,User,r]  2
    RHS1      triangle1[CertificateTemplate,Role,User,c]  2
    RHS1      triangle1[CertificateTemplate,Role,CourseSession,r]  2
    RHS1      triangle1[CertificateTemplate,Role,CourseSession,c]  2
    RHS1      triangle1[CertificateTemplate,Role,Clinic,r]  2
    RHS1      triangle1[CertificateTemplate,Role,Clinic,c]  2
    RHS1      triangle1[CertificateTemplate,Role,Location,r]  2
    RHS1      triangle1[CertificateTemplate,Role,Location,c]  2
    RHS1      triangle1[CertificateTemplate,Role,Therapist,r]  2
    RHS1      triangle1[CertificateTemplate,Role,Therapist,c]  2
    RHS1      triangle1[CertificateTemplate,Role,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,Role,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,User,CourseSession,r]  2
    RHS1      triangle1[CertificateTemplate,User,CourseSession,c]  2
    RHS1      triangle1[CertificateTemplate,User,Clinic,r]  2
    RHS1      triangle1[CertificateTemplate,User,Clinic,c]  2
    RHS1      triangle1[CertificateTemplate,User,Location,r]  2
    RHS1      triangle1[CertificateTemplate,User,Location,c]  2
    RHS1      triangle1[CertificateTemplate,User,Therapist,r]  2
    RHS1      triangle1[CertificateTemplate,User,Therapist,c]  2
    RHS1      triangle1[CertificateTemplate,User,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,User,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Clinic,r]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Clinic,c]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Location,r]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Location,c]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Therapist,r]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Therapist,c]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,CourseSession,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,Clinic,Location,r]  2
    RHS1      triangle1[CertificateTemplate,Clinic,Location,c]  2
    RHS1      triangle1[CertificateTemplate,Clinic,Therapist,r]  2
    RHS1      triangle1[CertificateTemplate,Clinic,Therapist,c]  2
    RHS1      triangle1[CertificateTemplate,Clinic,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,Clinic,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,Location,Therapist,r]  2
    RHS1      triangle1[CertificateTemplate,Location,Therapist,c]  2
    RHS1      triangle1[CertificateTemplate,Location,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,Location,Instructor,c]  2
    RHS1      triangle1[CertificateTemplate,Therapist,Instructor,r]  2
    RHS1      triangle1[CertificateTemplate,Therapist,Instructor,c]  2
    RHS1      triangle1[Course,Role,User,r]  2
    RHS1      triangle1[Course,Role,User,c]  2
    RHS1      triangle1[Course,Role,CourseSession,r]  2
    RHS1      triangle1[Course,Role,CourseSession,c]  2
    RHS1      triangle1[Course,Role,Clinic,r]  2
    RHS1      triangle1[Course,Role,Clinic,c]  2
    RHS1      triangle1[Course,Role,Location,r]  2
    RHS1      triangle1[Course,Role,Location,c]  2
    RHS1      triangle1[Course,Role,Therapist,r]  2
    RHS1      triangle1[Course,Role,Therapist,c]  2
    RHS1      triangle1[Course,Role,Instructor,r]  2
    RHS1      triangle1[Course,Role,Instructor,c]  2
    RHS1      triangle1[Course,User,CourseSession,r]  2
    RHS1      triangle1[Course,User,CourseSession,c]  2
    RHS1      triangle1[Course,User,Clinic,r]  2
    RHS1      triangle1[Course,User,Clinic,c]  2
    RHS1      triangle1[Course,User,Location,r]  2
    RHS1      triangle1[Course,User,Location,c]  2
    RHS1      triangle1[Course,User,Therapist,r]  2
    RHS1      triangle1[Course,User,Therapist,c]  2
    RHS1      triangle1[Course,User,Instructor,r]  2
    RHS1      triangle1[Course,User,Instructor,c]  2
    RHS1      triangle1[Course,CourseSession,Clinic,r]  2
    RHS1      triangle1[Course,CourseSession,Clinic,c]  2
    RHS1      triangle1[Course,CourseSession,Location,r]  2
    RHS1      triangle1[Course,CourseSession,Location,c]  2
    RHS1      triangle1[Course,CourseSession,Therapist,r]  2
    RHS1      triangle1[Course,CourseSession,Therapist,c]  2
    RHS1      triangle1[Course,CourseSession,Instructor,r]  2
    RHS1      triangle1[Course,CourseSession,Instructor,c]  2
    RHS1      triangle1[Course,Clinic,Location,r]  2
    RHS1      triangle1[Course,Clinic,Location,c]  2
    RHS1      triangle1[Course,Clinic,Therapist,r]  2
    RHS1      triangle1[Course,Clinic,Therapist,c]  2
    RHS1      triangle1[Course,Clinic,Instructor,r]  2
    RHS1      triangle1[Course,Clinic,Instructor,c]  2
    RHS1      triangle1[Course,Location,Therapist,r]  2
    RHS1      triangle1[Course,Location,Therapist,c]  2
    RHS1      triangle1[Course,Location,Instructor,r]  2
    RHS1      triangle1[Course,Location,Instructor,c]  2
    RHS1      triangle1[Course,Therapist,Instructor,r]  2
    RHS1      triangle1[Course,Therapist,Instructor,c]  2
    RHS1      triangle1[Role,User,CourseSession,r]  2
    RHS1      triangle1[Role,User,CourseSession,c]  2
    RHS1      triangle1[Role,User,Clinic,r]  2
    RHS1      triangle1[Role,User,Clinic,c]  2
    RHS1      triangle1[Role,User,Location,r]  2
    RHS1      triangle1[Role,User,Location,c]  2
    RHS1      triangle1[Role,User,Therapist,r]  2
    RHS1      triangle1[Role,User,Therapist,c]  2
    RHS1      triangle1[Role,User,Instructor,r]  2
    RHS1      triangle1[Role,User,Instructor,c]  2
    RHS1      triangle1[Role,CourseSession,Clinic,r]  2
    RHS1      triangle1[Role,CourseSession,Clinic,c]  2
    RHS1      triangle1[Role,CourseSession,Location,r]  2
    RHS1      triangle1[Role,CourseSession,Location,c]  2
    RHS1      triangle1[Role,CourseSession,Therapist,r]  2
    RHS1      triangle1[Role,CourseSession,Therapist,c]  2
    RHS1      triangle1[Role,CourseSession,Instructor,r]  2
    RHS1      triangle1[Role,CourseSession,Instructor,c]  2
    RHS1      triangle1[Role,Clinic,Location,r]  2
    RHS1      triangle1[Role,Clinic,Location,c]  2
    RHS1      triangle1[Role,Clinic,Therapist,r]  2
    RHS1      triangle1[Role,Clinic,Therapist,c]  2
    RHS1      triangle1[Role,Clinic,Instructor,r]  2
    RHS1      triangle1[Role,Clinic,Instructor,c]  2
    RHS1      triangle1[Role,Location,Therapist,r]  2
    RHS1      triangle1[Role,Location,Therapist,c]  2
    RHS1      triangle1[Role,Location,Instructor,r]  2
    RHS1      triangle1[Role,Location,Instructor,c]  2
    RHS1      triangle1[Role,Therapist,Instructor,r]  2
    RHS1      triangle1[Role,Therapist,Instructor,c]  2
    RHS1      triangle1[User,CourseSession,Clinic,r]  2
    RHS1      triangle1[User,CourseSession,Clinic,c]  2
    RHS1      triangle1[User,CourseSession,Location,r]  2
    RHS1      triangle1[User,CourseSession,Location,c]  2
    RHS1      triangle1[User,CourseSession,Therapist,r]  2
    RHS1      triangle1[User,CourseSession,Therapist,c]  2
    RHS1      triangle1[User,CourseSession,Instructor,r]  2
    RHS1      triangle1[User,CourseSession,Instructor,c]  2
    RHS1      triangle1[User,Clinic,Location,r]  2
    RHS1      triangle1[User,Clinic,Location,c]  2
    RHS1      triangle1[User,Clinic,Therapist,r]  2
    RHS1      triangle1[User,Clinic,Therapist,c]  2
    RHS1      triangle1[User,Clinic,Instructor,r]  2
    RHS1      triangle1[User,Clinic,Instructor,c]  2
    RHS1      triangle1[User,Location,Therapist,r]  2
    RHS1      triangle1[User,Location,Therapist,c]  2
    RHS1      triangle1[User,Location,Instructor,r]  2
    RHS1      triangle1[User,Location,Instructor,c]  2
    RHS1      triangle1[User,Therapist,Instructor,r]  2
    RHS1      triangle1[User,Therapist,Instructor,c]  2
    RHS1      triangle1[CourseSession,Clinic,Location,r]  2
    RHS1      triangle1[CourseSession,Clinic,Location,c]  2
    RHS1      triangle1[CourseSession,Clinic,Therapist,r]  2
    RHS1      triangle1[CourseSession,Clinic,Therapist,c]  2
    RHS1      triangle1[CourseSession,Clinic,Instructor,r]  2
    RHS1      triangle1[CourseSession,Clinic,Instructor,c]  2
    RHS1      triangle1[CourseSession,Location,Therapist,r]  2
    RHS1      triangle1[CourseSession,Location,Therapist,c]  2
    RHS1      triangle1[CourseSession,Location,Instructor,r]  2
    RHS1      triangle1[CourseSession,Location,Instructor,c]  2
    RHS1      triangle1[CourseSession,Therapist,Instructor,r]  2
    RHS1      triangle1[CourseSession,Therapist,Instructor,c]  2
    RHS1      triangle1[Clinic,Location,Therapist,r]  2
    RHS1      triangle1[Clinic,Location,Therapist,c]  2
    RHS1      triangle1[Clinic,Location,Instructor,r]  2
    RHS1      triangle1[Clinic,Location,Instructor,c]  2
    RHS1      triangle1[Clinic,Therapist,Instructor,r]  2
    RHS1      triangle1[Clinic,Therapist,Instructor,c]  2
    RHS1      triangle1[Location,Therapist,Instructor,r]  2
    RHS1      triangle1[Location,Therapist,Instructor,c]  2
    RHS1      triangle2[Client,CertificateTemplate,Course,r]  2
    RHS1      triangle2[Client,CertificateTemplate,Course,c]  2
    RHS1      triangle2[Client,CertificateTemplate,Role,r]  2
    RHS1      triangle2[Client,CertificateTemplate,Role,c]  2
    RHS1      triangle2[Client,CertificateTemplate,User,r]  2
    RHS1      triangle2[Client,CertificateTemplate,User,c]  2
    RHS1      triangle2[Client,CertificateTemplate,CourseSession,r]  2
    RHS1      triangle2[Client,CertificateTemplate,CourseSession,c]  2
    RHS1      triangle2[Client,CertificateTemplate,Clinic,r]  2
    RHS1      triangle2[Client,CertificateTemplate,Clinic,c]  2
    RHS1      triangle2[Client,CertificateTemplate,Location,r]  2
    RHS1      triangle2[Client,CertificateTemplate,Location,c]  2
    RHS1      triangle2[Client,CertificateTemplate,Therapist,r]  2
    RHS1      triangle2[Client,CertificateTemplate,Therapist,c]  2
    RHS1      triangle2[Client,CertificateTemplate,Instructor,r]  2
    RHS1      triangle2[Client,CertificateTemplate,Instructor,c]  2
    RHS1      triangle2[Client,Course,Role,r]  2
    RHS1      triangle2[Client,Course,Role,c]  2
    RHS1      triangle2[Client,Course,User,r]  2
    RHS1      triangle2[Client,Course,User,c]  2
    RHS1      triangle2[Client,Course,CourseSession,r]  2
    RHS1      triangle2[Client,Course,CourseSession,c]  2
    RHS1      triangle2[Client,Course,Clinic,r]  2
    RHS1      triangle2[Client,Course,Clinic,c]  2
    RHS1      triangle2[Client,Course,Location,r]  2
    RHS1      triangle2[Client,Course,Location,c]  2
    RHS1      triangle2[Client,Course,Therapist,r]  2
    RHS1      triangle2[Client,Course,Therapist,c]  2
    RHS1      triangle2[Client,Course,Instructor,r]  2
    RHS1      triangle2[Client,Course,Instructor,c]  2
    RHS1      triangle2[Client,Role,User,r]  2
    RHS1      triangle2[Client,Role,User,c]  2
    RHS1      triangle2[Client,Role,CourseSession,r]  2
    RHS1      triangle2[Client,Role,CourseSession,c]  2
    RHS1      triangle2[Client,Role,Clinic,r]  2
    RHS1      triangle2[Client,Role,Clinic,c]  2
    RHS1      triangle2[Client,Role,Location,r]  2
    RHS1      triangle2[Client,Role,Location,c]  2
    RHS1      triangle2[Client,Role,Therapist,r]  2
    RHS1      triangle2[Client,Role,Therapist,c]  2
    RHS1      triangle2[Client,Role,Instructor,r]  2
    RHS1      triangle2[Client,Role,Instructor,c]  2
    RHS1      triangle2[Client,User,CourseSession,r]  2
    RHS1      triangle2[Client,User,CourseSession,c]  2
    RHS1      triangle2[Client,User,Clinic,r]  2
    RHS1      triangle2[Client,User,Clinic,c]  2
    RHS1      triangle2[Client,User,Location,r]  2
    RHS1      triangle2[Client,User,Location,c]  2
    RHS1      triangle2[Client,User,Therapist,r]  2
    RHS1      triangle2[Client,User,Therapist,c]  2
    RHS1      triangle2[Client,User,Instructor,r]  2
    RHS1      triangle2[Client,User,Instructor,c]  2
    RHS1      triangle2[Client,CourseSession,Clinic,r]  2
    RHS1      triangle2[Client,CourseSession,Clinic,c]  2
    RHS1      triangle2[Client,CourseSession,Location,r]  2
    RHS1      triangle2[Client,CourseSession,Location,c]  2
    RHS1      triangle2[Client,CourseSession,Therapist,r]  2
    RHS1      triangle2[Client,CourseSession,Therapist,c]  2
    RHS1      triangle2[Client,CourseSession,Instructor,r]  2
    RHS1      triangle2[Client,CourseSession,Instructor,c]  2
    RHS1      triangle2[Client,Clinic,Location,r]  2
    RHS1      triangle2[Client,Clinic,Location,c]  2
    RHS1      triangle2[Client,Clinic,Therapist,r]  2
    RHS1      triangle2[Client,Clinic,Therapist,c]  2
    RHS1      triangle2[Client,Clinic,Instructor,r]  2
    RHS1      triangle2[Client,Clinic,Instructor,c]  2
    RHS1      triangle2[Client,Location,Therapist,r]  2
    RHS1      triangle2[Client,Location,Therapist,c]  2
    RHS1      triangle2[Client,Location,Instructor,r]  2
    RHS1      triangle2[Client,Location,Instructor,c]  2
    RHS1      triangle2[Client,Therapist,Instructor,r]  2
    RHS1      triangle2[Client,Therapist,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,Course,Role,r]  2
    RHS1      triangle2[CertificateTemplate,Course,Role,c]  2
    RHS1      triangle2[CertificateTemplate,Course,User,r]  2
    RHS1      triangle2[CertificateTemplate,Course,User,c]  2
    RHS1      triangle2[CertificateTemplate,Course,CourseSession,r]  2
    RHS1      triangle2[CertificateTemplate,Course,CourseSession,c]  2
    RHS1      triangle2[CertificateTemplate,Course,Clinic,r]  2
    RHS1      triangle2[CertificateTemplate,Course,Clinic,c]  2
    RHS1      triangle2[CertificateTemplate,Course,Location,r]  2
    RHS1      triangle2[CertificateTemplate,Course,Location,c]  2
    RHS1      triangle2[CertificateTemplate,Course,Therapist,r]  2
    RHS1      triangle2[CertificateTemplate,Course,Therapist,c]  2
    RHS1      triangle2[CertificateTemplate,Course,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,Course,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,Role,User,r]  2
    RHS1      triangle2[CertificateTemplate,Role,User,c]  2
    RHS1      triangle2[CertificateTemplate,Role,CourseSession,r]  2
    RHS1      triangle2[CertificateTemplate,Role,CourseSession,c]  2
    RHS1      triangle2[CertificateTemplate,Role,Clinic,r]  2
    RHS1      triangle2[CertificateTemplate,Role,Clinic,c]  2
    RHS1      triangle2[CertificateTemplate,Role,Location,r]  2
    RHS1      triangle2[CertificateTemplate,Role,Location,c]  2
    RHS1      triangle2[CertificateTemplate,Role,Therapist,r]  2
    RHS1      triangle2[CertificateTemplate,Role,Therapist,c]  2
    RHS1      triangle2[CertificateTemplate,Role,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,Role,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,User,CourseSession,r]  2
    RHS1      triangle2[CertificateTemplate,User,CourseSession,c]  2
    RHS1      triangle2[CertificateTemplate,User,Clinic,r]  2
    RHS1      triangle2[CertificateTemplate,User,Clinic,c]  2
    RHS1      triangle2[CertificateTemplate,User,Location,r]  2
    RHS1      triangle2[CertificateTemplate,User,Location,c]  2
    RHS1      triangle2[CertificateTemplate,User,Therapist,r]  2
    RHS1      triangle2[CertificateTemplate,User,Therapist,c]  2
    RHS1      triangle2[CertificateTemplate,User,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,User,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Clinic,r]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Clinic,c]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Location,r]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Location,c]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Therapist,r]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Therapist,c]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,CourseSession,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,Clinic,Location,r]  2
    RHS1      triangle2[CertificateTemplate,Clinic,Location,c]  2
    RHS1      triangle2[CertificateTemplate,Clinic,Therapist,r]  2
    RHS1      triangle2[CertificateTemplate,Clinic,Therapist,c]  2
    RHS1      triangle2[CertificateTemplate,Clinic,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,Clinic,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,Location,Therapist,r]  2
    RHS1      triangle2[CertificateTemplate,Location,Therapist,c]  2
    RHS1      triangle2[CertificateTemplate,Location,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,Location,Instructor,c]  2
    RHS1      triangle2[CertificateTemplate,Therapist,Instructor,r]  2
    RHS1      triangle2[CertificateTemplate,Therapist,Instructor,c]  2
    RHS1      triangle2[Course,Role,User,r]  2
    RHS1      triangle2[Course,Role,User,c]  2
    RHS1      triangle2[Course,Role,CourseSession,r]  2
    RHS1      triangle2[Course,Role,CourseSession,c]  2
    RHS1      triangle2[Course,Role,Clinic,r]  2
    RHS1      triangle2[Course,Role,Clinic,c]  2
    RHS1      triangle2[Course,Role,Location,r]  2
    RHS1      triangle2[Course,Role,Location,c]  2
    RHS1      triangle2[Course,Role,Therapist,r]  2
    RHS1      triangle2[Course,Role,Therapist,c]  2
    RHS1      triangle2[Course,Role,Instructor,r]  2
    RHS1      triangle2[Course,Role,Instructor,c]  2
    RHS1      triangle2[Course,User,CourseSession,r]  2
    RHS1      triangle2[Course,User,CourseSession,c]  2
    RHS1      triangle2[Course,User,Clinic,r]  2
    RHS1      triangle2[Course,User,Clinic,c]  2
    RHS1      triangle2[Course,User,Location,r]  2
    RHS1      triangle2[Course,User,Location,c]  2
    RHS1      triangle2[Course,User,Therapist,r]  2
    RHS1      triangle2[Course,User,Therapist,c]  2
    RHS1      triangle2[Course,User,Instructor,r]  2
    RHS1      triangle2[Course,User,Instructor,c]  2
    RHS1      triangle2[Course,CourseSession,Clinic,r]  2
    RHS1      triangle2[Course,CourseSession,Clinic,c]  2
    RHS1      triangle2[Course,CourseSession,Location,r]  2
    RHS1      triangle2[Course,CourseSession,Location,c]  2
    RHS1      triangle2[Course,CourseSession,Therapist,r]  2
    RHS1      triangle2[Course,CourseSession,Therapist,c]  2
    RHS1      triangle2[Course,CourseSession,Instructor,r]  2
    RHS1      triangle2[Course,CourseSession,Instructor,c]  2
    RHS1      triangle2[Course,Clinic,Location,r]  2
    RHS1      triangle2[Course,Clinic,Location,c]  2
    RHS1      triangle2[Course,Clinic,Therapist,r]  2
    RHS1      triangle2[Course,Clinic,Therapist,c]  2
    RHS1      triangle2[Course,Clinic,Instructor,r]  2
    RHS1      triangle2[Course,Clinic,Instructor,c]  2
    RHS1      triangle2[Course,Location,Therapist,r]  2
    RHS1      triangle2[Course,Location,Therapist,c]  2
    RHS1      triangle2[Course,Location,Instructor,r]  2
    RHS1      triangle2[Course,Location,Instructor,c]  2
    RHS1      triangle2[Course,Therapist,Instructor,r]  2
    RHS1      triangle2[Course,Therapist,Instructor,c]  2
    RHS1      triangle2[Role,User,CourseSession,r]  2
    RHS1      triangle2[Role,User,CourseSession,c]  2
    RHS1      triangle2[Role,User,Clinic,r]  2
    RHS1      triangle2[Role,User,Clinic,c]  2
    RHS1      triangle2[Role,User,Location,r]  2
    RHS1      triangle2[Role,User,Location,c]  2
    RHS1      triangle2[Role,User,Therapist,r]  2
    RHS1      triangle2[Role,User,Therapist,c]  2
    RHS1      triangle2[Role,User,Instructor,r]  2
    RHS1      triangle2[Role,User,Instructor,c]  2
    RHS1      triangle2[Role,CourseSession,Clinic,r]  2
    RHS1      triangle2[Role,CourseSession,Clinic,c]  2
    RHS1      triangle2[Role,CourseSession,Location,r]  2
    RHS1      triangle2[Role,CourseSession,Location,c]  2
    RHS1      triangle2[Role,CourseSession,Therapist,r]  2
    RHS1      triangle2[Role,CourseSession,Therapist,c]  2
    RHS1      triangle2[Role,CourseSession,Instructor,r]  2
    RHS1      triangle2[Role,CourseSession,Instructor,c]  2
    RHS1      triangle2[Role,Clinic,Location,r]  2
    RHS1      triangle2[Role,Clinic,Location,c]  2
    RHS1      triangle2[Role,Clinic,Therapist,r]  2
    RHS1      triangle2[Role,Clinic,Therapist,c]  2
    RHS1      triangle2[Role,Clinic,Instructor,r]  2
    RHS1      triangle2[Role,Clinic,Instructor,c]  2
    RHS1      triangle2[Role,Location,Therapist,r]  2
    RHS1      triangle2[Role,Location,Therapist,c]  2
    RHS1      triangle2[Role,Location,Instructor,r]  2
    RHS1      triangle2[Role,Location,Instructor,c]  2
    RHS1      triangle2[Role,Therapist,Instructor,r]  2
    RHS1      triangle2[Role,Therapist,Instructor,c]  2
    RHS1      triangle2[User,CourseSession,Clinic,r]  2
    RHS1      triangle2[User,CourseSession,Clinic,c]  2
    RHS1      triangle2[User,CourseSession,Location,r]  2
    RHS1      triangle2[User,CourseSession,Location,c]  2
    RHS1      triangle2[User,CourseSession,Therapist,r]  2
    RHS1      triangle2[User,CourseSession,Therapist,c]  2
    RHS1      triangle2[User,CourseSession,Instructor,r]  2
    RHS1      triangle2[User,CourseSession,Instructor,c]  2
    RHS1      triangle2[User,Clinic,Location,r]  2
    RHS1      triangle2[User,Clinic,Location,c]  2
    RHS1      triangle2[User,Clinic,Therapist,r]  2
    RHS1      triangle2[User,Clinic,Therapist,c]  2
    RHS1      triangle2[User,Clinic,Instructor,r]  2
    RHS1      triangle2[User,Clinic,Instructor,c]  2
    RHS1      triangle2[User,Location,Therapist,r]  2
    RHS1      triangle2[User,Location,Therapist,c]  2
    RHS1      triangle2[User,Location,Instructor,r]  2
    RHS1      triangle2[User,Location,Instructor,c]  2
    RHS1      triangle2[User,Therapist,Instructor,r]  2
    RHS1      triangle2[User,Therapist,Instructor,c]  2
    RHS1      triangle2[CourseSession,Clinic,Location,r]  2
    RHS1      triangle2[CourseSession,Clinic,Location,c]  2
    RHS1      triangle2[CourseSession,Clinic,Therapist,r]  2
    RHS1      triangle2[CourseSession,Clinic,Therapist,c]  2
    RHS1      triangle2[CourseSession,Clinic,Instructor,r]  2
    RHS1      triangle2[CourseSession,Clinic,Instructor,c]  2
    RHS1      triangle2[CourseSession,Location,Therapist,r]  2
    RHS1      triangle2[CourseSession,Location,Therapist,c]  2
    RHS1      triangle2[CourseSession,Location,Instructor,r]  2
    RHS1      triangle2[CourseSession,Location,Instructor,c]  2
    RHS1      triangle2[CourseSession,Therapist,Instructor,r]  2
    RHS1      triangle2[CourseSession,Therapist,Instructor,c]  2
    RHS1      triangle2[Clinic,Location,Therapist,r]  2
    RHS1      triangle2[Clinic,Location,Therapist,c]  2
    RHS1      triangle2[Clinic,Location,Instructor,r]  2
    RHS1      triangle2[Clinic,Location,Instructor,c]  2
    RHS1      triangle2[Clinic,Therapist,Instructor,r]  2
    RHS1      triangle2[Clinic,Therapist,Instructor,c]  2
    RHS1      triangle2[Location,Therapist,Instructor,r]  2
    RHS1      triangle2[Location,Therapist,Instructor,c]  2
BOUNDS
 LO BND1      x[r,Client]  1
 UP BND1      x[r,Client]  34
 LO BND1      x[r,CertificateTemplate]  1
 UP BND1      x[r,CertificateTemplate]  36
 LO BND1      x[r,Course]  1
 UP BND1      x[r,Course]  37
 LO BND1      x[r,Role]  1
 UP BND1      x[r,Role]  37
 LO BND1      x[r,User]  1
 UP BND1      x[r,User]  36
 LO BND1      x[r,CourseSession]  1
 UP BND1      x[r,CourseSession]  34
 LO BND1      x[r,Clinic]  1
 UP BND1      x[r,Clinic]  35
 LO BND1      x[r,Location]  1
 UP BND1      x[r,Location]  34
 LO BND1      x[r,Therapist]  1
 UP BND1      x[r,Therapist]  33
 LO BND1      x[r,Instructor]  1
 UP BND1      x[r,Instructor]  33
 LO BND1      x[c,Client]  1
 UP BND1      x[c,Client]  32
 LO BND1      x[c,CertificateTemplate]  1
 UP BND1      x[c,CertificateTemplate]  31
 LO BND1      x[c,Course]  1
 UP BND1      x[c,Course]  33
 LO BND1      x[c,Role]  1
 UP BND1      x[c,Role]  33
 LO BND1      x[c,User]  1
 UP BND1      x[c,User]  32
 LO BND1      x[c,CourseSession]  1
 UP BND1      x[c,CourseSession]  29
 LO BND1      x[c,Clinic]  1
 UP BND1      x[c,Clinic]  32
 LO BND1      x[c,Location]  1
 UP BND1      x[c,Location]  32
 LO BND1      x[c,Therapist]  1
 UP BND1      x[c,Therapist]  32
 LO BND1      x[c,Instructor]  1
 UP BND1      x[c,Instructor]  31
 UP BND1      center_dist[r,Client]  353
 UP BND1      center_dist[r,CertificateTemplate]  353
 UP BND1      center_dist[r,Course]  353
 UP BND1      center_dist[r,Role]  353
 UP BND1      center_dist[r,User]  353
 UP BND1      center_dist[r,CourseSession]  353
 UP BND1      center_dist[r,Clinic]  353
 UP BND1      center_dist[r,Location]  353
 UP BND1      center_dist[r,Therapist]  353
 UP BND1      center_dist[r,Instructor]  353
 UP BND1      center_dist[c,Client]  353
 UP BND1      center_dist[c,CertificateTemplate]  353
 UP BND1      center_dist[c,Course]  353
 UP BND1      center_dist[c,Role]  353
 UP BND1      center_dist[c,User]  353
 UP BND1      center_dist[c,CourseSession]  353
 UP BND1      center_dist[c,Clinic]  353
 UP BND1      center_dist[c,Location]  353
 UP BND1      center_dist[c,Therapist]  353
 UP BND1      center_dist[c,Instructor]  353
 UP BND1      dist[r,Client,CertificateTemplate]  34
 UP BND1      dist[r,Client,CourseSession]  33
 UP BND1      dist[r,Client,Instructor]  32.5
 UP BND1      dist[r,Client,Location]  33
 UP BND1      dist[r,Client,User]  34
 UP BND1      dist[r,CertificateTemplate,CourseSession]  34
 UP BND1      dist[r,Course,CourseSession]  34.5
 UP BND1      dist[r,CourseSession,Instructor]  32.5
 UP BND1      dist[r,Instructor,Location]  32.5
 UP BND1      dist[r,Clinic,Location]  33.5
 UP BND1      dist[r,Clinic,Therapist]  33
 UP BND1      dist[r,Location,Therapist]  32.5
 UP BND1      dist[r,Location,CourseSession]  33
 UP BND1      dist[r,Therapist,CourseSession]  32.5
 UP BND1      dist[r,Role,User]  35.5
 UP BND1      dist[r,User,Instructor]  33.5
 UP BND1      dist[r,User,Therapist]  33.5
 UP BND1      dist[c,Client,CertificateTemplate]  30.5
 UP BND1      dist[c,Client,CourseSession]  29.5
 UP BND1      dist[c,Client,Instructor]  30.5
 UP BND1      dist[c,Client,Location]  31
 UP BND1      dist[c,Client,User]  31
 UP BND1      dist[c,CertificateTemplate,CourseSession]  29
 UP BND1      dist[c,Course,CourseSession]  30
 UP BND1      dist[c,CourseSession,Instructor]  29
 UP BND1      dist[c,Instructor,Location]  30.5
 UP BND1      dist[c,Clinic,Location]  31
 UP BND1      dist[c,Clinic,Therapist]  31
 UP BND1      dist[c,Location,Therapist]  31
 UP BND1      dist[c,Location,CourseSession]  29.5
 UP BND1      dist[c,Therapist,CourseSession]  29.5
 UP BND1      dist[c,Role,User]  31.5
 UP BND1      dist[c,User,Instructor]  30.5
 UP BND1      dist[c,User,Therapist]  31
 BV BND1      zV[r,rt,Client,CertificateTemplate]
 BV BND1      zV[c,rt,Client,CertificateTemplate]
 BV BND1      zV[r,lb,Client,CertificateTemplate]
 BV BND1      zV[c,lb,Client,CertificateTemplate]
 BV BND1      zV[r,rt,Client,Course]
 BV BND1      zV[c,rt,Client,Course]
 BV BND1      zV[r,lb,Client,Course]
 BV BND1      zV[c,lb,Client,Course]
 BV BND1      zV[r,rt,Client,Role]
 BV BND1      zV[c,rt,Client,Role]
 BV BND1      zV[r,lb,Client,Role]
 BV BND1      zV[c,lb,Client,Role]
 BV BND1      zV[r,rt,Client,User]
 BV BND1      zV[c,rt,Client,User]
 BV BND1      zV[r,lb,Client,User]
 BV BND1      zV[c,lb,Client,User]
 BV BND1      zV[r,rt,Client,CourseSession]
 BV BND1      zV[c,rt,Client,CourseSession]
 BV BND1      zV[r,lb,Client,CourseSession]
 BV BND1      zV[c,lb,Client,CourseSession]
 BV BND1      zV[r,rt,Client,Clinic]
 BV BND1      zV[c,rt,Client,Clinic]
 BV BND1      zV[r,lb,Client,Clinic]
 BV BND1      zV[c,lb,Client,Clinic]
 BV BND1      zV[r,rt,Client,Location]
 BV BND1      zV[c,rt,Client,Location]
 BV BND1      zV[r,lb,Client,Location]
 BV BND1      zV[c,lb,Client,Location]
 BV BND1      zV[r,rt,Client,Therapist]
 BV BND1      zV[c,rt,Client,Therapist]
 BV BND1      zV[r,lb,Client,Therapist]
 BV BND1      zV[c,lb,Client,Therapist]
 BV BND1      zV[r,rt,Client,Instructor]
 BV BND1      zV[c,rt,Client,Instructor]
 BV BND1      zV[r,lb,Client,Instructor]
 BV BND1      zV[c,lb,Client,Instructor]
 BV BND1      zV[r,rt,CertificateTemplate,Course]
 BV BND1      zV[c,rt,CertificateTemplate,Course]
 BV BND1      zV[r,lb,CertificateTemplate,Course]
 BV BND1      zV[c,lb,CertificateTemplate,Course]
 BV BND1      zV[r,rt,CertificateTemplate,Role]
 BV BND1      zV[c,rt,CertificateTemplate,Role]
 BV BND1      zV[r,lb,CertificateTemplate,Role]
 BV BND1      zV[c,lb,CertificateTemplate,Role]
 BV BND1      zV[r,rt,CertificateTemplate,User]
 BV BND1      zV[c,rt,CertificateTemplate,User]
 BV BND1      zV[r,lb,CertificateTemplate,User]
 BV BND1      zV[c,lb,CertificateTemplate,User]
 BV BND1      zV[r,rt,CertificateTemplate,CourseSession]
 BV BND1      zV[c,rt,CertificateTemplate,CourseSession]
 BV BND1      zV[r,lb,CertificateTemplate,CourseSession]
 BV BND1      zV[c,lb,CertificateTemplate,CourseSession]
 BV BND1      zV[r,rt,CertificateTemplate,Clinic]
 BV BND1      zV[c,rt,CertificateTemplate,Clinic]
 BV BND1      zV[r,lb,CertificateTemplate,Clinic]
 BV BND1      zV[c,lb,CertificateTemplate,Clinic]
 BV BND1      zV[r,rt,CertificateTemplate,Location]
 BV BND1      zV[c,rt,CertificateTemplate,Location]
 BV BND1      zV[r,lb,CertificateTemplate,Location]
 BV BND1      zV[c,lb,CertificateTemplate,Location]
 BV BND1      zV[r,rt,CertificateTemplate,Therapist]
 BV BND1      zV[c,rt,CertificateTemplate,Therapist]
 BV BND1      zV[r,lb,CertificateTemplate,Therapist]
 BV BND1      zV[c,lb,CertificateTemplate,Therapist]
 BV BND1      zV[r,rt,CertificateTemplate,Instructor]
 BV BND1      zV[c,rt,CertificateTemplate,Instructor]
 BV BND1      zV[r,lb,CertificateTemplate,Instructor]
 BV BND1      zV[c,lb,CertificateTemplate,Instructor]
 BV BND1      zV[r,rt,Course,Role]
 BV BND1      zV[c,rt,Course,Role]
 BV BND1      zV[r,lb,Course,Role]
 BV BND1      zV[c,lb,Course,Role]
 BV BND1      zV[r,rt,Course,User]
 BV BND1      zV[c,rt,Course,User]
 BV BND1      zV[r,lb,Course,User]
 BV BND1      zV[c,lb,Course,User]
 BV BND1      zV[r,rt,Course,CourseSession]
 BV BND1      zV[c,rt,Course,CourseSession]
 BV BND1      zV[r,lb,Course,CourseSession]
 BV BND1      zV[c,lb,Course,CourseSession]
 BV BND1      zV[r,rt,Course,Clinic]
 BV BND1      zV[c,rt,Course,Clinic]
 BV BND1      zV[r,lb,Course,Clinic]
 BV BND1      zV[c,lb,Course,Clinic]
 BV BND1      zV[r,rt,Course,Location]
 BV BND1      zV[c,rt,Course,Location]
 BV BND1      zV[r,lb,Course,Location]
 BV BND1      zV[c,lb,Course,Location]
 BV BND1      zV[r,rt,Course,Therapist]
 BV BND1      zV[c,rt,Course,Therapist]
 BV BND1      zV[r,lb,Course,Therapist]
 BV BND1      zV[c,lb,Course,Therapist]
 BV BND1      zV[r,rt,Course,Instructor]
 BV BND1      zV[c,rt,Course,Instructor]
 BV BND1      zV[r,lb,Course,Instructor]
 BV BND1      zV[c,lb,Course,Instructor]
 BV BND1      zV[r,rt,Role,User]
 BV BND1      zV[c,rt,Role,User]
 BV BND1      zV[r,lb,Role,User]
 BV BND1      zV[c,lb,Role,User]
 BV BND1      zV[r,rt,Role,CourseSession]
 BV BND1      zV[c,rt,Role,CourseSession]
 BV BND1      zV[r,lb,Role,CourseSession]
 BV BND1      zV[c,lb,Role,CourseSession]
 BV BND1      zV[r,rt,Role,Clinic]
 BV BND1      zV[c,rt,Role,Clinic]
 BV BND1      zV[r,lb,Role,Clinic]
 BV BND1      zV[c,lb,Role,Clinic]
 BV BND1      zV[r,rt,Role,Location]
 BV BND1      zV[c,rt,Role,Location]
 BV BND1      zV[r,lb,Role,Location]
 BV BND1      zV[c,lb,Role,Location]
 BV BND1      zV[r,rt,Role,Therapist]
 BV BND1      zV[c,rt,Role,Therapist]
 BV BND1      zV[r,lb,Role,Therapist]
 BV BND1      zV[c,lb,Role,Therapist]
 BV BND1      zV[r,rt,Role,Instructor]
 BV BND1      zV[c,rt,Role,Instructor]
 BV BND1      zV[r,lb,Role,Instructor]
 BV BND1      zV[c,lb,Role,Instructor]
 BV BND1      zV[r,rt,User,CourseSession]
 BV BND1      zV[c,rt,User,CourseSession]
 BV BND1      zV[r,lb,User,CourseSession]
 BV BND1      zV[c,lb,User,CourseSession]
 BV BND1      zV[r,rt,User,Clinic]
 BV BND1      zV[c,rt,User,Clinic]
 BV BND1      zV[r,lb,User,Clinic]
 BV BND1      zV[c,lb,User,Clinic]
 BV BND1      zV[r,rt,User,Location]
 BV BND1      zV[c,rt,User,Location]
 BV BND1      zV[r,lb,User,Location]
 BV BND1      zV[c,lb,User,Location]
 BV BND1      zV[r,rt,User,Therapist]
 BV BND1      zV[c,rt,User,Therapist]
 BV BND1      zV[r,lb,User,Therapist]
 BV BND1      zV[c,lb,User,Therapist]
 BV BND1      zV[r,rt,User,Instructor]
 BV BND1      zV[c,rt,User,Instructor]
 BV BND1      zV[r,lb,User,Instructor]
 BV BND1      zV[c,lb,User,Instructor]
 BV BND1      zV[r,rt,CourseSession,Clinic]
 BV BND1      zV[c,rt,CourseSession,Clinic]
 BV BND1      zV[r,lb,CourseSession,Clinic]
 BV BND1      zV[c,lb,CourseSession,Clinic]
 BV BND1      zV[r,rt,CourseSession,Location]
 BV BND1      zV[c,rt,CourseSession,Location]
 BV BND1      zV[r,lb,CourseSession,Location]
 BV BND1      zV[c,lb,CourseSession,Location]
 BV BND1      zV[r,rt,CourseSession,Therapist]
 BV BND1      zV[c,rt,CourseSession,Therapist]
 BV BND1      zV[r,lb,CourseSession,Therapist]
 BV BND1      zV[c,lb,CourseSession,Therapist]
 BV BND1      zV[r,rt,CourseSession,Instructor]
 BV BND1      zV[c,rt,CourseSession,Instructor]
 BV BND1      zV[r,lb,CourseSession,Instructor]
 BV BND1      zV[c,lb,CourseSession,Instructor]
 BV BND1      zV[r,rt,Clinic,Location]
 BV BND1      zV[c,rt,Clinic,Location]
 BV BND1      zV[r,lb,Clinic,Location]
 BV BND1      zV[c,lb,Clinic,Location]
 BV BND1      zV[r,rt,Clinic,Therapist]
 BV BND1      zV[c,rt,Clinic,Therapist]
 BV BND1      zV[r,lb,Clinic,Therapist]
 BV BND1      zV[c,lb,Clinic,Therapist]
 BV BND1      zV[r,rt,Clinic,Instructor]
 BV BND1      zV[c,rt,Clinic,Instructor]
 BV BND1      zV[r,lb,Clinic,Instructor]
 BV BND1      zV[c,lb,Clinic,Instructor]
 BV BND1      zV[r,rt,Location,Therapist]
 BV BND1      zV[c,rt,Location,Therapist]
 BV BND1      zV[r,lb,Location,Therapist]
 BV BND1      zV[c,lb,Location,Therapist]
 BV BND1      zV[r,rt,Location,Instructor]
 BV BND1      zV[c,rt,Location,Instructor]
 BV BND1      zV[r,lb,Location,Instructor]
 BV BND1      zV[c,lb,Location,Instructor]
 BV BND1      zV[r,rt,Therapist,Instructor]
 BV BND1      zV[c,rt,Therapist,Instructor]
 BV BND1      zV[r,lb,Therapist,Instructor]
 BV BND1      zV[c,lb,Therapist,Instructor]
ENDATA
